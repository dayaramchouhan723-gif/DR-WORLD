# DR WORLD v2.2.0 — Design & Developed by Dayaram Chouhan

[![Download Latest APK](https://img.shields.io/badge/Download%20APK-DR--WORLD--v2.2.0-7C3AED?style=for-the-badge&logo=android&logoColor=white)](../../releases/latest/download/DR-WORLD-v2.2.0-by-Dayaram-Chouhan.apk)
[![All Releases](https://img.shields.io/badge/All%20Releases-source%20zip%20%2B%20tar.gz-00A86B?style=for-the-badge)](../../releases)

**DR WORLD** is a voice-first Android assistant and phone controller, designed and developed by **Dayaram Chouhan**. It is the upgrade of Sanam AI v2.1.0 with the complete **MK KING 👑** hub merged in.

## Download

- APK: `DR-WORLD-v2.2.0-by-Dayaram-Chouhan.apk` (Releases page, also `app-debug.apk`)
- Source code: `Source code (zip)` and `Source code (tar.gz)` on the same Releases page

## What is inside

1. **Sanam voice companion** (unchanged from v2.1.0): 3-character voice orb, "Hey Sanam" wake word, 32-voice library with offline mode.
2. **Device control**: accessibility screen reader, auto-click for WhatsApp, Instagram, Facebook, SMS and calls, touch guard, anti-theft security.
3. **Social media agent** and **PC controller** (QR code plus WebSocket remote on your Wi-Fi).
4. **MK KING 👑 hub** (new): Home, Scan, Memories, Chat and Settings screens, with the personas, voices and agents of MK KING. Open it with the 👑 MK KING button at the top right. The DR WORLD button in its bottom bar (or the Back button) brings you back.

## Build it yourself (free, from a phone)

1. Create a GitHub repository.
2. Create the file `.github/workflows/build.yml` and paste the file `build.yml` from this project.
3. Upload `DR-WORLD-2.2.0.zip` to the repo root. The workflow unpacks it, builds the APK and publishes a Release.
4. For AI replies, add your Gemini key in `.env` (see `.env.example`). Never commit `.env`, and do not share an APK that has your key inside.

The app installs under its own id (`com.dayaramchouhan.drworld`), so it sits next to the old Sanam app.

---
*Design & Developed by Dayaram Chouhan • DR WORLD v2.2.0*
