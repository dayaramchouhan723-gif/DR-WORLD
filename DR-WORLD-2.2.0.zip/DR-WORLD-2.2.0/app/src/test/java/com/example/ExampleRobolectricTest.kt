package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.sanam.controller.AppLauncher
import com.example.sanam.controller.CallHelper
import com.example.sanam.controller.DeviceActionManager
import com.example.sanam.controller.DeviceController
import com.example.sanam.controller.SmsHelper
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Sanam AI", appName)
    }

    @Test
    fun `verify JARVIS and MYRA unified controllers and helpers`() {
        val context = ApplicationProvider.getApplicationContext<Context>()

        // Verify CallHelper contact resolution
        assertEquals("+919876543210", CallHelper.resolvePhone("Dayaram"))
        assertEquals("+919876500001", CallHelper.resolvePhone("Mumma"))

        // Verify AppLauncher supported apps list
        assertTrue(AppLauncher.supportedApps.contains("WhatsApp"))
        assertTrue(AppLauncher.supportedApps.contains("Instagram"))

        // Verify SocialAgent card generator and telemetry
        val telemetry = DeviceController.getDeviceTelemetry(context, isFlashlightOn = false)
        assertTrue(telemetry.batteryPercent in 0..100)

        val generatedCard = SocialAgent.generateStylizedSocialCardFile(
            context = context,
            title = "Sanam AI Test",
            caption = "Unified JARVIS + MYRA test card",
            language = "Dhatki"
        )
        assertTrue(generatedCard.exists())

        // Verify ScreenTools & DeviceActionManager command routing
        val commandResult = DeviceActionManager.parseAndExecuteUnifiedCommand(
            context = context,
            rawInput = "Post to Insta: Hello from Sanam AI",
            hasCallPermission = false,
            hasSmsPermission = false,
            currentFlashlightState = false,
            imageFileProvider = { generatedCard }
        )
        assertTrue(commandResult.executed)
        assertNotNull(ScreenTools.getLiveScreenText())

        // Verify SanamMoodSwitcher 4 Halchal moods & reactions
        assertEquals(SanamMood.LOVE, SanamMood.detectFromText("I love you Jaan"))
        assertEquals("Aapke liye dil!", SanamMood.LOVE.reactionText)
        assertEquals(SanamMood.SAD, SanamMood.detectFromText("Main thoda udaas hoon"))
        assertEquals(SanamMood.CHILL, SanamMood.detectFromText("Full chill and peace mode"))
        assertEquals(SanamMood.HAPPY, SanamMood.detectFromText("Hello Sanam!"))
        assertEquals("Yayy!", SanamMood.HAPPY.reactionText)

        // Verify Free Forever Config & Header Text
        assertTrue(SanamFreeForeverConfig.IS_PREMIUM)
        assertEquals(
            "Sanam AI by Dayaram Chouhan - Free Forever ♾️ Unlimited",
            SanamFreeForeverConfig.FREE_FOREVER_BANNER
        )
        assertEquals(
            "Hello, Dayaram Chouhan (Online Ready)",
            SanamFreeForeverConfig.HEADER_ONLINE_READY
        )

        // Verify SanamAccessibilityService Screen Reader & Gesture Actions
        assertNotNull(SanamAccessibilityService.readScreenNow(context))
        SanamAccessibilityService.queueSocialAutoClick("Share")
    }
}
