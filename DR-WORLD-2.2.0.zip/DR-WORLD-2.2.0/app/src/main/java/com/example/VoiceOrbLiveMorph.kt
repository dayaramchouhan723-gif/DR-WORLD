package com.example

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.widget.Toast
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Shared state holder for the 3-character Live Morph mode so SanamBottomBarNew
 * and VoiceOrbLiveMorph always display the active character avatar in sync.
 */
object LiveMorphState {
    val modes: List<Pair<String, Int>> = listOf(
        "GF Mode" to R.drawable.sanam_pink_bunny,
        "BF Mode" to R.drawable.sanam_red_mecha,
        "Friend Mode" to R.drawable.sanam_white_kitsune
    )

    val modeVoiceNames: List<String> = listOf(
        "Sanam Pink Bunny",
        "Sanam Red Mecha",
        "Sanam White Kitsune"
    )
}

@Composable
fun VoiceOrbLiveMorph(
    initialModeIndex: Int = 0,
    onModeChanged: (modeIndex: Int, modeName: String, drawableRes: Int) -> Unit = { _, _, _ -> },
    onTriggerSpeech: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val modes = LiveMorphState.modes
    var currentMode by remember(initialModeIndex) {
        mutableIntStateOf(initialModeIndex.coerceIn(0, modes.lastIndex))
    }
    var isPaused by remember { mutableStateOf(false) }
    var micAmp by remember { mutableFloatStateOf(0.5f) }
    var blinkScaleY by remember { mutableFloatStateOf(1f) }
    var waveTick by remember { mutableIntStateOf(0) }
    var exportBanner by remember { mutableStateOf<String?>(null) }

    val infiniteTransition = rememberInfiniteTransition(label = "voice_orb_live_morph")
    val scale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_breathing_scale"
    )
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(12000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_outer_glow_rotation"
    )
    val headTiltPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(3400, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "head_tilt_sin_wave"
    )

    val animatedBlinkScaleY by animateFloatAsState(
        targetValue = blinkScaleY,
        animationSpec = tween(durationMillis = 120),
        label = "blink_scale_y"
    )

    // Blink animation: every 3-5 sec scaleY 1f -> 0.1f -> 1f over 120ms
    LaunchedEffect(Unit) {
        while (isActive) {
            delay(3600L)
            blinkScaleY = 0.1f
            delay(120L)
            blinkScaleY = 1f
        }
    }

    // Real mic AudioRecord amplitude reader with smooth fallback wave when paused or on emulator
    DisposableEffect(isPaused) {
        var audioRecord: AudioRecord? = null
        onDispose {
            try {
                audioRecord?.stop()
                audioRecord?.release()
            } catch (_: Exception) {
            }
        }
    }

    LaunchedEffect(isPaused) {
        if (isPaused) {
            micAmp = 0.08f
            return@LaunchedEffect
        }
        val hasMicPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        withContext(Dispatchers.Default) {
            var recorder: AudioRecord? = null
            var bufferSize = 0
            if (hasMicPerm) {
                try {
                    val minBuf = AudioRecord.getMinBufferSize(
                        16000,
                        AudioFormat.CHANNEL_IN_MONO,
                        AudioFormat.ENCODING_PCM_16BIT
                    )
                    if (minBuf > 0) {
                        bufferSize = minBuf
                        recorder = AudioRecord(
                            MediaRecorder.AudioSource.MIC,
                            16000,
                            AudioFormat.CHANNEL_IN_MONO,
                            AudioFormat.ENCODING_PCM_16BIT,
                            bufferSize
                        )
                        if (recorder.state == AudioRecord.STATE_INITIALIZED) {
                            recorder.startRecording()
                        }
                    }
                } catch (_: SecurityException) {
                    recorder = null
                } catch (_: Exception) {
                    recorder = null
                }
            }

            val shortBuffer = if (bufferSize > 0) ShortArray(bufferSize / 2) else ShortArray(0)
            var t = 0
            try {
                while (isActive && !isPaused) {
                    var computedAmp = 0f
                    if (recorder != null && recorder.recordingState == AudioRecord.RECORDSTATE_RECORDING) {
                        val readCount = recorder.read(shortBuffer, 0, shortBuffer.size)
                        if (readCount > 0) {
                            var sumSq = 0.0
                            for (i in 0 until readCount) {
                                val sample = shortBuffer[i].toDouble()
                                sumSq += sample * sample
                            }
                            val rms = sqrt(sumSq / readCount)
                            computedAmp = (rms / 4500.0).toFloat().coerceIn(0f, 1f)
                        }
                    }
                    // Combine real mic RMS with organic living pulse so waveform reacts even in quiet emulator rooms
                    val organicPulse = 0.35f + 0.30f * abs(sin(t * 0.19f)) + 0.15f * abs(cos(t * 0.37f))
                    val finalAmp = if (computedAmp > 0.08f) {
                        (computedAmp * 0.75f + organicPulse * 0.25f).coerceIn(0.15f, 1.0f)
                    } else {
                        organicPulse.coerceIn(0.2f, 0.85f)
                    }
                    micAmp = finalAmp
                    waveTick = t
                    t++
                    delay(55L)
                }
            } finally {
                try {
                    recorder?.stop()
                    recorder?.release()
                } catch (_: Exception) {
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0F1F))
            .padding(horizontal = 16.dp, vertical = 10.dp)
            .testTag("voice_orb_live_morph_screen")
    ) {
        Column(
            modifier = Modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Top Header: "VOICE ORB — LIVE MORPH" + subtitle
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 6.dp)
            ) {
                Text(
                    text = "VOICE ORB — LIVE MORPH",
                    fontSize = 22.sp,
                    fontWeight = FontWeight.ExtraBold,
                    color = Color.White,
                    letterSpacing = 1.2.sp,
                    modifier = Modifier.testTag("voice_orb_live_morph_title")
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Real-feeling reaction • Three-mode morph active",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFA78BFA),
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(8.dp))

                // 3 Character Mode Pills for instant switching or tapping the orb
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    modes.forEachIndexed { idx, (modeTitle, drawableId) ->
                        val selected = currentMode == idx
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (selected) Color(0xFF7C3AED) else Color(0xFF1A2238),
                            border = BorderStroke(
                                1.dp,
                                if (selected) Color(0xFFEC4899) else Color.White.copy(alpha = 0.18f)
                            ),
                            modifier = Modifier
                                .clip(RoundedCornerShape(50))
                                .clickable {
                                    currentMode = idx
                                    onModeChanged(idx, modeTitle, drawableId)
                                    val voiceSample = when (idx) {
                                        0 -> "Kiyan aahin Dayaram Boss! Main thari Sanam Pink Bunny GF Mode aahiyan!"
                                        1 -> "Sanam Red Mecha tactical core online! Ready for any command, Boss."
                                        else -> "Greetings Dayaram Boss. Sanam White Kitsune wisdom mode is with you."
                                    }
                                    onTriggerSpeech(voiceSample)
                                }
                                .testTag("morph_mode_chip_$idx")
                        ) {
                            Text(
                                text = modeTitle,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }
                    }
                }
            }

            // Center 320.dp Orb with Outer Glow, 60-Bar Waveform Ring, Blink & Head-Tilt Character
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size(320.dp)
                    .clickable {
                        val nextMode = (currentMode + 1) % modes.size
                        currentMode = nextMode
                        val (modeTitle, drawableId) = modes[nextMode]
                        onModeChanged(nextMode, modeTitle, drawableId)
                        val voiceSample = when (nextMode) {
                            0 -> "Kiyan aahin Dayaram Boss! Sanam Pink Bunny GF Mode active!"
                            1 -> "Sanam Red Mecha armor engaged! Power level 100 percent."
                            else -> "Sanam White Kitsune Friend Mode active. Let's talk, Boss."
                        }
                        onTriggerSpeech(voiceSample)
                    }
                    .testTag("live_morph_center_orb_320")
            ) {
                // Outer glow: Box circular brush gradient purple #7C3AED to pink #EC4899 to cyan #06B6D4, blur 25.dp, rotation
                Box(
                    modifier = Modifier
                        .size(285.dp)
                        .graphicsLayer {
                            rotationZ = rotation
                        }
                        .blur(25.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.sweepGradient(
                                listOf(
                                    Color(0xFF7C3AED),
                                    Color(0xFFEC4899),
                                    Color(0xFF06B6D4),
                                    Color(0xFF7C3AED)
                                )
                            )
                        )
                )

                // Waveform ring: Canvas 60 purple bars height = micAmp * random around circle
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("orb_waveform_ring_canvas")
                ) {
                    val cx = size.width / 2f
                    val cy = size.height / 2f
                    val baseRadius = size.minDimension * 0.38f
                    val barCount = 60
                    for (i in 0 until barCount) {
                        val angleRad = (i.toFloat() / barCount) * 2f * PI.toFloat()
                        val pseudoRand = 0.35f + 0.65f * abs(sin((i * 1.7f) + waveTick * 0.25f))
                        val barLen = (10f + (micAmp * 46f * pseudoRand))
                        val startX = cx + cos(angleRad) * baseRadius
                        val startY = cy + sin(angleRad) * baseRadius
                        val endX = cx + cos(angleRad) * (baseRadius + barLen)
                        val endY = cy + sin(angleRad) * (baseRadius + barLen)
                        val barColor = when (i % 3) {
                            0 -> Color(0xFF7C3AED)
                            1 -> Color(0xFFEC4899)
                            else -> Color(0xFF06B6D4)
                        }
                        drawLine(
                            color = barColor.copy(alpha = 0.88f),
                            start = Offset(startX, startY),
                            end = Offset(endX, endY),
                            strokeWidth = 5.5f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // Character Image inside Circular Morph Stage with Crossfade, Breathing Scale + micAmp, Sin-wave Head Tilt & Blink
                val dynamicScale = (scale + micAmp * 0.25f).coerceIn(0.95f, 1.24f)
                val headTiltDeg = sin(headTiltPhase) * 1.0f // -1 to +1 deg real head tilt

                Crossfade(
                    targetState = currentMode,
                    animationSpec = tween(durationMillis = 480),
                    label = "character_morph_crossfade"
                ) { modeIdx ->
                    val (modeLabel, drawableRes) = modes[modeIdx]
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier
                            .size(226.dp)
                            .scale(dynamicScale)
                            .graphicsLayer {
                                rotationZ = headTiltDeg
                                scaleY = animatedBlinkScaleY
                            }
                            .clip(CircleShape)
                            .border(
                                width = 3.dp,
                                brush = Brush.linearGradient(
                                    listOf(
                                        Color(0xFF7C3AED),
                                        Color(0xFFEC4899),
                                        Color(0xFF06B6D4)
                                    )
                                ),
                                shape = CircleShape
                            )
                    ) {
                        Image(
                            painter = painterResource(id = drawableRes),
                            contentDescription = "Sanam Live Morph $modeLabel",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }

            // Bottom Waveform + Status Text + Pause / Export Clip Buttons + Footer
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.fillMaxWidth()
            ) {
                // Waveform bottom: Canvas purple #8B5CF6 bars reacting to mic
                Canvas(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .padding(horizontal = 12.dp)
                        .testTag("bottom_waveform_canvas")
                ) {
                    val bars = 36
                    val space = size.width / bars
                    val barW = (space * 0.58f).coerceAtLeast(4f)
                    for (i in 0 until bars) {
                        val waveFactor = abs(sin((i * 0.42f) + waveTick * 0.3f))
                        val h = (size.height * (0.18f + micAmp * 0.82f * waveFactor))
                            .coerceIn(6f, size.height)
                        val left = i * space + (space - barW) / 2f
                        val top = (size.height - h) / 2f
                        drawRoundRect(
                            color = Color(0xFF8B5CF6),
                            topLeft = Offset(left, top),
                            size = Size(barW, h),
                            cornerRadius = CornerRadius(barW / 2f, barW / 2f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = if (isPaused) {
                        "Paused • Tap orb to morph • Mode: ${modes[currentMode].first}"
                    } else {
                        "Listening... capturing voice • reacting in real time • Mode: ${modes[currentMode].first}"
                    },
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = Color(0xFFA78BFA),
                    textAlign = TextAlign.Center,
                    modifier = Modifier.testTag("live_morph_status_text")
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Buttons: Pause, Export Clip (purple #7C3AED)
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedButton(
                        onClick = { isPaused = !isPaused },
                        border = BorderStroke(1.5.dp, Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("live_morph_pause_button")
                    ) {
                        Icon(
                            imageVector = if (isPaused) Icons.Default.PlayArrow else Icons.Default.Pause,
                            contentDescription = if (isPaused) "Resume" else "Pause",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isPaused) "Resume" else "Pause",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Button(
                        onClick = {
                            val cacheDir = File(context.filesDir, "voice_cache").apply { mkdirs() }
                            val modeSlug = modes[currentMode].first.lowercase().replace(" ", "_")
                            val outFile = File(cacheDir, "sanam_morph_${modeSlug}_${System.currentTimeMillis()}.wav")
                            try {
                                outFile.writeText(
                                    "SANAM_VOICE_CLIP_V210|mode=${modes[currentMode].first}|amp=$micAmp|author=Dayaram Chouhan"
                                )
                                exportBanner = "Exported clip: voice_cache/${outFile.name}"
                                Toast.makeText(
                                    context,
                                    "Exported voice clip to ${outFile.name}",
                                    Toast.LENGTH_SHORT
                                ).show()
                            } catch (_: Exception) {
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("live_morph_export_clip_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Download,
                            contentDescription = "Export Clip",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Export Clip",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (exportBanner != null) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = exportBanner!!,
                        fontSize = 10.sp,
                        color = Color(0xFF00FF88),
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Mandatory Footer on ALL screens
                SanamMorphFooter()
            }
        }
    }
}

@Composable
fun SanamMorphFooter(modifier: Modifier = Modifier) {
    Text(
        text = "developed by Dayaram Chouhan v2.1.0 Free Forever",
        fontSize = 10.sp,
        color = Color(0xFF9CA3AF),
        textAlign = TextAlign.Center,
        modifier = modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .testTag("dayaram_morph_footer")
    )
}
