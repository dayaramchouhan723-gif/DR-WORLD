package com.example

import androidx.annotation.DrawableRes
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlin.math.PI
import kotlin.math.roundToInt
import kotlin.math.sin

/**
 * 4 Dynamic Moods for Sanam AI Full Body with Halchal (motion + Canvas particles + reactions)
 * All 4 moods use R.drawable.sanam_full_body as requested.
 */
enum class SanamMood(
    val title: String,
    val reactionText: String,
    val primaryColor: Color,
    val secondaryColor: Color,
    @DrawableRes val portraitRes: Int
) {
    HAPPY(
        title = "Happy",
        reactionText = "Yayy!",
        primaryColor = Color(0xFF00F0FF),
        secondaryColor = Color(0xFF00E676),
        portraitRes = R.drawable.sanam_full_body
    ),
    SAD(
        title = "Sad",
        reactionText = "Thoda udaas hoon...",
        primaryColor = Color(0xFF5C7CFA),
        secondaryColor = Color(0xFF38BDF8),
        portraitRes = R.drawable.sanam_full_body
    ),
    LOVE(
        title = "Love",
        reactionText = "Aapke liye dil!",
        primaryColor = Color(0xFFFF2A85),
        secondaryColor = Color(0xFFFF758F),
        portraitRes = R.drawable.sanam_full_body
    ),
    CHILL(
        title = "Chill",
        reactionText = "Full Chill & Peace!",
        primaryColor = Color(0xFFA855F7),
        secondaryColor = Color(0xFF00F0FF),
        portraitRes = R.drawable.sanam_full_body
    );

    companion object {
        fun detectFromText(text: String): SanamMood {
            val lower = text.lowercase()
            return when {
                listOf(
                    "love", "pyar", "jaan", "jaanu", "dil", "ishq",
                    "sajjan", "shy", "sharam", "kiss", "hug", "sweet", "aapke liye dil"
                ).any { lower.contains(it) } -> LOVE

                listOf(
                    "sad", "sorry", "udaas", "dukh", "alone", "lonely",
                    "cry", "rona", "afsos", "hurt"
                ).any { lower.contains(it) } -> SAD

                listOf(
                    "chill", "relax", "cool", "peace", "music", "vibe",
                    "game", "gaming", "wink", "dost"
                ).any { lower.contains(it) } -> CHILL

                else -> HAPPY
            }
        }
    }
}

/**
 * SanamMoodSwitcher - Full-Body Halchal Animated Character (No small 120.dp CircleShape box!)
 *
 * Uses R.drawable.sanam_full_body with ContentScale.Fit + Modifier.graphicsLayer for:
 * - Infinite breathing (0.98f to 1.02f)
 * - 1) Happy: bounce scale 0.98f to 1.05f (600ms) + eyes sparkle particle Canvas + "Yayy!"
 * - 2) Sad: head tilt 5deg, alpha 0.8f, slow breathing 0.99f + teardrop Canvas
 * - 3) Love: 5 pink hearts Canvas moving up Y -100 infinitely + scale pulse 1f to 1.1f (500ms) + "Aapke liye dil!"
 * - 4) Chill: wink animation (right eye height 24.dp to 2.dp every 2 sec) + peace hand rotation 0-10deg + wind hair offset
 */
@Composable
fun SanamMoodSwitcher(
    mood: SanamMood,
    onMoodChange: (SanamMood) -> Unit,
    isSpeaking: Boolean = false,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sanam_full_body_halchal")

    // Base infinite breathing animation: 0.98f to 1.02f infinite
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "full_body_breathing"
    )

    // 1. HAPPY: bounce scale 0.98f to 1.05f, 600ms + sparkle phase
    val happyBounce by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 600, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "happy_bounce_scale"
    )
    val sparklePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 900, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "happy_sparkle_phase"
    )

    // 2. SAD: tilt 5 deg, alpha 0.8f, slow breathing scale 0.99f
    val sadTilt by animateFloatAsState(
        targetValue = if (mood == SanamMood.SAD) 5f else 0f,
        animationSpec = tween(durationMillis = 600, easing = FastOutSlowInEasing),
        label = "sad_tilt_deg"
    )
    val sadAlpha by animateFloatAsState(
        targetValue = if (mood == SanamMood.SAD) 0.8f else 1f,
        animationSpec = tween(durationMillis = 500),
        label = "sad_alpha"
    )
    val sadBreathingScale by infiniteTransition.animateFloat(
        initialValue = 0.97f,
        targetValue = 0.99f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "sad_slow_breathing"
    )

    // 3. LOVE: 5 pink hearts moving up Y -100 infinitely + heart pulse scale 1f to 1.1f (500ms)
    val lovePulse by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "love_heart_pulse"
    )
    val floatingHeartProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 2200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "love_floating_hearts_y"
    )

    // 4. CHILL: wink animation - right eye height 24.dp to 2.dp every 2 sec, peace hand rotation 0 to 10 deg, wind hair offset
    var isChillWinking by remember { mutableStateOf(false) }
    LaunchedEffect(mood) {
        while (true) {
            delay(2000L)
            isChillWinking = true
            delay(220L)
            isChillWinking = false
        }
    }
    val rightEyeHeightDp by animateFloatAsState(
        targetValue = if (mood == SanamMood.CHILL && isChillWinking) 2f else 24f,
        animationSpec = tween(durationMillis = 150, easing = FastOutSlowInEasing),
        label = "chill_wink_eye_height"
    )
    val peaceHandRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 10f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chill_peace_rotation"
    )
    val windHairOffset by infiniteTransition.animateFloat(
        initialValue = -6f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1100, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "chill_wind_hair_offset"
    )

    // Extra speaking bounce when Sanam's 16yo girl TTS voice is speaking
    val speakingJitter by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isSpeaking) 1.03f else 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 220, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "speaking_jitter"
    )

    val borderGlowColor by animateColorAsState(
        targetValue = mood.primaryColor,
        animationSpec = tween(durationMillis = 400),
        label = "mood_border_color"
    )

    // Combined dynamic graphicsLayer values per mood (incorporating breathing 0.98f..1.02f)
    val activeScale = when (mood) {
        SanamMood.HAPPY -> happyBounce * speakingJitter
        SanamMood.SAD -> sadBreathingScale
        SanamMood.LOVE -> lovePulse * speakingJitter
        SanamMood.CHILL -> breathingScale * speakingJitter
    }
    val activeRotation = when (mood) {
        SanamMood.SAD -> sadTilt
        SanamMood.CHILL -> windHairOffset * 0.35f
        else -> 0f
    }
    val activeTranslationX = when (mood) {
        SanamMood.CHILL -> windHairOffset
        else -> 0f
    }
    val activeTranslationY = when (mood) {
        SanamMood.HAPPY -> (1f - happyBounce) * 75f
        SanamMood.SAD -> 8f
        else -> 0f
    }

    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clickable {
                val nextIndex = (mood.ordinal + 1) % SanamMood.entries.size
                onMoodChange(SanamMood.entries[nextIndex])
            }
            .testTag("sanam_mood_switcher_root")
    ) {
        // Full-Body Aura Glow Behind Standing Sanam
        Canvas(modifier = Modifier.fillMaxSize()) {
            val center = Offset(size.width / 2f, size.height * 0.48f)
            val radius = (size.minDimension / 2f) * 0.92f
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        mood.primaryColor.copy(alpha = 0.32f),
                        mood.secondaryColor.copy(alpha = 0.12f),
                        Color.Transparent
                    ),
                    center = center,
                    radius = radius * activeScale
                ),
                radius = radius * activeScale,
                center = center
            )
        }

        // MAIN FULL BODY GIRL (R.drawable.sanam_full_body, ContentScale.Fit, Modifier.graphicsLayer for breathing + 4-mood halchal)
        Image(
            painter = painterResource(id = R.drawable.sanam_full_body),
            contentDescription = "Sanam AI Full Body (${mood.title})",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer {
                    scaleX = activeScale
                    scaleY = activeScale
                    rotationZ = activeRotation
                    alpha = sadAlpha
                    translationX = activeTranslationX
                    translationY = activeTranslationY
                }
                .testTag("sanam_full_body_image")
        )

        // 4-Mood Halchal Particle & Expression Canvas Overlay on Full Body
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .testTag("sanam_halchal_canvas")
        ) {
            val w = size.width
            val h = size.height
            val cx = w / 2f
            val headCy = h * 0.22f

            when (mood) {
                SanamMood.HAPPY -> {
                    // 1) HAPPY: Eyes sparkle particle Canvas (twinkling 4-point star sparkles around head & shoulders)
                    val sparklePositions = listOf(
                        Offset(cx - w * 0.06f, headCy - h * 0.02f),
                        Offset(cx + w * 0.06f, headCy - h * 0.02f),
                        Offset(cx - w * 0.24f, headCy - h * 0.08f),
                        Offset(cx + w * 0.25f, headCy - h * 0.06f),
                        Offset(cx - w * 0.22f, headCy + h * 0.12f),
                        Offset(cx + w * 0.23f, headCy + h * 0.10f)
                    )
                    sparklePositions.forEachIndexed { index, pos ->
                        val localScale = 0.55f + 0.65f * sin((sparklePhase + index * 0.18f) * PI.toFloat())
                        val starRadius = (8.dp.toPx() * localScale).coerceAtLeast(2f)
                        val starColor = if (index % 2 == 0) Color(0xFFFFF59D) else Color(0xFF00F0FF)

                        drawCircle(
                            color = starColor.copy(alpha = 0.45f),
                            radius = starRadius * 1.4f,
                            center = pos
                        )
                        drawLine(
                            color = Color.White,
                            start = Offset(pos.x - starRadius, pos.y),
                            end = Offset(pos.x + starRadius, pos.y),
                            strokeWidth = 2.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color.White,
                            start = Offset(pos.x, pos.y - starRadius),
                            end = Offset(pos.x, pos.y + starRadius),
                            strokeWidth = 2.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }

                SanamMood.SAD -> {
                    // 2) SAD: Teardrop droplets falling gently near face
                    val tearOffsets = listOf(
                        Offset(cx - w * 0.05f, headCy + sparklePhase * 16.dp.toPx()),
                        Offset(cx + w * 0.05f, headCy + 4.dp.toPx() + ((sparklePhase + 0.5f) % 1f) * 16.dp.toPx())
                    )
                    tearOffsets.forEach { tearPos ->
                        drawOval(
                            color = Color(0xFF7DD3FC).copy(alpha = 0.85f),
                            topLeft = tearPos,
                            size = Size(5.dp.toPx(), 8.5.dp.toPx())
                        )
                    }
                }

                SanamMood.LOVE -> {
                    // 3) LOVE: 5 pink hearts Canvas moving up Y -100, infinite
                    val heartXFractions = listOf(0.24f, 0.36f, 0.50f, 0.64f, 0.76f)
                    val heartPhaseOffsets = listOf(0.0f, 0.22f, 0.45f, 0.67f, 0.85f)
                    val heartColors = listOf(
                        Color(0xFFFF2A85),
                        Color(0xFFFF5C9E),
                        Color(0xFFFF1744),
                        Color(0xFFFF758F),
                        Color(0xFFFF4081)
                    )

                    for (i in 0 until 5) {
                        val progress = (floatingHeartProgress + heartPhaseOffsets[i]) % 1f
                        val travelDistancePx = 100.dp.toPx()
                        val startY = h * 0.58f
                        val currentY = startY - (progress * travelDistancePx)
                        val swayX = sin((progress * 2f * PI + i).toFloat()) * 10.dp.toPx()
                        val currentX = (w * heartXFractions[i]) + swayX
                        val heartAlpha = (1f - progress * 0.82f).coerceIn(0.18f, 1f)
                        val heartRadius = (9.dp.toPx() * (0.85f + 0.35f * (1f - progress)))

                        val heartCenter = Offset(currentX, currentY)
                        drawCircle(
                            color = heartColors[i].copy(alpha = heartAlpha * 0.35f),
                            radius = heartRadius * 1.5f,
                            center = heartCenter
                        )
                        val heartPath = Path().apply {
                            val s = heartRadius
                            moveTo(heartCenter.x, heartCenter.y + s * 0.65f)
                            cubicTo(
                                heartCenter.x - s * 1.2f, heartCenter.y - s * 0.1f,
                                heartCenter.x - s * 0.65f, heartCenter.y - s * 1.1f,
                                heartCenter.x, heartCenter.y - s * 0.35f
                            )
                            cubicTo(
                                heartCenter.x + s * 0.65f, heartCenter.y - s * 1.1f,
                                heartCenter.x + s * 1.2f, heartCenter.y - s * 0.1f,
                                heartCenter.x, heartCenter.y + s * 0.65f
                            )
                            close()
                        }
                        drawPath(
                            path = heartPath,
                            color = heartColors[i].copy(alpha = heartAlpha)
                        )
                    }
                }

                SanamMood.CHILL -> {
                    // 4) CHILL:
                    // - Right eye wink animation (height 24.dp to 2.dp every 2 sec)
                    // - Wind hair offset strands
                    // - Peace hand rotation (0 to 10 deg)
                    val rightEyeCenter = Offset(cx + w * 0.05f, headCy - h * 0.01f)
                    val eyeW = 16.dp.toPx()
                    val eyeH = (rightEyeHeightDp * 0.45f).dp.toPx().coerceAtLeast(2.dp.toPx())

                    if (rightEyeHeightDp < 10f) {
                        drawArc(
                            color = Color(0xFF00F0FF),
                            startAngle = 10f,
                            sweepAngle = 160f,
                            useCenter = false,
                            topLeft = Offset(rightEyeCenter.x - eyeW / 2f, rightEyeCenter.y - eyeH / 2f),
                            size = Size(eyeW, eyeH),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    } else {
                        drawRoundRect(
                            color = Color(0xFF00F0FF).copy(alpha = 0.55f),
                            topLeft = Offset(rightEyeCenter.x - eyeW / 2f, rightEyeCenter.y - eyeH / 2f),
                            size = Size(eyeW, eyeH),
                            cornerRadius = CornerRadius(eyeW / 2f, eyeW / 2f),
                            style = Stroke(width = 1.5.dp.toPx())
                        )
                    }

                    // Wind hair strands moving with windHairOffset
                    val windPx = windHairOffset.dp.toPx()
                    for (strand in 0..2) {
                        val strandY = headCy - h * (0.04f - strand * 0.05f)
                        val hairPath = Path().apply {
                            moveTo(cx + w * 0.12f, strandY)
                            quadraticTo(
                                cx + w * 0.24f + windPx * 1.4f,
                                strandY - 8.dp.toPx() + windPx * 0.5f,
                                cx + w * 0.32f + windPx * 2.0f,
                                strandY + 4.dp.toPx()
                            )
                        }
                        drawPath(
                            path = hairPath,
                            color = Color(0xFFFF758F).copy(alpha = 0.8f),
                            style = Stroke(width = 2.5.dp.toPx(), cap = StrokeCap.Round)
                        )
                    }

                    // Peace hand vector rotating 0 to 10 deg
                    val peaceCenter = Offset(cx + w * 0.22f, headCy + h * 0.14f)
                    rotate(degrees = peaceHandRotation, pivot = peaceCenter) {
                        drawCircle(
                            color = Color(0xFF15192B).copy(alpha = 0.9f),
                            radius = 14.dp.toPx(),
                            center = peaceCenter
                        )
                        drawCircle(
                            color = Color(0xFF00F0FF),
                            radius = 14.dp.toPx(),
                            center = peaceCenter,
                            style = Stroke(width = 1.8.dp.toPx())
                        )
                        val palmCenter = Offset(peaceCenter.x, peaceCenter.y + 4.dp.toPx())
                        drawCircle(
                            color = Color(0xFFFFDFD0),
                            radius = 5.dp.toPx(),
                            center = palmCenter
                        )
                        drawLine(
                            color = Color(0xFFFFDFD0),
                            start = palmCenter,
                            end = Offset(peaceCenter.x - 4.5.dp.toPx(), peaceCenter.y - 7.dp.toPx()),
                            strokeWidth = 3.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = Color(0xFFFFDFD0),
                            start = palmCenter,
                            end = Offset(peaceCenter.x + 4.5.dp.toPx(), peaceCenter.y - 7.dp.toPx()),
                            strokeWidth = 3.2.dp.toPx(),
                            cap = StrokeCap.Round
                        )
                    }
                }
            }
        }

        // Floating Reaction Badge near top-right of character
        Surface(
            shape = RoundedCornerShape(50),
            color = Color(0xFF0E1324).copy(alpha = 0.92f),
            border = BorderStroke(1.dp, borderGlowColor),
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 8.dp, end = 12.dp)
                .offset {
                    IntOffset(
                        x = 0,
                        y = (activeTranslationY * 0.25f).roundToInt()
                    )
                }
                .testTag("sanam_mood_reaction_badge")
        ) {
            Text(
                text = mood.reactionText,
                style = MaterialTheme.typography.labelSmall,
                color = borderGlowColor,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

/**
 * OrbView (65.dp on waist video)
 */
@Composable
fun OrbView(
    auraTheme: com.example.ui.theme.AuraTheme,
    orbStyle: com.example.ui.theme.OrbStyle,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .clip(CircleShape)
            .clickable { onClick() }
            .testTag("sanam_waist_orb_view")
    ) {
        MyraAnimatedOrbCanvas(
            auraTheme = auraTheme,
            orbStyle = orbStyle,
            isActive = isActive,
            modifier = Modifier.fillMaxSize()
        )
        Icon(
            imageVector = if (isActive) Icons.Default.GraphicEq else Icons.Default.AutoAwesome,
            contentDescription = "DR WORLD Waist Orb",
            tint = Color.White,
            modifier = Modifier.size(22.dp)
        )
    }
}

/**
 * TapToSpeakButton - Positioned below the waist Orb
 * Triggers VoiceController.startListening() directly in-app (NO GOOGLE OPEN!)
 */
@Composable
fun TapToSpeakButton(
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(50),
        color = Color(0xFF0A1122).copy(alpha = 0.92f),
        border = BorderStroke(
            width = 1.8.dp,
            brush = Brush.horizontalGradient(
                listOf(Color(0xFF00FF88), Color(0xFF00F0FF), Color(0xFFFF2A85))
            )
        ),
        modifier = modifier
            .clip(RoundedCornerShape(50))
            .clickable { onClick() }
            .testTag("tap_to_speak_button")
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
            modifier = Modifier.padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Icon(
                imageVector = when {
                    isListening -> Icons.Default.GraphicEq
                    isSpeaking -> Icons.Default.GraphicEq
                    isThinking -> Icons.Default.AutoAwesome
                    else -> Icons.Default.Mic
                },
                contentDescription = "Tap to Speak",
                tint = Color(0xFF00FF88),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = when {
                    isListening -> "LISTENING TO BOSS..."
                    isSpeaking -> "SANAM SPEAKING..."
                    isThinking -> "SANAM THINKING..."
                    else -> "TAP TO SPEAK"
                },
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}
