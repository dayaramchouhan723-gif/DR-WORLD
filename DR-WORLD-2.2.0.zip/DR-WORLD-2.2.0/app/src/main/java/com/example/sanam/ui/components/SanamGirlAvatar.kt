package com.example.sanam.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.example.SanamEmotion
import com.example.ui.theme.AuraTheme
import kotlin.math.PI
import kotlin.math.sin

/**
 * SecondaryWaveAnimationLayer (from Sanam-ai JARVIS v1.0)
 * Renders a multi-harmonic sine wave visualizer across the bottom of the companion header.
 */
@Composable
fun SecondaryWaveAnimationLayer(
    auraTheme: AuraTheme,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "secondary_wave_anim")
    val phase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isActive) 900 else 2800, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "wave_phase"
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp)
    ) {
        val width = size.width
        val midY = size.height / 2f
        val amp = if (isActive) size.height * 0.42f else size.height * 0.16f

        val path1 = Path()
        val path2 = Path()
        val steps = 64
        for (i in 0..steps) {
            val x = (i.toFloat() / steps) * width
            val norm = (i.toFloat() / steps) * 4f * PI.toFloat()
            val y1 = midY + sin(norm + phase) * amp
            val y2 = midY + sin(norm - phase * 1.3f + 1.2f) * (amp * 0.7f)
            if (i == 0) {
                path1.moveTo(x, y1)
                path2.moveTo(x, y2)
            } else {
                path1.lineTo(x, y1)
                path2.lineTo(x, y2)
            }
        }

        drawPath(
            path = path1,
            brush = Brush.horizontalGradient(listOf(auraTheme.primary, auraTheme.secondary, auraTheme.primary)),
            style = Stroke(width = 2.5.dp.toPx())
        )
        drawPath(
            path = path2,
            color = auraTheme.secondary.copy(alpha = 0.55f),
            style = Stroke(width = 1.5.dp.toPx())
        )
    }
}
