package com.example

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material.icons.filled.Security
import com.example.sanam.controller.AppLauncher
import com.example.sanam.controller.CallHelper
import com.example.sanam.controller.DeviceActionManager
import com.example.sanam.controller.SmsHelper
import com.example.sanam.ui.SanamBottomBarNew
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.theme.SanamAiTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val sanamViewModel: SanamViewModel = viewModel()
            val selectedAura by sanamViewModel.selectedAura.collectAsStateWithLifecycle()

            var showMkKing by remember { mutableStateOf(false) }

            SanamAiTheme(auraTheme = selectedAura) {
                if (showMkKing) {
                    com.example.mkking.MkKingApp(onExit = { showMkKing = false })
                } else {
                    Box(modifier = Modifier.fillMaxSize()) {
                        SanamMainScreen(
                            activity = this@MainActivity,
                            viewModel = sanamViewModel
                        )
                        com.example.mkking.MkKingEntryButton(
                            onClick = { showMkKing = true },
                            modifier = Modifier.align(androidx.compose.ui.Alignment.TopEnd)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SanamMainScreen(
    activity: Activity,
    viewModel: SanamViewModel
) {
    val context = LocalContext.current
    val auraTheme by viewModel.selectedAura.collectAsStateWithLifecycle()
    val orbStyle by viewModel.selectedOrbStyle.collectAsStateWithLifecycle()
    val selectedLanguage by viewModel.selectedLanguage.collectAsStateWithLifecycle()
    val selectedMode by viewModel.selectedMode.collectAsStateWithLifecycle()
    val isListening by viewModel.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.isSpeaking.collectAsStateWithLifecycle()
    val isThinking by viewModel.isThinking.collectAsStateWithLifecycle()
    val telemetry by viewModel.telemetry.collectAsStateWithLifecycle()
    val statusBanner by viewModel.lastStatusBanner.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val conversationSessions by viewModel.conversationSessions.collectAsStateWithLifecycle()
    val activeSessionId by viewModel.activeSessionId.collectAsStateWithLifecycle()
    val triggersAndMissions by viewModel.triggersAndMissions.collectAsStateWithLifecycle()
    val memories by viewModel.memories.collectAsStateWithLifecycle()
    val screenLogs by viewModel.screenLogs.collectAsStateWithLifecycle()
    val liveScreenStream by viewModel.liveScreenStream.collectAsStateWithLifecycle()
    val selectedImageBitmap by viewModel.selectedImageBitmap.collectAsStateWithLifecycle()
    val isMediaProjectionActive by viewModel.isMediaProjectionActive.collectAsStateWithLifecycle()
    val visualTelemetry by viewModel.latestVisualTelemetry.collectAsStateWithLifecycle()
    val latestVisualLensAnalysis by viewModel.latestVisualLensAnalysis.collectAsStateWithLifecycle()
    val touchGuardLocked by viewModel.touchGuardLocked.collectAsStateWithLifecycle()
    val myraSecurityArmed by viewModel.myraSecurityArmed.collectAsStateWithLifecycle()
    val gamingBoostActive by viewModel.gamingBoostActive.collectAsStateWithLifecycle()
    val voicePitch by viewModel.voicePitch.collectAsStateWithLifecycle()
    val voiceSpeed by viewModel.voiceSpeed.collectAsStateWithLifecycle()
    val currentMorphModeIndex by viewModel.currentMorphModeIndex.collectAsStateWithLifecycle()
    val wakeWordOpenMorphCounter by viewModel.wakeWordOpenMorphCounter.collectAsStateWithLifecycle()
    val selectedConnector by viewModel.selectedConnector.collectAsStateWithLifecycle()
    val automationState by viewModel.automationPermissions.collectAsStateWithLifecycle()

    val proximityNear by viewModel.securityManager.proximityNear.collectAsStateWithLifecycle()
    val motionDelta by viewModel.securityManager.motionDelta.collectAsStateWithLifecycle()
    val securityAlerts by viewModel.securityManager.securityAlertCount.collectAsStateWithLifecycle()

    var currentTab by remember { mutableIntStateOf(1) } // Default to HOME tab (Exact MYRA UI)
    var homeResetTrigger by remember { mutableIntStateOf(0) }
    var settingsInitialSubScreen by remember { mutableStateOf<String?>(null) }
    var userInput by remember { mutableStateOf("") }
    var showQuickTriggerDialog by remember { mutableStateOf(false) }
    var quickDialogIsMission by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(wakeWordOpenMorphCounter) {
        if (wakeWordOpenMorphCounter > 0) {
            currentTab = 4
        }
    }

    // Back navigation handler for secondary tabs & Touch Guard
    BackHandler(enabled = touchGuardLocked || currentTab != 1) {
        if (touchGuardLocked) {
            viewModel.toggleTouchGuard(false)
        } else {
            currentTab = 1
        }
    }

    // Runtime Permission Launchers
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    fun hasPerm(perm: String): Boolean {
        return ContextCompat.checkSelfPermission(context, perm) == PackageManager.PERMISSION_GRANTED
    }

    fun requestCorePermissionsIfNeeded() {
        val perms = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.SEND_SMS,
            Manifest.permission.CAMERA
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            perms.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        permissionLauncher.launch(perms.toTypedArray())
    }

    fun startVoiceRecognition() {
        if (!hasPerm(Manifest.permission.RECORD_AUDIO)) {
            requestCorePermissionsIfNeeded()
        }
        viewModel.startInAppVoiceListening(
            hasCallPermission = hasPerm(Manifest.permission.CALL_PHONE),
            hasSmsPermission = hasPerm(Manifest.permission.SEND_SMS)
        )
    }

    // Zero-Permission Android Photo Picker Launcher
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            viewModel.onImagePickedFromUri(context, uri)
        }
    }

    // Camera Capture Preview Launcher
    val cameraLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.TakePicturePreview()
    ) { bitmap ->
        if (bitmap != null) {
            viewModel.onCameraBitmapCaptured(context, bitmap)
        }
    }

    var pendingProjectionPrompt by remember { mutableStateOf<String?>(null) }

    // MediaProjection Screen Capture Permission Launcher -> starts MediaProjectionService
    val mediaProjectionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        viewModel.onMediaProjectionPermissionResult(
            context = context,
            activity = activity,
            resultCode = result.resultCode,
            data = result.data,
            customPrompt = pendingProjectionPrompt
        )
    }

    fun triggerFullScreenMediaProjection(customPrompt: String? = null) {
        pendingProjectionPrompt = customPrompt
        if (isMediaProjectionActive) {
            viewModel.captureFrameFromActiveProjectionOrWindow(activity, customPrompt)
        } else {
            val intent = ScreenshotHelper.createMediaProjectionIntent(context)
            if (intent != null) {
                mediaProjectionLauncher.launch(intent)
            } else {
                viewModel.takeScreenshotAction(activity, analyzeWithAi = true)
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        auraTheme.background,
                        auraTheme.surface,
                        auraTheme.background
                    )
                )
            )
    ) {
        Scaffold(
            containerColor = Color.Transparent,
            contentWindowInsets = WindowInsets.safeDrawing,
            bottomBar = {
                SanamBottomBarNew(
                    currentTab = currentTab,
                    currentMorphModeIndex = currentMorphModeIndex,
                    onSelectTab = { index ->
                        HapticHelper.tick(context, automationState.hapticFeedbackEnabled)
                        if (index == 1) {
                            homeResetTrigger += 1
                        }
                        if (index == 3) {
                            settingsInitialSubScreen = null
                        }
                        currentTab = index
                    },
                    onOpenVoiceOrbLiveMorph = {
                        HapticHelper.tick(context, automationState.hapticFeedbackEnabled)
                        currentTab = 4
                        if (hasPerm(Manifest.permission.RECORD_AUDIO)) {
                            viewModel.startInAppVoiceListening(
                                hasCallPermission = hasPerm(Manifest.permission.CALL_PHONE),
                                hasSmsPermission = hasPerm(Manifest.permission.SEND_SMS)
                            )
                        }
                    }
                )
            }
        ) { innerPadding ->
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // Main Content Area based on the 5 MYRA Bottom Nav Tabs:
                // 0 = Chat | 1 = Home | 2 = Assistant | 3 = Settings | 4 = VoiceOrbLiveMorph
                Box(modifier = Modifier.weight(1f)) {
                    when (currentTab) {
                        0 -> CompanionChatTab(
                            auraTheme = auraTheme,
                            selectedMode = selectedMode,
                            selectedLanguage = selectedLanguage,
                            messages = messages,
                            conversationSessions = conversationSessions,
                            activeSessionId = activeSessionId,
                            userInput = userInput,
                            onUserInputChange = { userInput = it },
                            onModeSelect = { viewModel.selectMode(it) },
                            onContinueLastConversation = { viewModel.continueLastConversation() },
                            onStartNewConversation = { viewModel.startNewConversationSession() },
                            onSelectConversationSession = { viewModel.resumeConversationSession(it) },
                            onSendMessage = {
                                if (userInput.isNotBlank()) {
                                    viewModel.sendUserCommandOrMessage(
                                        context = context,
                                        input = userInput,
                                        hasCallPermission = hasPerm(Manifest.permission.CALL_PHONE),
                                        hasSmsPermission = hasPerm(Manifest.permission.SEND_SMS)
                                    )
                                    userInput = ""
                                }
                            },
                            onVoiceClick = { startVoiceRecognition() },
                            onQuickPrompt = { promptText ->
                                viewModel.sendUserCommandOrMessage(
                                    context = context,
                                    input = promptText,
                                    hasCallPermission = hasPerm(Manifest.permission.CALL_PHONE),
                                    hasSmsPermission = hasPerm(Manifest.permission.SEND_SMS)
                                )
                            },
                            onSpeakMessage = { viewModel.speakText(it) },
                            onClearChat = { viewModel.clearChatHistory() }
                        )

                        1 -> MyraExactHomeTab(
                            activity = activity,
                            viewModel = viewModel,
                            auraTheme = auraTheme,
                            selectedLanguage = selectedLanguage,
                            conversationSessions = conversationSessions,
                            messages = messages,
                            hasCallPermission = hasPerm(Manifest.permission.CALL_PHONE),
                            hasSmsPermission = hasPerm(Manifest.permission.SEND_SMS),
                            homeResetTrigger = homeResetTrigger,
                            onOpenChatTab = { currentTab = 0 },
                            onOpenAssistantTab = { currentTab = 2 },
                            onOpenVoiceOrbLiveMorph = { currentTab = 4 },
                            onOpenSettingsTab = { subScreen ->
                                settingsInitialSubScreen = subScreen
                                currentTab = 3
                            },
                            onStartVoiceListening = { startVoiceRecognition() },
                            onOpenQuickTriggerDialog = { isMission ->
                                quickDialogIsMission = isMission
                                showQuickTriggerDialog = true
                            },
                            subPanelContent = { activeSubPanel, _ ->
                                when (activeSubPanel) {
                                    1 -> SocialAndJarvisPanel(
                                        auraTheme = auraTheme,
                                        selectedLanguage = selectedLanguage,
                                        selectedImageBitmap = selectedImageBitmap,
                                        telemetry = telemetry,
                                        onPickGalleryPhoto = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onCaptureCamera = {
                                            if (hasPerm(Manifest.permission.CAMERA)) {
                                                cameraLauncher.launch(null)
                                            } else {
                                                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                                            }
                                        },
                                        onGenerateSocialCard = { caption ->
                                            viewModel.generateSocialPreviewCard(context, caption)
                                        },
                                        onPostInsta = { caption ->
                                            viewModel.postToInstagramAction(context, caption)
                                        },
                                        onPostFb = { caption ->
                                            viewModel.postToFacebookAction(context, caption)
                                        },
                                        onShareWhatsAppStatus = { caption ->
                                            viewModel.shareOnWhatsAppStatusAction(context, caption)
                                        },
                                        onSendWhatsAppMessage = { contact, msg ->
                                            DeviceActionManager.executeWhatsAppMessage(context, contact, msg)
                                        },
                                        onMakeCall = { contact ->
                                            DeviceActionManager.executeCall(
                                                context,
                                                contact,
                                                hasPerm(Manifest.permission.CALL_PHONE)
                                            )
                                        },
                                        onSendSms = { contact, msg ->
                                            DeviceActionManager.executeSms(
                                                context,
                                                contact,
                                                msg,
                                                hasPerm(Manifest.permission.SEND_SMS)
                                            )
                                        },
                                        onOpenMaps = { place ->
                                            viewModel.openMapsAction(context, place)
                                        },
                                        onToggleFlashlight = {
                                            viewModel.toggleFlashlightAction(context)
                                        },
                                        onAdjustVolume = { inc ->
                                            viewModel.adjustVolumeAction(context, inc)
                                        },
                                        onLaunchApp = { appName ->
                                            DeviceActionManager.executeLaunchApp(context, appName)
                                        }
                                    )

                                    2 -> VisualLensAndScreenPanel(
                                        auraTheme = auraTheme,
                                        selectedLanguage = selectedLanguage,
                                        selectedImageBitmap = selectedImageBitmap,
                                        isMediaProjectionActive = isMediaProjectionActive,
                                        visualTelemetry = visualTelemetry,
                                        latestVisualLensAnalysis = latestVisualLensAnalysis,
                                        liveScreenStream = liveScreenStream,
                                        screenLogs = screenLogs,
                                        onTakeScreenshot = {
                                            viewModel.takeScreenshotAction(activity, analyzeWithAi = true)
                                        },
                                        onRequestMediaProjection = { prompt ->
                                            triggerFullScreenMediaProjection(prompt)
                                        },
                                        onStopMediaProjection = {
                                            viewModel.stopMediaProjectionService(context)
                                        },
                                        onCaptureCamera = {
                                            if (hasPerm(Manifest.permission.CAMERA)) {
                                                cameraLauncher.launch(null)
                                            } else {
                                                permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
                                            }
                                        },
                                        onPickPhoto = {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                        onAnalyzeImageWithAi = { prompt ->
                                            if (selectedImageBitmap != null) {
                                                viewModel.performVisualLensContentAnalysis(
                                                    bitmap = selectedImageBitmap,
                                                    telemetry = visualTelemetry,
                                                    prompt = prompt
                                                )
                                            } else {
                                                viewModel.takeScreenshotAction(activity, analyzeWithAi = true)
                                            }
                                        },
                                        onSpeakAnalysis = { text ->
                                            viewModel.speakText(text)
                                        },
                                        onShareAnalyzedImageStatus = { caption ->
                                            viewModel.shareOnWhatsAppStatusAction(context, caption)
                                        },
                                        onOpenAccessibilitySettings = {
                                            ScreenReaderService.openAccessibilitySettings(context)
                                        },
                                        onSimulateScreenCaptureEvent = {
                                            Memory.saveScreenText(
                                                "Active Screen Read: Sanam AI (${selectedLanguage.label}) • Mode: ${selectedMode.title} • Battery ${telemetry.batteryPercent}%",
                                                context.packageName
                                            )
                                        }
                                    )

                                    else -> TriggersAndMissionsPanel(
                                        auraTheme = auraTheme,
                                        items = triggersAndMissions,
                                        onAddTriggerOrMission = { time, task, isMission ->
                                            viewModel.addTriggerOrMission(context, time, task, isMission)
                                        },
                                        onTestTriggerNow = { item ->
                                            viewModel.triggerNowTest(context, item)
                                        },
                                        onToggleEnabled = { item ->
                                            viewModel.toggleTriggerItem(item)
                                        },
                                        onToggleCompleted = { item ->
                                            viewModel.toggleMissionCompleted(item)
                                        },
                                        onDelete = { item ->
                                            viewModel.deleteTriggerItem(item)
                                        }
                                    )
                                }
                            }
                        )

                        2 -> LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .testTag("assistant_full_body_tab"),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            item {
                                // Top Animated MYRA Neural Orb & Full-Body Stage (GOOD EVENING DAYARAM BOSS + I'M ALWAYS WITH YOU)
                                MyraNeuralOrbHeader(
                                    auraTheme = auraTheme,
                                    orbStyle = orbStyle,
                                    selectedLanguage = selectedLanguage,
                                    selectedMode = selectedMode,
                                    isListening = isListening,
                                    isSpeaking = isSpeaking,
                                    isThinking = isThinking,
                                    telemetry = telemetry,
                                    statusBanner = statusBanner,
                                    onMicClick = { startVoiceRecognition() },
                                    onOrbStyleChange = { viewModel.selectOrbStyle(it) },
                                    onLanguageChange = { viewModel.selectLanguage(it, context) },
                                    onAuraChange = { viewModel.selectAura(it) }
                                )
                            }
                            item {
                                MyraQuickActionButtonsBar(
                                    auraTheme = auraTheme,
                                    onPostToInsta = {
                                        viewModel.postToInstagramAction(
                                            context,
                                            "Sanam AI (DR WORLD) • ${selectedLanguage.greeting} #SanamAI #DRWORLD"
                                        )
                                    },
                                    onPostToFb = {
                                        viewModel.postToFacebookAction(
                                            context,
                                            "Sanam AI (DR WORLD) • ${selectedLanguage.greeting} #SanamAI"
                                        )
                                    },
                                    onShareWhatsAppStatus = {
                                        viewModel.shareOnWhatsAppStatusAction(
                                            context,
                                            "Sanam AI Status (${selectedLanguage.label}): ${selectedLanguage.greeting} 💖"
                                        )
                                    },
                                    onTakeScreenshot = {
                                        triggerFullScreenMediaProjection(
                                            "Full-screen MediaProjection capture: Read everything on screen, summarize in ${selectedLanguage.label}, and suggest next action."
                                        )
                                    },
                                    onSetTrigger = {
                                        quickDialogIsMission = false
                                        showQuickTriggerDialog = true
                                    },
                                    onMissionMode = {
                                        quickDialogIsMission = true
                                        showQuickTriggerDialog = true
                                    },
                                    onOpenMaps = {
                                        viewModel.openMapsAction(context, "Tharparkar Sindh")
                                    },
                                    onToggleTouchGuard = {
                                        viewModel.toggleTouchGuard(true)
                                    }
                                )
                            }
                            item {
                                ScreenshotControls(
                                    activity = activity,
                                    viewModel = viewModel,
                                    auraTheme = auraTheme,
                                    selectedLanguage = selectedLanguage,
                                    onOpenVisualLensTab = { currentTab = 1 }
                                )
                                SanamMorphFooter()
                            }
                        }

                        4 -> VoiceOrbLiveMorph(
                            initialModeIndex = currentMorphModeIndex,
                            onModeChanged = { idx, _, _ ->
                                viewModel.updateMorphMode(context, idx)
                            },
                            onTriggerSpeech = { text ->
                                viewModel.speakText(text)
                            }
                        )

                        3 -> MyraExactSettingsScreen(
                            auraTheme = auraTheme,
                            viewModel = viewModel,
                            automationState = automationState,
                            selectedConnector = selectedConnector,
                            voicePitch = voicePitch,
                            voiceSpeed = voiceSpeed,
                            initialSubScreen = settingsInitialSubScreen,
                            onSelectConnector = {
                                HapticHelper.tick(context, automationState.hapticFeedbackEnabled)
                                viewModel.selectConnector(it)
                            },
                            onUpdateAutomationState = {
                                HapticHelper.tick(context, it.hapticFeedbackEnabled)
                                viewModel.updateAutomationPermissions(it)
                            },
                            onTestWakeWord = {
                                viewModel.triggerHeySanamWakeWord(context)
                            },
                            onTakeAppScreenshot = {
                                viewModel.takeScreenshotAction(activity, analyzeWithAi = true)
                            },
                            onRequestMicPermission = {
                                requestCorePermissionsIfNeeded()
                            }
                        )
                    }
                }
            }
        }

        // Quick Set Trigger / Mission Mode Modal Dialog
        if (showQuickTriggerDialog) {
            var dialogTime by remember { mutableStateOf("08:00 AM") }
            var dialogTask by remember {
                mutableStateOf(
                    if (quickDialogIsMission) "Pani peene ki yaad dilana & Instagram Status post karna"
                    else "Har subah 8 baje Good Morning bolna (${selectedLanguage.label})"
                )
            }
            AlertDialog(
                onDismissRequest = { showQuickTriggerDialog = false },
                title = {
                    Text(
                        text = if (quickDialogIsMission) "🎯 Set DR WORLD Mission Mode" else "⏰ Set Daily Voice Trigger",
                        fontWeight = FontWeight.Bold
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = dialogTime,
                            onValueChange = { dialogTime = it },
                            label = { Text("Time (e.g., 08:00 AM)") },
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = dialogTask,
                            onValueChange = { dialogTask = it },
                            label = { Text("Task / Voice Reminder") },
                            maxLines = 3
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.addTriggerOrMission(
                                context,
                                dialogTime,
                                dialogTask,
                                quickDialogIsMission
                            )
                            showQuickTriggerDialog = false
                            currentTab = 3
                        }
                    ) {
                        Text("Save & Activate")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showQuickTriggerDialog = false }) {
                        Text("Cancel")
                    }
                }
            )
        }

        // Full-Screen Touch Guard Overlay (Pocket Touch Protection & MYRA Security)
        AnimatedVisibility(visible = touchGuardLocked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xF505070E))
                    .clickable(enabled = true, onClick = {})
                    .testTag("touch_guard_overlay"),
                contentAlignment = Alignment.Center
            ) {
                Card(
                    shape = RoundedCornerShape(28.dp),
                    colors = CardDefaults.cardColors(containerColor = auraTheme.surface),
                    border = BorderStroke(2.dp, auraTheme.primary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = "Touch Guard Active",
                            tint = auraTheme.primary,
                            modifier = Modifier.size(56.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "DR WORLD TOUCH GUARD ACTIVE",
                            style = MaterialTheme.typography.titleLarge,
                            color = auraTheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "Accidental pocket touches are blocked while Sanam AI Voice & Triggers remain active in the background.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                        Spacer(modifier = Modifier.height(20.dp))
                        Button(
                            onClick = { viewModel.toggleTouchGuard(false) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("unlock_touch_guard_button")
                        ) {
                            Icon(Icons.Default.LockOpen, contentDescription = "Unlock")
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Unlock Sanam AI Screen")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompanionChatTab(
    auraTheme: com.example.ui.theme.AuraTheme,
    selectedMode: SanamMode,
    selectedLanguage: SanamLanguage,
    messages: List<ChatMessageEntity>,
    conversationSessions: List<ConversationSessionEntity>,
    activeSessionId: String,
    userInput: String,
    onUserInputChange: (String) -> Unit,
    onModeSelect: (SanamMode) -> Unit,
    onContinueLastConversation: () -> Unit,
    onStartNewConversation: () -> Unit,
    onSelectConversationSession: (ConversationSessionEntity) -> Unit,
    onSendMessage: () -> Unit,
    onVoiceClick: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onSpeakMessage: (String) -> Unit,
    onClearChat: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0F1F))
            .testTag("screen_chat_tab")
    ) {
        // Subtle Sanam Full-Body Avatar Background Watermark
        Image(
            painter = painterResource(id = R.drawable.sanam_full_body),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            alpha = 0.08f,
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
        )

        Column(modifier = Modifier.fillMaxSize()) {
            // Top Bar: SANAM Online with Avatar + Continue / Save Chat
            Surface(
                color = Color(0xFF1A2238),
                shape = RoundedCornerShape(bottomStart = 20.dp, bottomEnd = 20.dp),
                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.4f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("room_chat_history_bar")
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF7C5CFF).copy(alpha = 0.25f))
                                    .border(1.5.dp, Color(0xFF7C5CFF), CircleShape)
                            ) {
                                Image(
                                    painter = painterResource(id = R.drawable.sanam_full_body),
                                    contentDescription = "SANAM Avatar",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "SANAM",
                                    style = MaterialTheme.typography.titleMedium,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF00FF88))
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = "SANAM Online • ${selectedLanguage.label}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF00FF88),
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Button(
                                onClick = onContinueLastConversation,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)),
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("continue_last_conversation_button")
                            ) {
                                Text(
                                    text = "Continue",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            OutlinedButton(
                                onClick = onStartNewConversation,
                                modifier = Modifier
                                    .height(34.dp)
                                    .testTag("new_conversation_button")
                            ) {
                                Text("New", style = MaterialTheme.typography.labelSmall, color = Color.White)
                            }
                        }
                    }

                    if (conversationSessions.isNotEmpty()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState())
                                .padding(top = 6.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            conversationSessions.forEach { session ->
                                val isCurrent = session.sessionId == activeSessionId
                                FilterChip(
                                    selected = isCurrent,
                                    onClick = { onSelectConversationSession(session) },
                                    label = {
                                        Text(
                                            text = "💾 ${session.title} (${session.language})",
                                            style = MaterialTheme.typography.labelSmall
                                        )
                                    },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = Color(0xFF7C5CFF).copy(alpha = 0.28f),
                                        selectedLabelColor = Color.White
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // Center Prompt Header: "Start a new conversation with SANAM" + 4 Chips: Open, Play, Set, Search
            Surface(
                color = Color(0xFF1A2238),
                shape = RoundedCornerShape(18.dp),
                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.35f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "Start a new conversation with SANAM",
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold,
                        modifier = Modifier.testTag("chat_start_new_conversation_text")
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    // Exact 4 Chips from reference: Open, Play, Set, Search
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf(
                            "Open" to "Open YouTube",
                            "Play" to "Play Sindhi & Dhatki music on YouTube",
                            "Set" to "Set trigger for 8:00 AM Good Morning Dayaram Boss",
                            "Search" to "Let's plan trip to Jaipur"
                        ).forEach { (chipLabel, chipCmd) ->
                            FilterChip(
                                selected = false,
                                onClick = { onQuickPrompt(chipCmd) },
                                label = {
                                    Text(
                                        text = chipLabel,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp
                                    )
                                },
                                colors = FilterChipDefaults.filterChipColors(
                                    containerColor = Color(0xFF0A0F1F),
                                    labelColor = Color.White
                                ),
                                border = FilterChipDefaults.filterChipBorder(
                                    enabled = true,
                                    selected = false,
                                    borderColor = Color(0xFF7C5CFF)
                                ),
                                modifier = Modifier.testTag("chat_chip_${chipLabel.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Conversation List
            LazyColumn(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(messages, key = { it.id }) { msg ->
                    val isUser = msg.sender == "USER"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        Card(
                            shape = RoundedCornerShape(
                                topStart = 20.dp,
                                topEnd = 20.dp,
                                bottomStart = if (isUser) 20.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 20.dp
                            ),
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUser) {
                                    Color(0xFF7C5CFF)
                                } else {
                                    Color(0xFF1A2238)
                                }
                            ),
                            border = BorderStroke(
                                1.dp,
                                if (isUser) Color.White.copy(alpha = 0.25f)
                                else Color(0xFF7C5CFF).copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.fillMaxWidth(0.88f)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isUser) "YOU • ${msg.language}" else "SANAM AI • ${msg.language}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (isUser) Color.White.copy(alpha = 0.9f) else Color(0xFF00FF88),
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (msg.actionBadge != null) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color(0xFF0A0F1F)
                                        ) {
                                            Text(
                                                text = msg.actionBadge,
                                                style = MaterialTheme.typography.labelSmall,
                                                color = Color(0xFF00FF88),
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = msg.text,
                                    style = MaterialTheme.typography.bodyLarge,
                                    color = Color.White
                                )
                                if (!isUser) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End
                                    ) {
                                        IconButton(
                                            onClick = { onSpeakMessage(msg.text) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = "Speak Reply",
                                                tint = Color(0xFF00FF88),
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Bottom Chat Input Bar: "Type a message..." with purple mic (#7C5CFF) and send arrow
            Surface(
                color = Color(0xFF1A2238),
                tonalElevation = 6.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    IconButton(
                        onClick = onClearChat,
                        modifier = Modifier.testTag("clear_chat_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.DeleteSweep,
                            contentDescription = "Clear Chat",
                            tint = Color.White.copy(alpha = 0.65f)
                        )
                    }

                    OutlinedTextField(
                        value = userInput,
                        onValueChange = onUserInputChange,
                        placeholder = {
                            Text(
                                text = "Type a message...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = Color.White.copy(alpha = 0.55f)
                            )
                        },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("chat_command_input"),
                        shape = RoundedCornerShape(24.dp),
                        singleLine = true
                    )

                    IconButton(
                        onClick = onVoiceClick,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7C5CFF))
                            .testTag("voice_input_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Voice Input",
                            tint = Color.White
                        )
                    }

                    IconButton(
                        onClick = onSendMessage,
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7C5CFF))
                            .testTag("send_message_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send Command",
                            tint = Color.White
                        )
                    }
                }
            }
            SanamMorphFooter()
        }
    }
}

/**
 * Composable function 'ScreenshotControls' in the main UI that launches the MediaProjection
 * intent when triggered and saves the resulting bitmap to the app's local storage (context.filesDir/screenshots).
 */
@Composable
fun ScreenshotControls(
    activity: Activity,
    viewModel: SanamViewModel,
    auraTheme: com.example.ui.theme.AuraTheme,
    selectedLanguage: SanamLanguage,
    onOpenVisualLensTab: () -> Unit = {}
) {
    val context = LocalContext.current
    val isProjectionActive by viewModel.isMediaProjectionActive.collectAsStateWithLifecycle()
    val capturedBitmap by viewModel.selectedImageBitmap.collectAsStateWithLifecycle()
    val latestSavedFile by ScreenshotHelper.latestSavedLocalFile.collectAsStateWithLifecycle()

    // Launcher that receives MediaProjection permission result, starts MediaProjectionService,
    // and saves the resulting screenshot bitmap to the app's persistent local storage.
    val projectionIntentLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        // Immediately capture & persist initial frame to local storage (filesDir/screenshots)
        ScreenshotHelper.takeScreenshot(
            activity = activity,
            analyzeImmediately = false
        )
        // Start foreground MediaProjectionService for full-screen VirtualDisplay capture & Visual Lens analysis
        viewModel.onMediaProjectionPermissionResult(
            context = context,
            activity = activity,
            resultCode = result.resultCode,
            data = result.data,
            customPrompt = "Analyze this MediaProjection full-screen capture in ${selectedLanguage.label}."
        )
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .testTag("screenshot_controls_card"),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f)
        ),
        border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.35f))
    ) {
        Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    if (capturedBitmap != null) {
                        Image(
                            bitmap = capturedBitmap!!.asImageBitmap(),
                            contentDescription = "Saved Screenshot Thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onOpenVisualLensTab() }
                                .testTag("screenshot_controls_thumbnail")
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                    }
                    Column {
                        Text(
                            text = if (isProjectionActive) {
                                "🟢 MediaProjection Active • Local Storage Ready"
                            } else {
                                "📸 MediaProjection Screenshot Controls"
                            },
                            style = MaterialTheme.typography.labelLarge,
                            color = auraTheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = latestSavedFile?.let { "Saved: files/screenshots/${it.name}" }
                                ?: "Tap Capture to launch MediaProjection & save PNG locally",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.testTag("screenshot_controls_saved_path")
                        )
                    }
                }

                Spacer(modifier = Modifier.width(8.dp))

                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            if (isProjectionActive) {
                                viewModel.captureFrameFromActiveProjectionOrWindow(
                                    activity = activity,
                                    customPrompt = "Analyze this MediaProjection frame in ${selectedLanguage.label}."
                                )
                            } else {
                                val intent = ScreenshotHelper.createMediaProjectionIntent(context)
                                if (intent != null) {
                                    projectionIntentLauncher.launch(intent)
                                } else {
                                    ScreenshotHelper.takeScreenshot(
                                        activity = activity,
                                        analyzeImmediately = true
                                    )
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = auraTheme.primary),
                        modifier = Modifier.testTag("screenshot_controls_launch_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.ScreenshotMonitor,
                            contentDescription = "Launch MediaProjection Capture",
                            tint = Color.Black,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isProjectionActive) "Capture" else "Project & Save",
                            color = Color.Black,
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    if (capturedBitmap != null) {
                        IconButton(
                            onClick = {
                                ScreenshotHelper.saveBitmapToLocalStorage(
                                    context = context,
                                    bitmap = capturedBitmap!!,
                                    prefix = "sanam_manual_save"
                                )
                            },
                            modifier = Modifier
                                .size(38.dp)
                                .clip(CircleShape)
                                .background(auraTheme.secondary.copy(alpha = 0.2f))
                                .testTag("screenshot_controls_save_local_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Save,
                                contentDescription = "Save Bitmap to Local Storage",
                                tint = auraTheme.secondary,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

