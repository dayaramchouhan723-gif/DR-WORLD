package com.example

import android.graphics.Bitmap
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeDown
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FlashlightOn
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Sms
import androidx.compose.material.icons.filled.SportsEsports
import com.example.sanam.controller.AppLauncher
import com.example.sanam.controller.CallHelper
import com.example.sanam.controller.DeviceActionManager
import com.example.sanam.controller.SmsHelper
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.AuraTheme

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SocialAndJarvisPanel(
    auraTheme: AuraTheme,
    selectedLanguage: SanamLanguage,
    selectedImageBitmap: Bitmap?,
    telemetry: SystemTelemetry,
    onPickGalleryPhoto: () -> Unit,
    onCaptureCamera: () -> Unit,
    onGenerateSocialCard: (String) -> Unit,
    onPostInsta: (String) -> Unit,
    onPostFb: (String) -> Unit,
    onShareWhatsAppStatus: (String) -> Unit,
    onSendWhatsAppMessage: (String, String) -> Unit,
    onMakeCall: (String) -> Unit,
    onSendSms: (String, String) -> Unit,
    onOpenMaps: (String) -> Unit,
    onToggleFlashlight: () -> Unit,
    onAdjustVolume: (Boolean) -> Unit,
    onLaunchApp: (String) -> Unit
) {
    var socialCaption by remember {
        mutableStateOf("Kiyan aahin munhinja pyara! 💖 Living the future with Sanam AI (DR WORLD) #SanamAI #Dhatki #DRWORLD")
    }
    var contactInput by remember { mutableStateOf("Dayaram") }
    var messageInput by remember { mutableStateOf("Salam! Sent hands-free via Sanam AI Autonomous Controller.") }
    var mapsQuery by remember { mutableStateOf("Umerkot Fort Tharparkar") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 1. SOCIAL MEDIA AGENT CARD (Instagram, Facebook, WhatsApp Status)
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.secondary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "📸 SOCIAL MEDIA AGENT (DR WORLD)",
                                style = MaterialTheme.typography.titleMedium,
                                color = auraTheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Instagram Post • Facebook Share • WhatsApp Status & Photo",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Image Preview / Picker Row
                    if (selectedImageBitmap != null) {
                        Image(
                            bitmap = selectedImageBitmap.asImageBitmap(),
                            contentDescription = "Selected Social Media Image",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(190.dp)
                                .clip(RoundedCornerShape(16.dp))
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onPickGalleryPhoto,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("social_pick_gallery_button")
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Gallery", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gallery Photo")
                        }
                        OutlinedButton(
                            onClick = onCaptureCamera,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("social_camera_button")
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Camera", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Camera")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { onGenerateSocialCard(socialCaption) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_status_card_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Generate Status Card", tint = auraTheme.primary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Generate Stylized ${selectedLanguage.label} Status Card")
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = socialCaption,
                        onValueChange = { socialCaption = it },
                        label = { Text("Post / Status Caption (${selectedLanguage.label})") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("social_caption_input"),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Multi-language status caption presets
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "Dhatki Vibe" to "Kiyan aahin munhinja pyara! 🌸 Thari Sanam AI har pal saath aahi #Dhatki #Thar",
                            "Sindhi Love" to "منهنجا سڄڻ، تنهنجي مرڪ منهنجي زندگي آهي 💖 #SindhiStatus #SanamAI",
                            "Urdu Shayari" to "تیری آواز سے ہی روشن ہے میری دنیا، میرے ہمسفر ✨ #UrduStatus #DRWORLD",
                            "Hindi Status" to "Apna time aur apni Sanam AI dono best hain! 🔥💖 #SanamAI #JARVIS"
                        ).forEach { (title, preset) ->
                            FilterChip(
                                selected = socialCaption == preset,
                                onClick = { socialCaption = preset },
                                label = { Text(title, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onPostInsta(socialCaption) },
                            colors = ButtonDefaults.buttonColors(containerColor = auraTheme.secondary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("panel_post_insta_btn")
                        ) {
                            Icon(Icons.Default.PhotoCamera, contentDescription = "Instagram", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Post to Insta")
                        }
                        Button(
                            onClick = { onPostFb(socialCaption) },
                            colors = ButtonDefaults.buttonColors(containerColor = auraTheme.primary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("panel_post_fb_btn")
                        ) {
                            Icon(Icons.Default.Public, contentDescription = "Facebook", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Post to FB")
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { onShareWhatsAppStatus(socialCaption) },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00C853)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("panel_whatsapp_status_btn")
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "WhatsApp Status", tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Share Photo + Caption on WhatsApp Status",
                            color = Color.Black,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 2. AUTONOMOUS JARVIS PHONE CONTROLLER (Call, WhatsApp Msg, SMS, Maps, Flashlight, Apps)
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "⚡ JARVIS AUTONOMOUS DEVICE CONTROLLER",
                        style = MaterialTheme.typography.titleMedium,
                        color = auraTheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Direct Phone Call • WhatsApp Chat • SMS • Maps • Hardware",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "📞 QUICK CALL CONTACTS (JARVIS CallHelper):",
                        style = MaterialTheme.typography.labelSmall,
                        color = auraTheme.primary
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CallHelper.favoriteContacts.keys.forEach { name ->
                            val display = name.replaceFirstChar { it.uppercase() }
                            FilterChip(
                                selected = contactInput.equals(display, ignoreCase = true),
                                onClick = {
                                    contactInput = display
                                    onMakeCall(display)
                                },
                                label = { Text("📞 Call $display", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = contactInput,
                        onValueChange = { contactInput = it },
                        label = { Text("Contact Name or Phone (e.g., Dayaram, Mumma, +91...)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("jarvis_contact_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = messageInput,
                        onValueChange = { messageInput = it },
                        label = { Text("WhatsApp / SMS Message") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("jarvis_message_input"),
                        maxLines = 2
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onMakeCall(contactInput) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("jarvis_call_button")
                        ) {
                            Icon(Icons.Default.Call, contentDescription = "Call", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Call")
                        }
                        Button(
                            onClick = { onSendWhatsAppMessage(contactInput, messageInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E676)),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("jarvis_whatsapp_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "WhatsApp", tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("WhatsApp", color = Color.Black)
                        }
                        Button(
                            onClick = { onSendSms(contactInput, messageInput) },
                            colors = ButtonDefaults.buttonColors(containerColor = auraTheme.secondary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("jarvis_sms_button")
                        ) {
                            Icon(Icons.Default.Sms, contentDescription = "SMS", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("SMS")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Maps Navigation Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = mapsQuery,
                            onValueChange = { mapsQuery = it },
                            label = { Text("Google Maps Location / Place") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        Button(
                            onClick = { onOpenMaps(mapsQuery) },
                            modifier = Modifier.testTag("jarvis_maps_go_button")
                        ) {
                            Icon(Icons.Default.Map, contentDescription = "Open Maps")
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Maps")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // System Controls: Flashlight & Volume
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onToggleFlashlight,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("jarvis_flashlight_button")
                        ) {
                            Icon(Icons.Default.FlashlightOn, contentDescription = "Torch", tint = auraTheme.primary)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (telemetry.flashlightOn) "Torch: ON" else "Torch: OFF")
                        }
                        OutlinedButton(
                            onClick = { onAdjustVolume(false) },
                            modifier = Modifier.testTag("jarvis_vol_down_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeDown, contentDescription = "Volume Down")
                        }
                        OutlinedButton(
                            onClick = { onAdjustVolume(true) },
                            modifier = Modifier.testTag("jarvis_vol_up_button")
                        ) {
                            Icon(Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Volume Up")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "🚀 AUTONOMOUS APP LAUNCHER",
                        style = MaterialTheme.typography.labelLarge,
                        color = auraTheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        AppLauncher.supportedApps.forEach { app ->
                            OutlinedButton(
                                onClick = { onLaunchApp(app) },
                                modifier = Modifier.testTag("launch_app_${app.lowercase().replace(" ", "_")}")
                            ) {
                                Text(app)
                            }
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VisualLensAndScreenPanel(
    auraTheme: AuraTheme,
    selectedLanguage: SanamLanguage,
    selectedImageBitmap: Bitmap?,
    isMediaProjectionActive: Boolean,
    visualTelemetry: VisualContentTelemetry?,
    latestVisualLensAnalysis: String?,
    liveScreenStream: List<String>,
    screenLogs: List<ScreenLogEntity>,
    onTakeScreenshot: () -> Unit,
    onRequestMediaProjection: (String?) -> Unit,
    onStopMediaProjection: () -> Unit,
    onCaptureCamera: () -> Unit,
    onPickPhoto: () -> Unit,
    onAnalyzeImageWithAi: (String) -> Unit,
    onSpeakAnalysis: (String) -> Unit,
    onShareAnalyzedImageStatus: (String) -> Unit,
    onOpenAccessibilitySettings: () -> Unit,
    onSimulateScreenCaptureEvent: () -> Unit
) {
    var lensPrompt by remember {
        mutableStateOf("Read everything on this full-screen capture, summarize the UI & content in ${selectedLanguage.label}, and write a catchy Instagram/WhatsApp caption.")
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 0. SANAM ACCESSIBILITY SERVICE PERMISSION & GESTURE ACTIONS (Read Screen + Tap/Swipe/Back/Home)
        item {
            SanamAccessibilityPermissionCard(
                auraTheme = auraTheme,
                onTakeAppScreenshot = onTakeScreenshot
            )
        }

        // 1. MEDIAPROJECTION SERVICE & VISUAL LENS ENGINE CARD
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "👁️ MEDIAPROJECTION & VISUAL LENS",
                                style = MaterialTheme.typography.titleMedium,
                                color = auraTheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Full-Screen VirtualDisplay Capture & Gemini 3.5 Flash Visual Analysis",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(50),
                            color = if (isMediaProjectionActive) {
                                Color(0xFF00E676).copy(alpha = 0.2f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant
                            },
                            border = BorderStroke(
                                1.dp,
                                if (isMediaProjectionActive) Color(0xFF00E676) else auraTheme.primary.copy(alpha = 0.35f)
                            ),
                            modifier = Modifier.testTag("media_projection_status_badge")
                        ) {
                            Text(
                                text = if (isMediaProjectionActive) "🟢 PROJECTION ACTIVE" else "⚪ STANDBY",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isMediaProjectionActive) Color(0xFF00E676) else MaterialTheme.colorScheme.onSurface,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // MediaProjection Service Primary Controls
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { onRequestMediaProjection(lensPrompt) },
                            colors = ButtonDefaults.buttonColors(containerColor = auraTheme.primary),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("lens_media_projection_btn")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ScreenshotMonitor,
                                contentDescription = "MediaProjection Capture",
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                if (isMediaProjectionActive) "Capture Projection Frame"
                                else "Start MediaProjection"
                            )
                        }

                        if (isMediaProjectionActive) {
                            OutlinedButton(
                                onClick = onStopMediaProjection,
                                modifier = Modifier.testTag("lens_stop_projection_btn")
                            ) {
                                Text("Stop Service")
                            }
                        } else {
                            OutlinedButton(
                                onClick = onTakeScreenshot,
                                modifier = Modifier
                                    .weight(0.85f)
                                    .testTag("lens_take_screenshot_btn")
                            ) {
                                Text("Quick Capture")
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = onCaptureCamera,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.CameraAlt, contentDescription = "Camera", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Camera Lens")
                        }
                        OutlinedButton(
                            onClick = onPickPhoto,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.PhotoLibrary, contentDescription = "Photo", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Gallery Photo")
                        }
                    }

                    // Captured Screenshot / Image Preview + Visual Content Telemetry
                    if (selectedImageBitmap != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Image(
                            bitmap = selectedImageBitmap.asImageBitmap(),
                            contentDescription = "Visual Lens Target",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(210.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .testTag("visual_lens_preview_image")
                        )

                        if (visualTelemetry != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f),
                                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.3f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("visual_telemetry_card")
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "📊 VISUAL TELEMETRY • ${visualTelemetry.captureSource.uppercase()}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = auraTheme.primary,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "Res: ${visualTelemetry.resolution} (${visualTelemetry.aspectRatio}) • Luma: ${visualTelemetry.averageBrightnessPercent}%",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = MaterialTheme.colorScheme.surface
                                    ) {
                                        Text(
                                            text = visualTelemetry.dominantHexColor,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = auraTheme.secondary,
                                            fontWeight = FontWeight.Bold,
                                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Visual Lens Analysis Preset Modes
                    Text(
                        text = "VISUAL LENS ANALYSIS MODE PRESETS:",
                        style = MaterialTheme.typography.labelSmall,
                        color = auraTheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "🔍 Scene & UI Breakdown" to "Analyze the visual layout, UI components, colors, and objects on this screen in ${selectedLanguage.label}.",
                            "📝 Extract & Translate Text" to "Perform OCR on this screenshot: read all visible text and translate/explain it in ${selectedLanguage.label}.",
                            "📸 Social Status Caption" to "Write an emotional, catchy ${selectedLanguage.label} Instagram & WhatsApp Status caption for this screenshot.",
                            "🛡️ Security & Scam Check" to "Inspect this screen for any suspicious links, phishing prompts, or privacy risks and advise in ${selectedLanguage.label}."
                        ).forEach { (label, presetPrompt) ->
                            FilterChip(
                                selected = lensPrompt == presetPrompt,
                                onClick = { lensPrompt = presetPrompt },
                                label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = lensPrompt,
                        onValueChange = { lensPrompt = it },
                        label = { Text("Ask Sanam Visual Lens (${selectedLanguage.label})") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("visual_lens_prompt_input"),
                        maxLines = 2
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Button(
                        onClick = { onAnalyzeImageWithAi(lensPrompt) },
                        colors = ButtonDefaults.buttonColors(containerColor = auraTheme.secondary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("lens_analyze_ai_button")
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = "Analyze")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Analyze Screen / Photo with Visual Lens AI")
                    }

                    // Inline Visual Lens AI Analysis Output Card
                    if (!latestVisualLensAnalysis.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.85f)
                            ),
                            border = BorderStroke(1.dp, auraTheme.secondary.copy(alpha = 0.5f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("visual_lens_analysis_result_card")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "✨ SANAM VISUAL LENS INSIGHT (${selectedLanguage.label.uppercase()})",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = auraTheme.secondary,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Row {
                                        IconButton(
                                            onClick = { onSpeakAnalysis(latestVisualLensAnalysis) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                                contentDescription = "Speak Visual Analysis",
                                                tint = auraTheme.primary,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(4.dp))
                                        IconButton(
                                            onClick = { onShareAnalyzedImageStatus(latestVisualLensAnalysis) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Share,
                                                contentDescription = "Share Screenshot & Analysis",
                                                tint = Color(0xFF00E676),
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = latestVisualLensAnalysis,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }
            }
        }

        // 2. SCREEN READER ACCESSIBILITY SERVICE (MYRA Screen Reading)
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.secondary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "📖 DR WORLD SCREEN READER SERVICE",
                                style = MaterialTheme.typography.titleMedium,
                                color = auraTheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "AccessibilityService reads on-screen text & saves to Room Memory",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.AccessibilityNew,
                            contentDescription = "Accessibility",
                            tint = auraTheme.primary,
                            modifier = Modifier.size(28.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = onOpenAccessibilitySettings,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_accessibility_settings_btn")
                        ) {
                            Text("Accessibility Settings")
                        }
                        OutlinedButton(
                            onClick = onSimulateScreenCaptureEvent,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("read_current_screen_btn")
                        ) {
                            Text("Read Current Screen")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "LIVE CAPTURED SCREEN TEXT STREAM (${liveScreenStream.size + screenLogs.size} logs):",
                        style = MaterialTheme.typography.labelSmall,
                        color = auraTheme.primary
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    liveScreenStream.take(6).forEach { entry ->
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp)
                        ) {
                            Text(
                                text = entry,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TriggersAndMissionsPanel(
    auraTheme: AuraTheme,
    items: List<TriggerMission>,
    onAddTriggerOrMission: (String, String, Boolean) -> Unit,
    onTestTriggerNow: (TriggerMission) -> Unit,
    onToggleEnabled: (TriggerMission) -> Unit,
    onToggleCompleted: (TriggerMission) -> Unit,
    onDelete: (TriggerMission) -> Unit
) {
    var timeInput by remember { mutableStateOf("08:00 AM") }
    var taskInput by remember { mutableStateOf("Subah 8 baje Good Morning bolna & Dhatki shayari sunana") }
    var isMissionMode by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎯 DR WORLD TRIGGERS & MISSION MODE",
                        style = MaterialTheme.typography.titleMedium,
                        color = auraTheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Schedule daily voice triggers (AlarmManager) or autonomous Mission Mode tasks",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !isMissionMode,
                            onClick = { isMissionMode = false },
                            label = { Text("⏰ Daily Trigger") },
                            modifier = Modifier.testTag("select_trigger_type_chip")
                        )
                        FilterChip(
                            selected = isMissionMode,
                            onClick = { isMissionMode = true },
                            label = { Text("🎯 Mission Mode") },
                            modifier = Modifier.testTag("select_mission_type_chip")
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = timeInput,
                        onValueChange = { timeInput = it },
                        label = { Text("Trigger / Mission Time (e.g., 08:00 AM, 06:30 PM)") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("trigger_time_input"),
                        singleLine = true
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = taskInput,
                        onValueChange = { taskInput = it },
                        label = { Text("Task / Voice Command for Sanam") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("trigger_task_input"),
                        maxLines = 2
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Preset chips for popular MYRA triggers
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "08:00 AM" to "Good morning bolna aur aaj ka plan batana",
                            "01:00 PM" to "Pani peene aur khana khane ki yaad dilana",
                            "06:00 PM" to "WhatsApp Status & Instagram post update karna",
                            "10:30 PM" to "Good night pyari baat aur phone battery check"
                        ).forEach { (t, task) ->
                            FilterChip(
                                selected = taskInput == task,
                                onClick = {
                                    timeInput = t
                                    taskInput = task
                                },
                                label = { Text("$t • ${task.take(18)}...", style = MaterialTheme.typography.labelSmall) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Button(
                        onClick = {
                            onAddTriggerOrMission(timeInput, taskInput, isMissionMode)
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isMissionMode) auraTheme.secondary else auraTheme.primary
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("save_trigger_mission_btn")
                    ) {
                        Icon(
                            imageVector = if (isMissionMode) Icons.Default.Flag else Icons.Default.NotificationsActive,
                            contentDescription = "Save"
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (isMissionMode) "Add to Mission Mode" else "Schedule Voice Trigger")
                    }
                }
            }
        }

        items(items, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f)
                ),
                border = BorderStroke(
                    1.dp,
                    if (item.isMission) auraTheme.secondary.copy(alpha = 0.45f)
                    else auraTheme.primary.copy(alpha = 0.45f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Checkbox(
                        checked = item.isCompleted,
                        onCheckedChange = { onToggleCompleted(item) }
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (item.isMission) auraTheme.secondary.copy(alpha = 0.25f)
                                else auraTheme.primary.copy(alpha = 0.25f)
                            ) {
                                Text(
                                    text = if (item.isMission) "🎯 MISSION" else "⏰ TRIGGER",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.time,
                                style = MaterialTheme.typography.titleMedium,
                                color = auraTheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.task,
                            style = MaterialTheme.typography.bodyLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { onTestTriggerNow(item) }) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Test Trigger Voice Now",
                            tint = auraTheme.primary
                        )
                    }
                    Switch(
                        checked = item.isEnabled,
                        onCheckedChange = { onToggleEnabled(item) }
                    )
                    IconButton(onClick = { onDelete(item) }) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}

@Composable
fun GamingSecurityMemoryPanel(
    auraTheme: AuraTheme,
    telemetry: SystemTelemetry,
    gamingBoostActive: Boolean,
    myraSecurityArmed: Boolean,
    proximityNear: Boolean,
    motionDelta: Float,
    securityAlerts: Int,
    voicePitch: Float,
    voiceSpeed: Float,
    memories: List<MemoryFactEntity>,
    selectedConnector: AiModelConnector = AiModelConnector.GEMINI_FLASH,
    automationState: AutomationPermissionsState = AutomationPermissionsState(),
    onSelectConnector: (AiModelConnector) -> Unit = {},
    onUpdateAutomationState: (AutomationPermissionsState) -> Unit = {},
    onTestWakeWord: () -> Unit = {},
    onTakeAppScreenshot: () -> Unit = {},
    onGenerateWebsitePrompt: (String) -> Unit = {},
    onSendPcCommand: (String) -> Unit = {},
    onToggleGamingBoost: () -> Unit,
    onToggleMyraSecurity: () -> Unit,
    onLockTouchGuard: () -> Unit,
    onPitchChange: (Float) -> Unit,
    onSpeedChange: (Float) -> Unit,
    onAddMemory: (String, String) -> Unit,
    onDeleteMemory: (Int) -> Unit
) {
    var memTitle by remember { mutableStateOf("") }
    var memValue by remember { mutableStateOf("") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // 0. MYRA 2.2.10 LIFETIME FREE UNLOCKED, MULTI-LLM CONNECTORS, AUTOMATION TOGGLES & PC BRIDGE
        item {
            Myra2210UpgradeCard(
                auraTheme = auraTheme,
                selectedConnector = selectedConnector,
                automationState = automationState,
                onSelectConnector = onSelectConnector,
                onUpdateAutomationState = onUpdateAutomationState,
                onTestWakeWord = onTestWakeWord,
                onTakeAppScreenshot = onTakeAppScreenshot,
                onGenerateWebsitePrompt = onGenerateWebsitePrompt,
                onSendPcCommand = onSendPcCommand
            )
        }
        // 1. MYRA SECURITY & TOUCH GUARD CARD
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.45f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "🛡️ DR WORLD SECURITY & TOUCH GUARD",
                                style = MaterialTheme.typography.titleMedium,
                                color = auraTheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Pocket Touch Shield • Proximity Sensor • Anti-Theft Motion Alert",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = myraSecurityArmed,
                            onCheckedChange = { onToggleMyraSecurity() }
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Proximity: ${if (proximityNear) "⚠️ NEAR (Pocket)" else "✅ Clear"}",
                            style = MaterialTheme.typography.labelLarge
                        )
                        Text(
                            text = "Motion Δ: ${"%.2f".format(motionDelta)} m/s² • Alerts: $securityAlerts",
                            style = MaterialTheme.typography.labelLarge,
                            color = auraTheme.secondary
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = onLockTouchGuard,
                        colors = ButtonDefaults.buttonColors(containerColor = auraTheme.secondary),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("activate_touch_guard_lock_btn")
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = "Touch Guard")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Activate Pocket Touch Guard Shield")
                    }
                }
            }
        }

        // 2. GAMING ASSISTANT HUD
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.secondary.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "🎮 GAMING ASSISTANT HUD",
                                style = MaterialTheme.typography.titleMedium,
                                color = auraTheme.secondary,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "RAM: ${telemetry.ramUsedMb}/${telemetry.ramTotalMb} MB • Battery: ${telemetry.batteryPercent}%",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Button(
                            onClick = onToggleGamingBoost,
                            modifier = Modifier.testTag("gaming_boost_button")
                        ) {
                            Icon(Icons.Default.SportsEsports, contentDescription = "Gaming Boost", modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(if (gamingBoostActive) "Turbo ON" else "Boost")
                        }
                    }
                }
            }
        }

        // 3. VOICE CADENCE & PERSISTENT ROOM MEMORY
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎙️ MAYRA SWEET VOICE CADENCE & MEMORY",
                        style = MaterialTheme.typography.titleMedium,
                        color = auraTheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Voice Pitch: ${"%.2f".format(voicePitch)}x",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = voicePitch,
                        onValueChange = onPitchChange,
                        valueRange = 0.7f..1.6f
                    )
                    Text(
                        text = "Voice Speed: ${"%.2f".format(voiceSpeed)}x",
                        style = MaterialTheme.typography.labelLarge
                    )
                    Slider(
                        value = voiceSpeed,
                        onValueChange = onSpeedChange,
                        valueRange = 0.6f..1.4f
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = memTitle,
                            onValueChange = { memTitle = it },
                            label = { Text("Memory Key") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = memValue,
                            onValueChange = { memValue = it },
                            label = { Text("Fact / Preference") },
                            modifier = Modifier.weight(1.3f),
                            singleLine = true
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = {
                            onAddMemory(memTitle, memValue)
                            memTitle = ""
                            memValue = ""
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_memory_fact_btn")
                    ) {
                        Icon(Icons.Default.Memory, contentDescription = "Save Memory")
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Save to Room Persistent Memory")
                    }
                }
            }
        }

        items(memories, key = { it.id }) { fact ->
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "${fact.keyTitle} (${fact.category})",
                            style = MaterialTheme.typography.labelLarge,
                            color = auraTheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = fact.factValue,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(onClick = { onDeleteMemory(fact.id) }) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete Memory")
                    }
                }
            }
        }

        // Prototype Security Warning per Gemini API & Secret Management Guidelines
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                )
            ) {
                Text(
                    text = stringResource(id = R.string.security_warning_prototype),
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.padding(12.dp)
                )
            }
        }

        item { Spacer(modifier = Modifier.height(24.dp)) }
    }
}
