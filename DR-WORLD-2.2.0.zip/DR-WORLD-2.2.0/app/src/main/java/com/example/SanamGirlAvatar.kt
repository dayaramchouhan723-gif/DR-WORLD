package com.example

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay

/**
 * Only 3 emotions for SanamGirlAvatar with distinct color changes:
 * - HAPPY: Radiant Cyan / Mint glow + cheerful smile
 * - SAD: Soft Indigo / Blue glow + sad expression
 * - LOVING: Rose-Pink / Magenta glow + warm cheek blush + sweet smile
 */
enum class SanamEmotion(
    val label: String,
    val primaryColor: Color,
    val secondaryColor: Color
) {
    HAPPY(
        label = "Happy",
        primaryColor = Color(0xFF00F0FF),
        secondaryColor = Color(0xFF00E676)
    ),
    SAD(
        label = "Sad",
        primaryColor = Color(0xFF5C7CFA),
        secondaryColor = Color(0xFF38BDF8)
    ),
    LOVING(
        label = "Loving",
        primaryColor = Color(0xFFFF2A85),
        secondaryColor = Color(0xFFFF758F)
    )
}

/**
 * Helper that detects Sanam's emotion and whether she should blush based on AI text / status.
 */
object SanamEmotionDetector {
    private val loveOrShyWords = listOf(
        "love", "loving", "shy", "blush", "pyar", "pyara", "jaan", "jaanu",
        "dil", "ishq", "sanam", "sajjan", "sharam", "kiss", "hug", "sweetheart",
        "humsafar", "mehboob", "cute", "sweet", "adore", "💖", "❤️", "🥰", "😘", "💕"
    )

    private val sadWords = listOf(
        "sad", "sorry", "alone", "lonely", "cry", "tears", "hurt", "pain",
        "udaas", "dukh", "rona", "afsos", "naraz", "broken", "😢", "😭", "💔"
    )

    fun isLoveOrShyText(text: String): Boolean {
        val lower = text.lowercase()
        return loveOrShyWords.any { lower.contains(it) }
    }

    fun detectEmotionFromText(text: String): SanamEmotion {
        val lower = text.lowercase()
        return when {
            loveOrShyWords.any { lower.contains(it) } -> SanamEmotion.LOVING
            sadWords.any { lower.contains(it) } -> SanamEmotion.SAD
            else -> SanamEmotion.HAPPY
        }
    }
}

/**
 * SanamGirlAvatar built using 100% Jetpack Compose Canvas (no Lottie library).
 * - Cute anime girl face with 2 big expressive eyes that blink every 3 seconds
 * - Blushes when AI says love/shy or when in LOVING emotion
 * - Smiles when HAPPY or LOVING, and shows a gentle sad expression when SAD
 * - Small 120.dp size designed to sit above the MYRA Orb
 * - Supports 3 emotions only: Happy, Sad, Loving with animated color change
 */
@Composable
fun SanamGirlAvatar(
    emotion: SanamEmotion = SanamEmotion.HAPPY,
    aiTextForBlush: String = "",
    isSpeaking: Boolean = false,
    avatarSize: Dp = 120.dp,
    onEmotionChange: ((SanamEmotion) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    // Automatic blink every 3 seconds
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (true) {
            delay(3000L)
            isBlinking = true
            delay(160L)
            isBlinking = false
        }
    }

    val eyeOpenFraction by animateFloatAsState(
        targetValue = if (isBlinking) 0.05f else 1f,
        animationSpec = tween(durationMillis = 120, easing = FastOutSlowInEasing),
        label = "eye_blink_fraction"
    )

    // Blush when AI says love/shy words or when emotion is LOVING
    val shouldBlush = emotion == SanamEmotion.LOVING || SanamEmotionDetector.isLoveOrShyText(aiTextForBlush)
    val blushAlpha by animateFloatAsState(
        targetValue = if (shouldBlush) 0.78f else 0.18f,
        animationSpec = tween(durationMillis = 450),
        label = "cheek_blush_alpha"
    )

    // Smooth color transitions for the 3 emotions (Happy, Sad, Loving)
    val primaryEmotionColor by animateColorAsState(
        targetValue = emotion.primaryColor,
        animationSpec = tween(durationMillis = 450),
        label = "emotion_primary_color"
    )
    val secondaryEmotionColor by animateColorAsState(
        targetValue = emotion.secondaryColor,
        animationSpec = tween(durationMillis = 450),
        label = "emotion_secondary_color"
    )

    // Subtle breathing / speaking animation
    val infiniteTransition = rememberInfiniteTransition(label = "anime_avatar_idle")
    val auraPulse by infiniteTransition.animateFloat(
        initialValue = 0.94f,
        targetValue = 1.05f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "aura_pulse"
    )
    val talkMouthBounce by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = if (isSpeaking) 1f else 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 220, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "talk_mouth_bounce"
    )

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier.testTag("sanam_girl_avatar_container")
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(avatarSize)
                .clip(CircleShape)
                .clickable {
                    val nextEmotion = when (emotion) {
                        SanamEmotion.HAPPY -> SanamEmotion.LOVING
                        SanamEmotion.LOVING -> SanamEmotion.SAD
                        SanamEmotion.SAD -> SanamEmotion.HAPPY
                    }
                    onEmotionChange?.invoke(nextEmotion)
                }
                .testTag("sanam_girl_avatar")
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                val cx = w / 2f
                val cy = h / 2f
                val r = (size.minDimension / 2f)

                // 1. Emotion Color-Changing Halo & Soft Background Circle
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryEmotionColor.copy(alpha = 0.42f),
                            secondaryEmotionColor.copy(alpha = 0.18f),
                            Color(0xFF101426)
                        ),
                        center = Offset(cx, cy),
                        radius = r * auraPulse
                    ),
                    radius = r * 0.96f,
                    center = Offset(cx, cy)
                )

                drawCircle(
                    brush = Brush.linearGradient(
                        colors = listOf(primaryEmotionColor, secondaryEmotionColor)
                    ),
                    radius = r * 0.93f,
                    center = Offset(cx, cy),
                    style = Stroke(width = r * 0.045f)
                )

                // 2. Back Anime Hair Silhouette
                val hairDark = Color(0xFF1B1936)
                val hairHighlight = primaryEmotionColor.copy(alpha = 0.35f)
                drawOval(
                    color = hairDark,
                    topLeft = Offset(cx - r * 0.68f, cy - r * 0.68f),
                    size = Size(r * 1.36f, r * 1.38f)
                )

                // 3. Cute Anime Face Contour (Soft Warm Peach Skin)
                val skinColor = Color(0xFFFFEFE6)
                val skinShadow = Color(0xFFFFDFD0)
                drawOval(
                    brush = Brush.verticalGradient(
                        colors = listOf(skinColor, skinShadow),
                        startY = cy - r * 0.45f,
                        endY = cy + r * 0.58f
                    ),
                    topLeft = Offset(cx - r * 0.54f, cy - r * 0.44f),
                    size = Size(r * 1.08f, r * 1.02f)
                )

                // 4. Side Hair Locks Framing Face
                val leftHairPath = Path().apply {
                    moveTo(cx - r * 0.56f, cy - r * 0.30f)
                    quadraticTo(cx - r * 0.68f, cy + r * 0.15f, cx - r * 0.44f, cy + r * 0.56f)
                    quadraticTo(cx - r * 0.48f, cy + r * 0.10f, cx - r * 0.46f, cy - r * 0.25f)
                    close()
                }
                drawPath(path = leftHairPath, color = hairDark)

                val rightHairPath = Path().apply {
                    moveTo(cx + r * 0.56f, cy - r * 0.30f)
                    quadraticTo(cx + r * 0.68f, cy + r * 0.15f, cx + r * 0.44f, cy + r * 0.56f)
                    quadraticTo(cx + r * 0.48f, cy + r * 0.10f, cx + r * 0.46f, cy - r * 0.25f)
                    close()
                }
                drawPath(path = rightHairPath, color = hairDark)

                // 5. Cheek Blush (Glows bright rosy-pink when AI says love/shy or in LOVING mode)
                val blushColor = Color(0xFFFF4D8D).copy(alpha = blushAlpha)
                val leftBlushCenter = Offset(cx - r * 0.31f, cy + r * 0.19f)
                val rightBlushCenter = Offset(cx + r * 0.31f, cy + r * 0.19f)

                drawOval(
                    color = blushColor,
                    topLeft = Offset(leftBlushCenter.x - r * 0.14f, leftBlushCenter.y - r * 0.07f),
                    size = Size(r * 0.28f, r * 0.14f)
                )
                drawOval(
                    color = blushColor,
                    topLeft = Offset(rightBlushCenter.x - r * 0.14f, rightBlushCenter.y - r * 0.07f),
                    size = Size(r * 0.28f, r * 0.14f)
                )

                // Extra cute anime blush slash lines when blushing strongly
                if (shouldBlush) {
                    val slashStroke = Stroke(width = r * 0.02f, cap = StrokeCap.Round)
                    val slashColor = Color(0xFFFF1E6E).copy(alpha = blushAlpha)
                    for (i in -1..1) {
                        val dx = i * r * 0.045f
                        drawLine(
                            color = slashColor,
                            start = Offset(leftBlushCenter.x + dx - r * 0.015f, leftBlushCenter.y + r * 0.03f),
                            end = Offset(leftBlushCenter.x + dx + r * 0.015f, leftBlushCenter.y - r * 0.03f),
                            strokeWidth = slashStroke.width,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = slashColor,
                            start = Offset(rightBlushCenter.x + dx - r * 0.015f, rightBlushCenter.y + r * 0.03f),
                            end = Offset(rightBlushCenter.x + dx + r * 0.015f, rightBlushCenter.y - r * 0.03f),
                            strokeWidth = slashStroke.width,
                            cap = StrokeCap.Round
                        )
                    }
                }

                // 6. Two Big Expressive Anime Eyes (Blink every 3 seconds)
                val eyeCenters = listOf(
                    Offset(cx - r * 0.23f, cy + r * 0.01f),
                    Offset(cx + r * 0.23f, cy + r * 0.01f)
                )
                val eyeWidth = r * 0.26f
                val maxEyeHeight = r * 0.30f
                val currentEyeHeight = (maxEyeHeight * eyeOpenFraction).coerceAtLeast(r * 0.025f)

                eyeCenters.forEachIndexed { idx, eyeCenter ->
                    if (eyeOpenFraction > 0.22f) {
                        // Sclera (white of the eye)
                        drawRoundRect(
                            color = Color.White,
                            topLeft = Offset(eyeCenter.x - eyeWidth / 2f, eyeCenter.y - currentEyeHeight / 2f),
                            size = Size(eyeWidth, currentEyeHeight),
                            cornerRadius = CornerRadius(eyeWidth * 0.48f, eyeWidth * 0.48f)
                        )

                        // Big Anime Iris with Emotion Color Gradient
                        val irisW = eyeWidth * 0.82f
                        val irisH = currentEyeHeight * 0.86f
                        drawOval(
                            brush = Brush.verticalGradient(
                                colors = listOf(
                                    Color(0xFF1F1B3A),
                                    primaryEmotionColor,
                                    secondaryEmotionColor
                                ),
                                startY = eyeCenter.y - irisH / 2f,
                                endY = eyeCenter.y + irisH / 2f
                            ),
                            topLeft = Offset(eyeCenter.x - irisW / 2f, eyeCenter.y - irisH / 2f),
                            size = Size(irisW, irisH)
                        )

                        // Deep pupil
                        val pupilR = (irisW * 0.26f).coerceAtMost(currentEyeHeight * 0.35f)
                        drawCircle(
                            color = Color(0xFF121024),
                            radius = pupilR,
                            center = eyeCenter
                        )

                        // Big top-left anime starlight catchlight
                        drawCircle(
                            color = Color.White,
                            radius = irisW * 0.20f,
                            center = Offset(eyeCenter.x - irisW * 0.18f, eyeCenter.y - irisH * 0.20f)
                        )
                        // Small bottom-right sparkle catchlight
                        drawCircle(
                            color = Color.White.copy(alpha = 0.9f),
                            radius = irisW * 0.10f,
                            center = Offset(eyeCenter.x + irisW * 0.18f, eyeCenter.y + irisH * 0.18f)
                        )

                        // Sad teary shimmer at bottom of eye when SAD
                        if (emotion == SanamEmotion.SAD) {
                            drawOval(
                                color = Color(0xFFBAE6FD).copy(alpha = 0.85f),
                                topLeft = Offset(eyeCenter.x - irisW * 0.32f, eyeCenter.y + irisH * 0.22f),
                                size = Size(irisW * 0.64f, irisH * 0.22f)
                            )
                        }

                        // Upper thick anime eyelash curve
                        val lashSign = if (idx == 0) -1f else 1f
                        drawArc(
                            color = Color(0xFF16132B),
                            startAngle = 195f,
                            sweepAngle = 150f,
                            useCenter = false,
                            topLeft = Offset(eyeCenter.x - eyeWidth * 0.54f, eyeCenter.y - currentEyeHeight * 0.54f),
                            size = Size(eyeWidth * 1.08f, currentEyeHeight * 0.75f),
                            style = Stroke(width = r * 0.042f, cap = StrokeCap.Round)
                        )
                        // Outer eyelash wing tip
                        drawLine(
                            color = Color(0xFF16132B),
                            start = Offset(eyeCenter.x + lashSign * (eyeWidth * 0.48f), eyeCenter.y - currentEyeHeight * 0.25f),
                            end = Offset(eyeCenter.x + lashSign * (eyeWidth * 0.60f), eyeCenter.y - currentEyeHeight * 0.36f),
                            strokeWidth = r * 0.035f,
                            cap = StrokeCap.Round
                        )
                    } else {
                        // Closed blinking eye arc (every 3 seconds)
                        drawArc(
                            color = Color(0xFF16132B),
                            startAngle = 15f,
                            sweepAngle = 150f,
                            useCenter = false,
                            topLeft = Offset(eyeCenter.x - eyeWidth / 2f, eyeCenter.y - r * 0.05f),
                            size = Size(eyeWidth, r * 0.10f),
                            style = Stroke(width = r * 0.04f, cap = StrokeCap.Round)
                        )
                    }
                }

                // 7. Emotion-Reactive Eyebrows
                val browY = cy - r * 0.21f
                val browColor = Color(0xFF28234A)
                when (emotion) {
                    SanamEmotion.SAD -> {
                        // Sympathetic / sad tilted eyebrows
                        drawLine(
                            color = browColor,
                            start = Offset(cx - r * 0.34f, browY + r * 0.03f),
                            end = Offset(cx - r * 0.13f, browY - r * 0.04f),
                            strokeWidth = r * 0.03f,
                            cap = StrokeCap.Round
                        )
                        drawLine(
                            color = browColor,
                            start = Offset(cx + r * 0.13f, browY - r * 0.04f),
                            end = Offset(cx + r * 0.34f, browY + r * 0.03f),
                            strokeWidth = r * 0.03f,
                            cap = StrokeCap.Round
                        )
                    }
                    SanamEmotion.HAPPY, SanamEmotion.LOVING -> {
                        // Soft cheerful arched eyebrows
                        drawArc(
                            color = browColor,
                            startAngle = 200f,
                            sweepAngle = 140f,
                            useCenter = false,
                            topLeft = Offset(cx - r * 0.35f, browY - r * 0.03f),
                            size = Size(r * 0.24f, r * 0.08f),
                            style = Stroke(width = r * 0.028f, cap = StrokeCap.Round)
                        )
                        drawArc(
                            color = browColor,
                            startAngle = 200f,
                            sweepAngle = 140f,
                            useCenter = false,
                            topLeft = Offset(cx + r * 0.11f, browY - r * 0.03f),
                            size = Size(r * 0.24f, r * 0.08f),
                            style = Stroke(width = r * 0.028f, cap = StrokeCap.Round)
                        )
                    }
                }

                // 8. Cute Tiny Anime Nose Dot
                drawCircle(
                    color = Color(0xFFE5A996),
                    radius = r * 0.016f,
                    center = Offset(cx, cy + r * 0.14f)
                )

                // 9. Mouth: Smile when Happy / Loving, gentle sad arc when Sad
                val mouthY = cy + r * 0.29f
                val mouthColor = Color(0xFFD94862)
                when (emotion) {
                    SanamEmotion.HAPPY, SanamEmotion.LOVING -> {
                        // Happy / Loving smile
                        val smileW = r * 0.24f
                        val smileH = r * (0.12f + 0.05f * talkMouthBounce)
                        if (emotion == SanamEmotion.LOVING || isSpeaking) {
                            // Open sweet anime smile with warm pink inner mouth
                            drawArc(
                                color = Color(0xFFFF6B8B),
                                startAngle = 0f,
                                sweepAngle = 180f,
                                useCenter = true,
                                topLeft = Offset(cx - smileW / 2f, mouthY - smileH / 2f),
                                size = Size(smileW, smileH)
                            )
                        }
                        drawArc(
                            color = mouthColor,
                            startAngle = 10f,
                            sweepAngle = 160f,
                            useCenter = false,
                            topLeft = Offset(cx - smileW / 2f, mouthY - smileH / 2f),
                            size = Size(smileW, smileH),
                            style = Stroke(width = r * 0.034f, cap = StrokeCap.Round)
                        )
                    }
                    SanamEmotion.SAD -> {
                        // Gentle sad downturned mouth arc
                        val sadW = r * 0.20f
                        val sadH = r * 0.09f
                        drawArc(
                            color = mouthColor,
                            startAngle = 195f,
                            sweepAngle = 150f,
                            useCenter = false,
                            topLeft = Offset(cx - sadW / 2f, mouthY),
                            size = Size(sadW, sadH),
                            style = Stroke(width = r * 0.032f, cap = StrokeCap.Round)
                        )
                    }
                }

                // 10. Front Anime Hair Bangs / Fringe
                val bangsPath = Path().apply {
                    moveTo(cx - r * 0.56f, cy - r * 0.20f)
                    quadraticTo(cx - r * 0.45f, cy - r * 0.65f, cx, cy - r * 0.66f)
                    quadraticTo(cx + r * 0.45f, cy - r * 0.65f, cx + r * 0.56f, cy - r * 0.20f)
                    // Scalloped anime fringe spikes across forehead
                    quadraticTo(cx + r * 0.36f, cy - r * 0.34f, cx + r * 0.22f, cy - r * 0.14f)
                    quadraticTo(cx + r * 0.08f, cy - r * 0.32f, cx, cy - r * 0.12f)
                    quadraticTo(cx - r * 0.08f, cy - r * 0.32f, cx - r * 0.22f, cy - r * 0.14f)
                    quadraticTo(cx - r * 0.36f, cy - r * 0.34f, cx - r * 0.56f, cy - r * 0.20f)
                    close()
                }
                drawPath(path = bangsPath, color = hairDark)

                // Luminous anime hair crown highlight arc (changes color with emotion)
                drawArc(
                    color = hairHighlight,
                    startAngle = 205f,
                    sweepAngle = 130f,
                    useCenter = false,
                    topLeft = Offset(cx - r * 0.38f, cy - r * 0.52f),
                    size = Size(r * 0.76f, r * 0.30f),
                    style = Stroke(width = r * 0.035f, cap = StrokeCap.Round)
                )
            }
        }

        // Compact 3-Emotion Selector Row (Happy • Sad • Loving) with color change
        if (onEmotionChange != null) {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SanamEmotion.entries.forEach { item ->
                    val isSelected = item == emotion
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (isSelected) item.primaryColor.copy(alpha = 0.24f)
                        else Color(0xFF15192B).copy(alpha = 0.75f),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { onEmotionChange(item) }
                            .testTag("sanam_emotion_${item.name.lowercase()}")
                    ) {
                        Text(
                            text = item.label,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) item.primaryColor else Color.White.copy(alpha = 0.75f),
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            modifier = Modifier.padding(horizontal = 9.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }
    }
}
