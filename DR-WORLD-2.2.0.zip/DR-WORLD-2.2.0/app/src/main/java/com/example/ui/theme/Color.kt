package com.example.ui.theme

import androidx.compose.ui.graphics.Color

enum class AuraTheme(
    val title: String,
    val subtitle: String,
    val primary: Color,
    val secondary: Color,
    val tertiary: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val glowCore: Color,
    val glowOuter: Color
) {
    CYBER_ELECTRIC(
        title = "Cyber Electric",
        subtitle = "DR WORLD Signature Neon Cyan & Pulse Magenta",
        primary = Color(0xFF00F0FF),
        secondary = Color(0xFFFF2A85),
        tertiary = Color(0xFF7C4DFF),
        background = Color(0xFF070913),
        surface = Color(0xFF101426),
        surfaceVariant = Color(0xFF1A213B),
        glowCore = Color(0xFF00F0FF),
        glowOuter = Color(0xFFFF2A85)
    ),
    ROSE_BLOOM(
        title = "Rose Bloom",
        subtitle = "Sanam Girlfriend Persona Warm Rose & Velvet",
        primary = Color(0xFFFF3B7F),
        secondary = Color(0xFFFF8FA3),
        tertiary = Color(0xFFFFC2D1),
        background = Color(0xFF12070D),
        surface = Color(0xFF210F1A),
        surfaceVariant = Color(0xFF331828),
        glowCore = Color(0xFFFF3B7F),
        glowOuter = Color(0xFFFF8FA3)
    ),
    EMERALD_ZEN(
        title = "Emerald Zen",
        subtitle = "Bio-Matrix Tactical HUD & Calm Focus",
        primary = Color(0xFF00E676),
        secondary = Color(0xFF1DE9B6),
        tertiary = Color(0xFF69F0AE),
        background = Color(0xFF06110C),
        surface = Color(0xFF0D1F17),
        surfaceVariant = Color(0xFF163326),
        glowCore = Color(0xFF00E676),
        glowOuter = Color(0xFF1DE9B6)
    ),
    SOLAR_AMBER(
        title = "Solar Amber",
        subtitle = "JARVIS Autonomous Gold & High-Energy Core",
        primary = Color(0xFFFFB300),
        secondary = Color(0xFFFF6D00),
        tertiary = Color(0xFFFFE57F),
        background = Color(0xFF120D06),
        surface = Color(0xFF21180C),
        surfaceVariant = Color(0xFF332614),
        glowCore = Color(0xFFFFB300),
        glowOuter = Color(0xFFFF6D00)
    ),
    VELVET_TWILIGHT(
        title = "Velvet Twilight",
        subtitle = "Deep Neural Violet & Starlight Hologram",
        primary = Color(0xFFB388FF),
        secondary = Color(0xFFEA80FC),
        tertiary = Color(0xFF8C9EFF),
        background = Color(0xFF0A0714),
        surface = Color(0xFF151026),
        surfaceVariant = Color(0xFF231B3D),
        glowCore = Color(0xFFB388FF),
        glowOuter = Color(0xFFEA80FC)
    )
}

enum class OrbStyle(val title: String, val tagline: String) {
    CLASSIC("Classic", "Smooth concentric DR WORLD breathing rings"),
    ENERGY("Energy", "Plasma wave harmonics & neural particle flare"),
    NEON("Neon", "Cybernetic hex-grid & laser pulse geometry"),
    SANAM_AVATAR("Sanam Avatar", "Holographic Sanam Companion Portrait & Wave HUD")
}
