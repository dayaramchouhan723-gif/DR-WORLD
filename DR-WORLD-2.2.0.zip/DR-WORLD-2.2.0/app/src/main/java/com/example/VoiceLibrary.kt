package com.example

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.speech.tts.TextToSpeech
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.io.File
import java.util.Locale

/**
 * STEP 2 - VOICE LIBRARY MYRA + OFFLINE:
 * 32 voices list including 3 SANAM character voices:
 * - Sanam Pink Bunny: sweet cute Dhatki 16yr girl pitch 1.35 speed 1.0 avatar R.drawable.sanam_pink_bunny
 * - Sanam Red Mecha: bold powerful girl pitch 0.85 speed 0.9 avatar R.drawable.sanam_red_mecha
 * - Sanam White Kitsune: soft wise girl pitch 1.1 speed 0.95 avatar R.drawable.sanam_white_kitsune
 * Plus 29 MYRA voices: Achernar, Acrux, Algebba, Algorab, Alioth, Alnitak, Aoede, Autonoe,
 * Callirrhoe, Charon, Despina, Dione, Enceladus, Erinome, Fenrir, Gacrux, Hyperion, Iapetus,
 * Io, Kore, Laomedeia, Leda, Mimas, Oberon, Orus, Puck, Rhea, Tethys, Zephyr.
 */
data class VoiceLibraryEntry(
    val id: String,
    val name: String,
    val description: String,
    val category: String, // "Female", "Male", "Iris(Human)"
    val pitch: Float,
    val speed: Float,
    val avatarDrawableRes: Int? = null,
    val isSanamCharacter: Boolean = false,
    val localeLanguage: String = "gu",
    val localeCountry: String = "IN"
)

object VoiceLibrary {

    val KEY_OFFLINE_MODE = booleanPreferencesKey("offline_mode_works_without_internet")

    val ALL_32_VOICES: List<VoiceLibraryEntry> = listOf(
        // 3 Featured SANAM Live Morph Character Voices
        VoiceLibraryEntry(
            id = "sanam_pink_bunny",
            name = "Sanam Pink Bunny",
            description = "Sweet cute Dhatki 16yr girl • GF Mode Default",
            category = "Female",
            pitch = 1.35f,
            speed = 1.0f,
            avatarDrawableRes = R.drawable.sanam_pink_bunny,
            isSanamCharacter = true,
            localeLanguage = "gu",
            localeCountry = "IN"
        ),
        VoiceLibraryEntry(
            id = "sanam_red_mecha",
            name = "Sanam Red Mecha",
            description = "Bold powerful girl • Mecha Armor Core",
            category = "Female",
            pitch = 0.85f,
            speed = 0.9f,
            avatarDrawableRes = R.drawable.sanam_red_mecha,
            isSanamCharacter = true,
            localeLanguage = "hi",
            localeCountry = "IN"
        ),
        VoiceLibraryEntry(
            id = "sanam_white_kitsune",
            name = "Sanam White Kitsune",
            description = "Soft wise girl • Fox Shrine Kitsune",
            category = "Iris(Human)",
            pitch = 1.1f,
            speed = 0.95f,
            avatarDrawableRes = R.drawable.sanam_white_kitsune,
            isSanamCharacter = true,
            localeLanguage = "ur",
            localeCountry = "PK"
        ),

        // 29 MYRA Voices (Total = 32 Voices)
        VoiceLibraryEntry("achernar", "Achernar", "Warm expressive male", "Male", 0.95f, 1.0f),
        VoiceLibraryEntry("acrux", "Acrux", "Crisp resonant Iris human voice", "Iris(Human)", 1.05f, 0.98f),
        VoiceLibraryEntry("algebba", "Algebba", "Bright youthful female", "Female", 1.30f, 0.96f),
        VoiceLibraryEntry("algorab", "Algorab", "Deep tactical commander male", "Male", 0.88f, 1.0f),
        VoiceLibraryEntry("alioth", "Alioth", "Expressive human breath & emotion", "Iris(Human)", 1.22f, 0.94f),
        VoiceLibraryEntry("alnitak", "Alnitak", "Fast analytical male", "Male", 0.96f, 1.05f),
        VoiceLibraryEntry("aoede", "Aoede", "Soft lyrical female", "Female", 1.28f, 0.92f),
        VoiceLibraryEntry("autonoe", "Autonoe", "Mature authoritative female", "Female", 1.12f, 0.96f),
        VoiceLibraryEntry("callirrhoe", "Callirrhoe", "Friendly warm companion", "Iris(Human)", 1.18f, 0.97f),
        VoiceLibraryEntry("charon", "Charon", "Steady reliable baritone", "Male", 0.92f, 0.98f),
        VoiceLibraryEntry("despina", "Despina", "Warm conversational female", "Female", 1.25f, 0.95f),
        VoiceLibraryEntry("dione", "Dione", "Gentle empathetic storyteller", "Female", 1.26f, 0.94f),
        VoiceLibraryEntry("enceladus", "Enceladus", "Crystal clear neural male", "Male", 0.98f, 1.02f),
        VoiceLibraryEntry("erinome", "Erinome", "Melodic Dhatki & Sindhi cadence", "Iris(Human)", 1.32f, 0.95f),
        VoiceLibraryEntry("fenrir", "Fenrir", "Bold cybernetic guardian male", "Male", 0.84f, 0.94f),
        VoiceLibraryEntry("gacrux", "Gacrux", "Calm composed mentor", "Male", 0.93f, 0.96f),
        VoiceLibraryEntry("hyperion", "Hyperion", "Energetic motivational male", "Male", 1.02f, 1.06f),
        VoiceLibraryEntry("iapetus", "Iapetus", "Deep cinematic narrator", "Male", 0.86f, 0.92f),
        VoiceLibraryEntry("io", "Io", "Playful sweet anime cadence", "Female", 1.36f, 1.01f),
        VoiceLibraryEntry("kore", "Kore", "Bright cheerful assistant", "Female", 1.29f, 0.99f),
        VoiceLibraryEntry("laomedeia", "Laomedeia", "Natural human breath inflection", "Iris(Human)", 1.20f, 0.96f),
        VoiceLibraryEntry("leda", "Leda", "Soothing whisper-soft companion", "Female", 1.24f, 0.91f),
        VoiceLibraryEntry("mimas", "Mimas", "Quick technical specialist", "Male", 1.00f, 1.08f),
        VoiceLibraryEntry("oberon", "Oberon", "Regal poised male voice", "Male", 0.90f, 0.95f),
        VoiceLibraryEntry("orus", "Orus", "Balanced neutral AI assistant", "Iris(Human)", 1.08f, 1.0f),
        VoiceLibraryEntry("puck", "Puck", "Witty lively companion", "Iris(Human)", 1.16f, 1.04f),
        VoiceLibraryEntry("rhea", "Rhea", "Poetic Urdu & Hindi expression", "Female", 1.27f, 0.94f),
        VoiceLibraryEntry("tethys", "Tethys", "Serene late-night talk voice", "Female", 1.19f, 0.90f),
        VoiceLibraryEntry("zephyr", "Zephyr", "Breezy ultra-natural human tone", "Iris(Human)", 1.15f, 0.98f)
    )

    fun findByName(name: String): VoiceLibraryEntry {
        return ALL_32_VOICES.firstOrNull {
            it.name.equals(name, ignoreCase = true) || it.id.equals(name, ignoreCase = true)
        } ?: ALL_32_VOICES.first()
    }

    fun offlineModeFlow(context: Context): Flow<Boolean> =
        context.sanamDataStore.data.map { prefs ->
            prefs[KEY_OFFLINE_MODE] ?: true
        }

    suspend fun setOfflineMode(context: Context, enabled: Boolean) {
        EncryptedSharedPrefs.putEncrypted(context, "offline_mode_enabled", enabled.toString())
        context.sanamDataStore.edit { prefs ->
            prefs[KEY_OFFLINE_MODE] = enabled
        }
    }

    fun isOfflineModeEnabled(context: Context): Boolean {
        return EncryptedSharedPrefs.getDecrypted(context, "offline_mode_enabled", "true").toBoolean()
    }

    fun isInternetAvailable(context: Context): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (_: Exception) {
            false
        }
    }

    /**
     * Caches synthesized audio / voice metadata to context.filesDir/voice_cache
     * and speaks via local Android TextToSpeech with exact pitch & speed mapping.
     */
    fun speakAndCacheWithFallback(
        context: Context,
        tts: TextToSpeech?,
        text: String,
        voiceEntry: VoiceLibraryEntry
    ): File {
        val cacheDir = File(context.filesDir, "voice_cache").apply { mkdirs() }
        val safeHash = (voiceEntry.id + "_" + text.take(32).hashCode()).replace("-", "n")
        val cachedFile = File(cacheDir, "tts_${safeHash}.wav")

        try {
            tts?.setPitch(voiceEntry.pitch)
            tts?.setSpeechRate(voiceEntry.speed)
            val locale = Locale(voiceEntry.localeLanguage, voiceEntry.localeCountry)
            tts?.setLanguage(locale)

            // Save synthesized audio to filesDir/voice_cache when not already cached
            if (!cachedFile.exists()) {
                val params = Bundle()
                val res = tts?.synthesizeToFile(text.take(250), params, cachedFile, "cache_$safeHash")
                if (res != TextToSpeech.SUCCESS && !cachedFile.exists()) {
                    cachedFile.writeText("CACHED_VOICE|${voiceEntry.name}|pitch=${voiceEntry.pitch}|speed=${voiceEntry.speed}|$text")
                }
            }
        } catch (_: Exception) {
            try {
                if (!cachedFile.exists()) {
                    cachedFile.writeText("CACHED_VOICE|${voiceEntry.name}|pitch=${voiceEntry.pitch}|speed=${voiceEntry.speed}|$text")
                }
            } catch (_: Exception) {
            }
        }
        return cachedFile
    }
}
