package com.example

import android.app.Activity
import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.speech.tts.TextToSpeech
import androidx.compose.ui.graphics.toArgb
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.sanam.controller.AppLauncher
import com.example.sanam.controller.CallHelper
import com.example.sanam.controller.DeviceActionManager
import com.example.sanam.controller.SmsHelper
import com.example.ui.theme.AuraTheme
import com.example.ui.theme.OrbStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.util.Locale

enum class SanamLanguage(
    val code: String,
    val label: String,
    val nativeScript: String,
    val locale: Locale,
    val greeting: String
) {
    DHATKI(
        code = "Dhatki",
        label = "Dhatki",
        nativeScript = "ڌاٽڪي / धाटकी",
        locale = Locale("gu", "IN"),
        greeting = "Kiyan aahin munhinja pyara! Main thari Sanam AI aahiyan."
    ),
    SINDHI(
        code = "Sindhi",
        label = "Sindhi",
        nativeScript = "سنڌي",
        locale = Locale("sd", "PK"),
        greeting = "ڪيئن آهين منهنجا سڄڻ! مان تنهنجي سنم آهيان."
    ),
    URDU(
        code = "Urdu",
        label = "Urdu",
        nativeScript = "اردو",
        locale = Locale("ur", "PK"),
        greeting = "السلام علیکم میرے ہمسفر! میں آپ کی صنم اے آئی ہوں۔"
    ),
    HINDI(
        code = "Hindi",
        label = "Hindi",
        nativeScript = "हिन्दी / Hinglish",
        locale = Locale("hi", "IN"),
        greeting = "Namaste Jaan! Main aapki Sanam AI (DR WORLD) hoon."
    )
}

enum class SanamMode(val title: String, val badge: String, val description: String) {
    GIRLFRIEND("Girlfriend & Dost", "💖 Sweet DR WORLD Cadence", "Caring, loving & empathetic emotional companion"),
    JARVIS("JARVIS Controller", "⚡ Autonomous Control", "Direct Call, WhatsApp, SMS, Apps, Flashlight & Maps"),
    SOCIAL_AGENT("Social Media Agent", "📸 Insta • FB • Status", "Post photos & captions to Instagram, Facebook & WhatsApp Status"),
    VISUAL_LENS("Visual Lens & Screen", "👁️ Lens + Screen Reader", "Camera analysis, MediaProjection Screenshot & Accessibility Reader"),
    MISSIONS("Triggers & Missions", "🎯 DR WORLD Mission Mode", "Daily voice alarms, scheduled triggers & task reminders"),
    GAMING_SECURITY("Gaming & Security", "🛡️ HUD + Touch Guard", "Gaming telemetry HUD, Pocket Touch Guard & Anti-Theft sensor")
}

class SanamViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val db = SanamDatabase.getInstance(application)
    private val repository = SanamRepository(db.sanamDao(), db.missionDao())
    val securityManager = MyraSecurityManager(application)

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    val messages: StateFlow<List<ChatMessageEntity>> = repository.allMessages
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val conversationSessions: StateFlow<List<ConversationSessionEntity>> = repository.allConversationSessions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeSessionId = MutableStateFlow("session_dayaram_main")
    val activeSessionId: StateFlow<String> = _activeSessionId.asStateFlow()

    val isPremium: StateFlow<Boolean> = MutableStateFlow(true).asStateFlow()

    val memories: StateFlow<List<MemoryFactEntity>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val triggersAndMissions: StateFlow<List<TriggerMission>> = repository.allMissionsAndTriggers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val screenLogs: StateFlow<List<ScreenLogEntity>> = repository.recentScreenLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val liveScreenStream: StateFlow<List<String>> = Memory.liveScreenStream

    val isMediaProjectionActive: StateFlow<Boolean> = ScreenshotHelper.isProjectionServiceActive

    private val _selectedLanguage = MutableStateFlow(SanamLanguage.DHATKI)
    val selectedLanguage: StateFlow<SanamLanguage> = _selectedLanguage.asStateFlow()

    private val _selectedMode = MutableStateFlow(SanamMode.GIRLFRIEND)
    val selectedMode: StateFlow<SanamMode> = _selectedMode.asStateFlow()

    private val _selectedAura = MutableStateFlow(AuraTheme.CYBER_ELECTRIC)
    val selectedAura: StateFlow<AuraTheme> = _selectedAura.asStateFlow()

    private val _selectedOrbStyle = MutableStateFlow(OrbStyle.CLASSIC)
    val selectedOrbStyle: StateFlow<OrbStyle> = _selectedOrbStyle.asStateFlow()

    private val _selectedConnector = MutableStateFlow(AiModelConnector.GEMINI_FLASH)
    val selectedConnector: StateFlow<AiModelConnector> = _selectedConnector.asStateFlow()

    private val _automationPermissions = MutableStateFlow(AutomationPermissionsState())
    val automationPermissions: StateFlow<AutomationPermissionsState> = _automationPermissions.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isThinking = MutableStateFlow(false)
    val isThinking: StateFlow<Boolean> = _isThinking.asStateFlow()

    private val _voicePitch = MutableStateFlow(1.35f) // 16-year-old sweet girl voice pitch
    val voicePitch: StateFlow<Float> = _voicePitch.asStateFlow()

    private val _voiceSpeed = MutableStateFlow(0.95f)
    val voiceSpeed: StateFlow<Float> = _voiceSpeed.asStateFlow()

    private val _currentMorphModeIndex = MutableStateFlow(0)
    val currentMorphModeIndex: StateFlow<Int> = _currentMorphModeIndex.asStateFlow()

    private val _wakeWordOpenMorphCounter = MutableStateFlow(0)
    val wakeWordOpenMorphCounter: StateFlow<Int> = _wakeWordOpenMorphCounter.asStateFlow()

    private var lastCallPerm: Boolean = false
    private var lastSmsPerm: Boolean = false

    val voiceController = VoiceController(
        context = application,
        onSpeechRecognized = { spokenText, detectedLocale ->
            val matchedLang = when (detectedLocale.language) {
                "sd" -> SanamLanguage.SINDHI
                "hi" -> SanamLanguage.HINDI
                "gu" -> SanamLanguage.DHATKI
                else -> SanamLanguage.URDU
            }
            _selectedLanguage.value = matchedLang
            _voicePitch.value = if (matchedLang == SanamLanguage.DHATKI) 1.3f else 1.35f
            sendUserCommandOrMessage(
                context = getApplication(),
                input = spokenText,
                hasCallPermission = lastCallPerm,
                hasSmsPermission = lastSmsPerm
            )
        },
        onListeningStateChanged = { listening ->
            _isListening.value = listening
            if (listening) {
                _lastStatusBanner.value = "🎙️ Sanam is listening (${_selectedLanguage.value.label})..."
            }
        },
        onSpeakingStateChanged = { speaking ->
            _isSpeaking.value = speaking
        },
        onWakeWordDetected = {
            _wakeWordOpenMorphCounter.value += 1
        }
    )

    private val _touchGuardLocked = MutableStateFlow(false)
    val touchGuardLocked: StateFlow<Boolean> = _touchGuardLocked.asStateFlow()

    private val _myraSecurityArmed = MutableStateFlow(true)
    val myraSecurityArmed: StateFlow<Boolean> = _myraSecurityArmed.asStateFlow()

    private val _gamingBoostActive = MutableStateFlow(false)
    val gamingBoostActive: StateFlow<Boolean> = _gamingBoostActive.asStateFlow()

    private val _flashlightOn = MutableStateFlow(false)
    val flashlightOn: StateFlow<Boolean> = _flashlightOn.asStateFlow()

    private val _telemetry = MutableStateFlow(
        SocialAgent.getSystemTelemetry(application, false)
    )
    val telemetry: StateFlow<SystemTelemetry> = _telemetry.asStateFlow()

    private val _selectedImageBitmap = MutableStateFlow<Bitmap?>(null)
    val selectedImageBitmap: StateFlow<Bitmap?> = _selectedImageBitmap.asStateFlow()

    private val _selectedImageFile = MutableStateFlow<File?>(null)
    val selectedImageFile: StateFlow<File?> = _selectedImageFile.asStateFlow()

    private val _latestVisualTelemetry = MutableStateFlow<VisualContentTelemetry?>(null)
    val latestVisualTelemetry: StateFlow<VisualContentTelemetry?> = _latestVisualTelemetry.asStateFlow()

    private val _latestVisualLensAnalysis = MutableStateFlow<String?>(null)
    val latestVisualLensAnalysis: StateFlow<String?> = _latestVisualLensAnalysis.asStateFlow()

    private val _lastStatusBanner = MutableStateFlow(
        "Hello, Dayaram Chouhan (Online Ready) • DR WORLD Free Forever ♾️ Unlimited"
    )
    val lastStatusBanner: StateFlow<String> = _lastStatusBanner.asStateFlow()

    private var lastProcessedCaptureTimestamp: Long = 0L

    init {
        Memory.init(application)
        tts = TextToSpeech(application, this)
        securityManager.startMonitoring()
        seedInitialDataIfNeeded()
        startTelemetryTicker()
        observeMediaProjectionCaptures()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.setPitch(_voicePitch.value)
            tts?.setSpeechRate(_voiceSpeed.value)
            tts?.language = _selectedLanguage.value.locale
        }
    }

    /**
     * Observes frames captured by MediaProjectionService or ScreenshotHelper
     * and runs Visual Lens content analysis automatically when requested.
     */
    private fun observeMediaProjectionCaptures() {
        viewModelScope.launch {
            ScreenshotHelper.latestMediaProjectionCapture.collectLatest { captured ->
                if (captured != null && captured.timestamp != lastProcessedCaptureTimestamp) {
                    lastProcessedCaptureTimestamp = captured.timestamp
                    _selectedImageBitmap.value = captured.bitmap
                    _selectedImageFile.value = captured.file
                    _latestVisualTelemetry.value = captured.visualTelemetry
                    _lastStatusBanner.value =
                        "📸 ${captured.visualTelemetry.captureSource} (${captured.visualTelemetry.resolution}) ready!"

                    if (captured.analyzeImmediately) {
                        val prompt = captured.customAnalysisPrompt
                            ?: "Visual Lens Full-Screen Analysis (${captured.visualTelemetry.resolution}, Dominant Color ${captured.visualTelemetry.dominantHexColor}): Describe the UI/scene on screen, extract key text, and suggest a ${selectedLanguage.value.label} social media caption."
                        performVisualLensContentAnalysis(
                            bitmap = captured.bitmap,
                            telemetry = captured.visualTelemetry,
                            prompt = prompt
                        )
                    }
                }
            }
        }
    }

    fun performVisualLensContentAnalysis(
        bitmap: Bitmap? = _selectedImageBitmap.value,
        telemetry: VisualContentTelemetry? = _latestVisualTelemetry.value,
        prompt: String
    ) {
        val targetBitmap = bitmap ?: return
        viewModelScope.launch {
            _isThinking.value = true
            _lastStatusBanner.value = "👁️ Visual Lens analyzing screen content in ${_selectedLanguage.value.label}..."
            val memoriesText = memories.value.take(6).joinToString("; ") { "${it.keyTitle}: ${it.factValue}" }
            val telemetrySummary = telemetry?.let {
                "Screen Resolution: ${it.resolution}, Aspect Ratio: ${it.aspectRatio}, Brightness: ${it.averageBrightnessPercent}%, Dominant Palette: ${it.dominantHexColor}, Source: ${it.captureSource}"
            } ?: "Visual Lens Image Capture"

            val reply = GeminiClient.generateSanamReply(
                prompt = "$prompt\n[Visual Telemetry: $telemetrySummary]",
                language = _selectedLanguage.value.code,
                mode = SanamMode.VISUAL_LENS.title,
                memoriesSummary = memoriesText,
                actionExecutedNote = telemetrySummary,
                imageBitmap = targetBitmap
            )
            _isThinking.value = false
            _latestVisualLensAnalysis.value = reply
            _lastStatusBanner.value = "✅ Visual Lens analysis complete (${_selectedLanguage.value.label})"

            repository.addMessage(
                ChatMessageEntity(
                    sender = "SANAM",
                    text = reply,
                    language = _selectedLanguage.value.code,
                    mode = SanamMode.VISUAL_LENS.title,
                    actionBadge = "👁️ Visual Lens AI"
                )
            )
            speakText(reply)
        }
    }

    /**
     * Handles the ActivityResult from MediaProjectionManager.createScreenCaptureIntent()
     */
    fun onMediaProjectionPermissionResult(
        context: Context,
        activity: Activity,
        resultCode: Int,
        data: Intent?,
        customPrompt: String? = null
    ) {
        if (resultCode == Activity.RESULT_OK && data != null) {
            _lastStatusBanner.value = "🟢 Starting MediaProjectionService VirtualDisplay capture..."
            ScreenshotHelper.startMediaProjectionCaptureService(
                context = context,
                resultCode = resultCode,
                resultData = data,
                analyzeImmediately = true,
                customPrompt = customPrompt
            )
        } else {
            // Fallback to immediate Window capture if user cancels system projection dialog
            _lastStatusBanner.value = "📸 Capturing window screenshot for Visual Lens..."
            ScreenshotHelper.takeScreenshot(
                activity = activity,
                analyzeImmediately = true,
                customPrompt = customPrompt
            )
        }
    }

    fun captureFrameFromActiveProjectionOrWindow(activity: Activity, customPrompt: String? = null) {
        if (isMediaProjectionActive.value) {
            _lastStatusBanner.value = "📸 Capturing full-screen frame via MediaProjectionService..."
            ScreenshotHelper.requestFrameFromActiveProjection(activity, customPrompt)
        } else {
            ScreenshotHelper.takeScreenshot(
                activity = activity,
                analyzeImmediately = true,
                customPrompt = customPrompt
            )
        }
    }

    fun stopMediaProjectionService(context: Context) {
        ScreenshotHelper.stopMediaProjectionService(context)
        _lastStatusBanner.value = "⏹️ MediaProjectionService stopped."
    }

    private fun startTelemetryTicker() {
        viewModelScope.launch {
            while (true) {
                _telemetry.value = SocialAgent.getSystemTelemetry(
                    getApplication(),
                    _flashlightOn.value
                )
                delay(5000L)
            }
        }
    }

    private fun seedInitialDataIfNeeded() {
        viewModelScope.launch {
            val existingMissions = db.missionDao().getAll()
            if (existingMissions.isEmpty()) {
                repository.addTriggerMission(
                    TriggerMission(
                        time = "08:00 AM",
                        task = "Good morning bolna & Dhatki/Hindi pyari wish dena",
                        isMission = false,
                        category = "Morning Trigger"
                    )
                )
                repository.addTriggerMission(
                    TriggerMission(
                        time = "11:00 AM",
                        task = "Pani peene ki yaad dilana (Hydration Care)",
                        isMission = true,
                        category = "Health Mission"
                    )
                )
                repository.addTriggerMission(
                    TriggerMission(
                        time = "06:30 PM",
                        task = "Instagram & WhatsApp Status post share karna",
                        isMission = true,
                        category = "Social Agent Mission"
                    )
                )
                repository.addTriggerMission(
                    TriggerMission(
                        time = "10:30 PM",
                        task = "Good night sweet voice note & alarm check",
                        isMission = false,
                        category = "Night Trigger"
                    )
                )

                repository.addMemory(
                    MemoryFactEntity(
                        keyTitle = "Creator & Companion Bond",
                        factValue = "Dayaram Chouhan (Special Girlfriend + JARVIS Companion Bond)",
                        category = "Bond"
                    )
                )
                repository.addMemory(
                    MemoryFactEntity(
                        keyTitle = "Favorite Languages",
                        factValue = "Dhatki (ڌاٽڪي), Sindhi (سنڌي), Urdu (اردو), Hindi (हिन्दी)",
                        category = "Preference"
                    )
                )
                repository.addMemory(
                    MemoryFactEntity(
                        keyTitle = "Quick Contacts",
                        factValue = "Dayaram, Mumma, Rahul, Ammi",
                        category = "Contact"
                    )
                )

                repository.addMessage(
                    ChatMessageEntity(
                        sender = "SANAM",
                        text = "Kiyan aahin munhinja pyara Dayaram Boss! 💖 Main thari Sanam AI (Free Forever ♾️ Unlimited) aahiyan. Accessibility Controller, Hey Sanam Wake Word, Social Media Agent (Insta/FB/WhatsApp Status), MediaProjection Visual Lens, aur Room Chat History sab ready aahin!",
                        language = "Dhatki",
                        mode = SanamMode.GIRLFRIEND.title,
                        actionBadge = "DR WORLD Beater Ready",
                        sessionId = "session_dayaram_main"
                    )
                )

                repository.upsertConversationSession(
                    ConversationSessionEntity(
                        sessionId = "session_dayaram_main",
                        title = "Dayaram Boss & Sanam AI Companion",
                        lastMessagePreview = "Kiyan aahin munhinja pyara Dayaram Boss! 💖 Main thari Sanam AI aahiyan.",
                        language = "Dhatki",
                        mode = SanamMode.GIRLFRIEND.title,
                        messageCount = 1
                    )
                )
            }
        }
    }

    fun selectLanguage(lang: SanamLanguage, context: Context? = null) {
        _selectedLanguage.value = lang
        val targetPitch = if (lang == SanamLanguage.DHATKI) 1.3f else 1.35f
        _voicePitch.value = targetPitch
        tts?.setPitch(targetPitch)
        tts?.language = lang.locale
        if (context != null) {
            voiceController.activateLanguageButton(context, lang)
        } else {
            voiceController.applyLocaleToTts(lang.locale, targetPitch)
        }
        _lastStatusBanner.value = "${lang.label} Active (${lang.nativeScript})"
        speakText(lang.greeting)
    }

    fun startInAppVoiceListening(hasCallPermission: Boolean, hasSmsPermission: Boolean) {
        lastCallPerm = hasCallPermission
        lastSmsPerm = hasSmsPermission
        voiceController.startListening()
    }

    fun selectMode(mode: SanamMode) {
        _selectedMode.value = mode
        _lastStatusBanner.value = "Active Mode: ${mode.title} • ${mode.badge}"
    }

    fun selectAura(aura: AuraTheme) {
        _selectedAura.value = aura
        _lastStatusBanner.value = "Aura Theme: ${aura.title} (${aura.subtitle})"
    }

    fun selectOrbStyle(style: OrbStyle) {
        _selectedOrbStyle.value = style
        _lastStatusBanner.value = "DR WORLD Orb Style: ${style.title} — ${style.tagline}"
    }

    fun selectConnector(connector: AiModelConnector) {
        _selectedConnector.value = connector
        _lastStatusBanner.value = "🤖 Active AI Connector: ${connector.displayName} (${connector.providerTag})"
    }

    fun updateAutomationPermissions(newState: AutomationPermissionsState) {
        val unlockedState = newState.copy(isPremium = true)
        _automationPermissions.value = unlockedState
        voiceController.updateWakeWordConfig(
            enabled = unlockedState.wakeWordEnabled,
            sensitivity = unlockedState.wakeWordSensitivity
        )
        _lastStatusBanner.value =
            "⚙️ Wake Word '${unlockedState.wakeWordPhrase}' (${(unlockedState.wakeWordSensitivity * 100).toInt()}%) & Automation Updated"
    }

    fun triggerHeySanamWakeWord(context: Context) {
        voiceController.triggerHeySanamWakeWord(context)
        _lastStatusBanner.value =
            "🎙️ Picovoice Free 'Hey Sanam' Wake Word Activated (${(_automationPermissions.value.wakeWordSensitivity * 100).toInt()}%)"
    }

    /**
     * Continues the last saved conversation from Room DB
     */
    fun continueLastConversation() {
        viewModelScope.launch {
            val latestSession = repository.getLatestConversationSession()
            val lastMsg = messages.value.lastOrNull()
            if (latestSession != null) {
                _activeSessionId.value = latestSession.sessionId
                val resumeAnnouncement =
                    "💬 Continuing last conversation: \"${latestSession.title}\" — ${latestSession.lastMessagePreview.take(90)}"
                _lastStatusBanner.value = resumeAnnouncement
                speakText(
                    lastMsg?.text
                        ?: "Ji Dayaram Boss, pichli baat-cheet wahin se shuru karte hain: ${latestSession.lastMessagePreview}"
                )
            } else if (lastMsg != null) {
                val resumeAnnouncement = "💬 Continuing last message: ${lastMsg.text.take(90)}"
                _lastStatusBanner.value = resumeAnnouncement
                speakText(lastMsg.text)
            } else {
                val greeting = _selectedLanguage.value.greeting
                _lastStatusBanner.value = "💬 Starting fresh conversation with Sanam AI"
                speakText(greeting)
            }
        }
    }

    fun startNewConversationSession(customTitle: String? = null) {
        viewModelScope.launch {
            val newId = "session_${System.currentTimeMillis()}"
            _activeSessionId.value = newId
            val lang = _selectedLanguage.value
            val title = customTitle?.takeIf { it.isNotBlank() }
                ?: "${lang.label} Chat • ${LocalTimezoneHelper.getFormattedLocalTimeAndZone().take(8)}"
            val welcome = "Nayi conversation shuru ho gayi Dayaram Boss! (${lang.label}) — ${lang.greeting}"
            repository.upsertConversationSession(
                ConversationSessionEntity(
                    sessionId = newId,
                    title = title,
                    lastMessagePreview = welcome,
                    language = lang.code,
                    mode = _selectedMode.value.title,
                    messageCount = 1
                )
            )
            repository.addMessage(
                ChatMessageEntity(
                    sender = "SANAM",
                    text = welcome,
                    language = lang.code,
                    mode = _selectedMode.value.title,
                    actionBadge = "💬 Saved Session",
                    sessionId = newId
                )
            )
            _lastStatusBanner.value = "💬 Saved & started conversation: $title"
            speakText(welcome)
        }
    }

    fun resumeConversationSession(session: ConversationSessionEntity) {
        viewModelScope.launch {
            _activeSessionId.value = session.sessionId
            _lastStatusBanner.value = "💬 Resumed Room Conversation: ${session.title}"
            speakText("Continuing ${session.title}: ${session.lastMessagePreview}")
        }
    }

    fun updateVoicePitch(pitch: Float) {
        _voicePitch.value = pitch
        tts?.setPitch(pitch)
        voiceController.updatePitchAndSpeed(pitch, _voiceSpeed.value)
    }

    fun updateVoiceSpeed(speed: Float) {
        _voiceSpeed.value = speed
        tts?.setSpeechRate(speed)
        voiceController.updatePitchAndSpeed(_voicePitch.value, speed)
    }

    fun applyVoiceLibraryEntry(context: Context, voice: VoiceLibraryEntry) {
        GeminiClient.activeVoiceProfileName = voice.name
        _voicePitch.value = voice.pitch
        _voiceSpeed.value = voice.speed
        tts?.setPitch(voice.pitch)
        tts?.setSpeechRate(voice.speed)
        voiceController.updatePitchAndSpeed(voice.pitch, voice.speed)
        when (voice.id) {
            "sanam_pink_bunny" -> {
                _currentMorphModeIndex.value = 0
                GeminiClient.activePersonalityMode = "GF Mode"
                selectLanguage(SanamLanguage.DHATKI, context)
            }
            "sanam_red_mecha" -> {
                _currentMorphModeIndex.value = 1
                GeminiClient.activePersonalityMode = "BF Mode"
            }
            "sanam_white_kitsune" -> {
                _currentMorphModeIndex.value = 2
                GeminiClient.activePersonalityMode = "Friend Mode"
            }
        }
    }

    fun updateMorphMode(context: Context, modeIndex: Int) {
        val safeIdx = modeIndex.coerceIn(0, 2)
        _currentMorphModeIndex.value = safeIdx
        val voiceName = LiveMorphState.modeVoiceNames.getOrElse(safeIdx) { "Sanam Pink Bunny" }
        val entry = VoiceLibrary.findByName(voiceName)
        applyVoiceLibraryEntry(context, entry)
        viewModelScope.launch {
            SanamDataStorePrefs.savePersonalityMode(
                context,
                LiveMorphState.modes[safeIdx].first
            )
            SanamDataStorePrefs.saveActiveVoice(context, entry.name)
        }
    }

    fun setListeningState(listening: Boolean) {
        _isListening.value = listening
        if (listening) {
            _lastStatusBanner.value = "🎙️ Sanam is listening (${_selectedLanguage.value.label})..."
        }
    }

    fun toggleTouchGuard(locked: Boolean) {
        _touchGuardLocked.value = locked
        _lastStatusBanner.value = if (locked) {
            "🛡️ Touch Guard Locked: Accidental pocket touches blocked"
        } else {
            "🔓 Touch Guard Unlocked"
        }
    }

    fun toggleMyraSecurity() {
        _myraSecurityArmed.value = !_myraSecurityArmed.value
        _lastStatusBanner.value = if (_myraSecurityArmed.value) {
            "🛡️ DR WORLD Security Armed (Proximity + Motion Anti-Theft Active)"
        } else {
            "DR WORLD Security Disarmed"
        }
    }

    fun toggleGamingBoost() {
        if (!_automationPermissions.value.gamingScreenCheckEnabled) {
            val disabledMsg = "🎮 Gaming Assistant Screen Check is turned OFF in Automation Permissions. Game screen reading & coaching is paused."
            _lastStatusBanner.value = disabledMsg
            speakText(disabledMsg)
            return
        }
        _gamingBoostActive.value = !_gamingBoostActive.value
        val msg = if (_gamingBoostActive.value) {
            "🎮 Gaming Turbo HUD Active! Background tasks optimized. Go win that match Jaan!"
        } else {
            "Gaming Assistant set to standby."
        }
        _lastStatusBanner.value = msg
        speakText(msg)
    }

    fun speakText(text: String) {
        val cleanText = text.replace(Regex("[⚡💖🌸📸🎯🛡️🔓🎙️•🟢⚪]"), "")
        viewModelScope.launch {
            _isSpeaking.value = true
            val activeVoice = VoiceLibrary.findByName(GeminiClient.activeVoiceProfileName)
            VoiceLibrary.speakAndCacheWithFallback(
                context = getApplication(),
                tts = tts,
                text = cleanText,
                voiceEntry = activeVoice
            )
            val detectedLocale = voiceController.detectLocaleFromText(cleanText)
            voiceController.updatePitchAndSpeed(_voicePitch.value, _voiceSpeed.value)
            voiceController.speak(cleanText, detectedLocale)
            if (isTtsReady) {
                tts?.setPitch(_voicePitch.value)
                tts?.setSpeechRate(_voiceSpeed.value)
                tts?.language = detectedLocale
                tts?.speak(cleanText.take(360), TextToSpeech.QUEUE_FLUSH, null, "sanam_utt_${System.currentTimeMillis()}")
            }
            delay((cleanText.length * 55L).coerceIn(1800L, 6500L))
            _isSpeaking.value = false
        }
    }

    /**
     * Load an image picked from the Android Photo Picker or Camera into Visual Lens & Social Agent
     */
    fun onImagePickedFromUri(context: Context, uri: Uri) {
        viewModelScope.launch {
            try {
                val inputStream = context.contentResolver.openInputStream(uri)
                val bitmap = BitmapFactory.decodeStream(inputStream)
                inputStream?.close()
                if (bitmap != null) {
                    val dir = File(context.cacheDir, "shared_images").apply { mkdirs() }
                    val outFile = File(dir, "sanam_gallery_${System.currentTimeMillis()}.png")
                    FileOutputStream(outFile).use { out ->
                        bitmap.compress(Bitmap.CompressFormat.PNG, 92, out)
                    }
                    _selectedImageBitmap.value = bitmap
                    _selectedImageFile.value = outFile
                    _latestVisualTelemetry.value = ScreenshotHelper.computeVisualTelemetry(bitmap, "Gallery Photo Picker")
                    _lastStatusBanner.value = "📸 Photo loaded! Ready for Instagram, WhatsApp Status, or Visual Lens."
                }
            } catch (e: Exception) {
                _lastStatusBanner.value = "Could not load photo: ${e.localizedMessage}"
            }
        }
    }

    fun onCameraBitmapCaptured(context: Context, bitmap: Bitmap) {
        viewModelScope.launch {
            val dir = File(context.cacheDir, "shared_images").apply { mkdirs() }
            val outFile = File(dir, "sanam_camera_${System.currentTimeMillis()}.png")
            FileOutputStream(outFile).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 92, out)
            }
            _selectedImageBitmap.value = bitmap
            _selectedImageFile.value = outFile
            val telemetry = ScreenshotHelper.computeVisualTelemetry(bitmap, "Camera Visual Lens")
            _latestVisualTelemetry.value = telemetry
            _lastStatusBanner.value = "📷 Camera frame captured (${telemetry.resolution})! Analyzing with Visual Lens..."
            performVisualLensContentAnalysis(
                bitmap = bitmap,
                telemetry = telemetry,
                prompt = "Analyze this camera photo in ${_selectedLanguage.value.label} and suggest a social caption."
            )
        }
    }

    /**
     * Ensures there is always a valid image File ready for Social Media Agent (either user-selected or stylized card)
     */
    private fun ensureSocialImageFile(context: Context, caption: String): File {
        val currentFile = _selectedImageFile.value
        if (currentFile != null && currentFile.exists()) {
            return currentFile
        }
        val aura = _selectedAura.value
        val generated = SocialAgent.generateStylizedSocialCardFile(
            context = context,
            title = "Sanam AI • ${_selectedLanguage.value.label}",
            caption = caption,
            language = _selectedLanguage.value.nativeScript,
            primaryColorInt = aura.primary.toArgb(),
            secondaryColorInt = aura.secondary.toArgb()
        )
        _selectedImageFile.value = generated
        val bmp = BitmapFactory.decodeFile(generated.absolutePath)
        _selectedImageBitmap.value = bmp
        if (bmp != null) {
            _latestVisualTelemetry.value = ScreenshotHelper.computeVisualTelemetry(bmp, "Generated Status Card")
        }
        return generated
    }

    fun generateSocialPreviewCard(context: Context, caption: String) {
        if (!_automationPermissions.value.imageGenerationEnabled) {
            val msg = "⚠️ AI Image & Status Card Generation is turned OFF in Automation Permissions. Turn it ON in DR WORLD+ settings to generate cards."
            _lastStatusBanner.value = msg
            speakText(msg)
            return
        }
        viewModelScope.launch {
            val aura = _selectedAura.value
            val file = SocialAgent.generateStylizedSocialCardFile(
                context = context,
                title = "DR WORLD",
                caption = caption,
                language = _selectedLanguage.value.nativeScript,
                primaryColorInt = aura.primary.toArgb(),
                secondaryColorInt = aura.secondary.toArgb()
            )
            _selectedImageFile.value = file
            val bmp = BitmapFactory.decodeFile(file.absolutePath)
            _selectedImageBitmap.value = bmp
            if (bmp != null) {
                _latestVisualTelemetry.value = ScreenshotHelper.computeVisualTelemetry(bmp, "Stylized Status Card")
            }
            _lastStatusBanner.value = "✨ Generated stylized DR WORLD Status Card! Tap Insta/WhatsApp to post."
        }
    }

    /**
     * Social Media Agent Direct Actions + SanamAccessibilityService Auto-Action Integration
     */
    fun postToInstagramAction(context: Context, caption: String) {
        viewModelScope.launch {
            SanamAccessibilityService.queueSocialAutoClick("Share")
            val file = ensureSocialImageFile(context, caption)
            val result = SocialAgent.postToInstagram(context, file, caption)
            _lastStatusBanner.value = "📸 Instagram Agent (Accessibility Ready): $result"
            logAutonomousAction("Post to Instagram", result)
        }
    }

    fun postToFacebookAction(context: Context, caption: String) {
        viewModelScope.launch {
            SanamAccessibilityService.queueSocialAutoClick("Post")
            val file = _selectedImageFile.value ?: ensureSocialImageFile(context, caption)
            val result = SocialAgent.postToFacebook(context, caption, file)
            _lastStatusBanner.value = "🌐 Facebook Agent (Accessibility Ready): $result"
            logAutonomousAction("Post to Facebook", result)
        }
    }

    fun shareOnWhatsAppStatusAction(context: Context, caption: String) {
        viewModelScope.launch {
            SanamAccessibilityService.queueSocialAutoClick("Send")
            val file = ensureSocialImageFile(context, caption)
            val result = SocialAgent.shareToWhatsApp(context, file, caption)
            _lastStatusBanner.value = "💚 WhatsApp Status Agent (Accessibility Ready): $result"
            logAutonomousAction("Share on WhatsApp Status", result)
        }
    }

    fun takeScreenshotAction(activity: Activity, analyzeWithAi: Boolean = true) {
        viewModelScope.launch {
            SanamAccessibilityService.performAccessibilityScreenshot()
            if (isMediaProjectionActive.value) {
                ScreenshotHelper.requestFrameFromActiveProjection(activity)
            } else {
                ScreenshotHelper.takeScreenshot(activity = activity, analyzeImmediately = analyzeWithAi)
            }
        }
    }

    fun openMapsAction(context: Context, place: String) {
        val status = SocialAgent.openMaps(context, place)
        _lastStatusBanner.value = "🗺️ Maps Agent: $status"
        logAutonomousAction("Open Maps ($place)", status)
    }

    fun toggleFlashlightAction(context: Context) {
        val next = !_flashlightOn.value
        val result = SocialAgent.toggleFlashlight(context, next)
        _flashlightOn.value = result
        _telemetry.value = SocialAgent.getSystemTelemetry(context, result)
        val msg = if (result) "🔦 Flashlight turned ON" else "🔦 Flashlight turned OFF"
        _lastStatusBanner.value = msg
        speakText(msg)
    }

    fun adjustVolumeAction(context: Context, increase: Boolean) {
        val newPct = SocialAgent.adjustVolume(context, increase)
        _telemetry.value = SocialAgent.getSystemTelemetry(context, _flashlightOn.value)
        _lastStatusBanner.value = "🔊 Volume adjusted to $newPct%"
    }

    fun addTriggerOrMission(context: Context, time: String, task: String, isMission: Boolean) {
        if (task.isBlank()) return
        viewModelScope.launch {
            val item = TriggerMission(
                time = time.ifBlank { "08:00 AM" },
                task = task.trim(),
                isMission = isMission,
                isEnabled = true,
                category = if (isMission) "Mission Mode" else "Daily Trigger"
            )
            repository.addTriggerMission(item)
            MissionManager.addTrigger(context, item.time, item.task, item.isMission)
            val badge = if (isMission) "Mission Mode Added" else "Trigger Scheduled"
            _lastStatusBanner.value = "⏰ $badge: ${item.time} — ${item.task}"
            speakText("$badge for ${item.time}: ${item.task}")
        }
    }

    fun triggerNowTest(context: Context, item: TriggerMission) {
        MissionManager.fireTriggerNow(context, item.time, item.task, item.isMission)
        speakText(item.task)
    }

    fun toggleTriggerItem(item: TriggerMission) {
        viewModelScope.launch {
            repository.toggleTriggerMission(item.id, !item.isEnabled)
        }
    }

    fun toggleMissionCompleted(item: TriggerMission) {
        viewModelScope.launch {
            repository.completeMission(item.id, !item.isCompleted)
        }
    }

    fun deleteTriggerItem(item: TriggerMission) {
        viewModelScope.launch {
            repository.deleteTriggerMission(item.id)
        }
    }

    fun addMemoryFact(keyTitle: String, factValue: String, category: String = "Personal") {
        if (keyTitle.isBlank() || factValue.isBlank()) return
        viewModelScope.launch {
            repository.addMemory(
                MemoryFactEntity(
                    keyTitle = keyTitle.trim(),
                    factValue = factValue.trim(),
                    category = category
                )
            )
            _lastStatusBanner.value = "🧠 Memory saved: $keyTitle"
        }
    }

    fun deleteMemoryFact(id: Int) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    fun clearChatHistory() {
        viewModelScope.launch {
            repository.clearChat()
            _lastStatusBanner.value = "Conversation history cleared."
        }
    }

    private fun logAutonomousAction(badge: String, details: String) {
        viewModelScope.launch {
            repository.addMessage(
                ChatMessageEntity(
                    sender = "SANAM",
                    text = "⚡ $details",
                    language = _selectedLanguage.value.code,
                    mode = _selectedMode.value.title,
                    actionBadge = badge
                )
            )
            speakText(details)
        }
    }

    /**
     * Autonomous Voice & Text Command Processor + Gemini AI Companion Reasoning
     */
    fun sendUserCommandOrMessage(
        context: Context,
        input: String,
        hasCallPermission: Boolean,
        hasSmsPermission: Boolean,
        attachCurrentImage: Boolean = false
    ) {
        val trimmed = input.trim()
        if (trimmed.isEmpty()) return

        viewModelScope.launch {
            val lang = _selectedLanguage.value
            val mode = _selectedMode.value
            val sessionId = _activeSessionId.value

            repository.addMessage(
                ChatMessageEntity(
                    sender = "USER",
                    text = trimmed,
                    language = lang.code,
                    mode = mode.title,
                    actionBadge = if (attachCurrentImage && _selectedImageBitmap.value != null) "📸 Visual Lens" else null,
                    sessionId = sessionId
                )
            )

            // Automatically learn memory facts if user says "remember" or "mera naam"
            val lower = trimmed.lowercase()
            if (lower.contains("remember") || lower.contains("yaad rakhna") || lower.contains("mera naam")) {
                repository.addMemory(
                    MemoryFactEntity(
                        keyTitle = "Voice Note Memory",
                        factValue = trimmed,
                        category = "Learned"
                    )
                )
            }

            // MYRA 2.2.10 Automated Payments Confirmation Safety Check
            if ((lower.contains("pay ") || lower.contains("place order") || lower.contains("send money") || lower.contains("payment karo")) &&
                !_automationPermissions.value.automatedPaymentsConfirmationEnabled
            ) {
                val safeMsg = "🛡️ Automated Payments Confirmation is turned OFF for your safety. Sanam AI blocked automatic clicking on Pay / Place Order / Send Money."
                repository.addMessage(
                    ChatMessageEntity(
                        sender = "SANAM",
                        text = safeMsg,
                        language = lang.code,
                        mode = mode.title,
                        actionBadge = "🛡️ Payment Guard"
                    )
                )
                _lastStatusBanner.value = safeMsg
                speakText(safeMsg)
                return@launch
            }

            // MYRA 2.2.10 Local Phone Timezone Check (Never UK/UTC time)
            if (lower.contains("time kya") || lower.contains("what time") || lower.contains("kitne baje") || lower.contains("waqt")) {
                val localTimeStr = LocalTimezoneHelper.getFormattedLocalTimeAndZone()
                val timeMsg = "⏰ Aapke phone ke local timezone ke hisab se abhi waqt hai: $localTimeStr"
                repository.addMessage(
                    ChatMessageEntity(
                        sender = "SANAM",
                        text = timeMsg,
                        language = lang.code,
                        mode = mode.title,
                        actionBadge = "⏰ Local Timezone"
                    )
                )
                _lastStatusBanner.value = timeMsg
                speakText(timeMsg)
                return@launch
            }

            // Detect and execute unified JARVIS v1.0 + MYRA v2.0 commands via DeviceActionManager
            val commandResult = DeviceActionManager.parseAndExecuteUnifiedCommand(
                context = context,
                rawInput = trimmed,
                hasCallPermission = hasCallPermission,
                hasSmsPermission = hasSmsPermission,
                currentFlashlightState = _flashlightOn.value,
                imageFileProvider = { caption -> ensureSocialImageFile(context, caption) }
            )

            if (commandResult.newFlashlightState != null) {
                _flashlightOn.value = commandResult.newFlashlightState
                _telemetry.value = SocialAgent.getSystemTelemetry(context, commandResult.newFlashlightState)
            }
            if (commandResult.scheduledTriggerMission != null) {
                repository.addTriggerMission(commandResult.scheduledTriggerMission)
            }

            val executedBadge: String? = commandResult.badge
            val executedNote: String? = commandResult.summary

            _isThinking.value = true
            val memoriesText = memories.value.take(6).joinToString("; ") { "${it.keyTitle}: ${it.factValue}" }
            val attachedBitmap = if (attachCurrentImage) _selectedImageBitmap.value else null

            val reply = GeminiClient.generateSanamReply(
                prompt = trimmed,
                language = lang.code,
                mode = mode.title,
                memoriesSummary = memoriesText,
                actionExecutedNote = executedNote,
                imageBitmap = attachedBitmap
            )
            _isThinking.value = false

            if (attachCurrentImage && attachedBitmap != null) {
                _latestVisualLensAnalysis.value = reply
            }

            repository.addMessage(
                ChatMessageEntity(
                    sender = "SANAM",
                    text = reply,
                    language = lang.code,
                    mode = mode.title,
                    actionBadge = executedBadge ?: mode.badge,
                    sessionId = sessionId
                )
            )
            repository.upsertConversationSession(
                ConversationSessionEntity(
                    sessionId = sessionId,
                    title = trimmed.take(36).ifBlank { "Dayaram Boss & Sanam Chat" },
                    lastMessagePreview = reply.take(120),
                    language = lang.code,
                    mode = mode.title,
                    messageCount = messages.value.size + 1,
                    updatedAt = System.currentTimeMillis()
                )
            )
            _lastStatusBanner.value = executedNote ?: "Sanam replied in ${lang.label}"
            speakText(reply)
        }
    }

    override fun onCleared() {
        securityManager.stopMonitoring()
        voiceController.shutdown()
        tts?.stop()
        tts?.shutdown()
        super.onCleared()
    }
}
