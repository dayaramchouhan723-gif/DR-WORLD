package com.example

/**
 * Top-level unified package bridge so that all JARVIS v1.0 controllers
 * (DeviceActionManager, DeviceController, CallHelper, SmsHelper, AppLauncher, SpeechManager)
 * can be imported either from `com.example.*` or `com.example.sanam.controller.*`
 * alongside MYRA v2.0 (`SocialAgent`, `ScreenTools`, `TriggersAndMission`).
 */
typealias DeviceActionManager = com.example.sanam.controller.DeviceActionManager
typealias DeviceController = com.example.sanam.controller.DeviceController
typealias CallHelper = com.example.sanam.controller.CallHelper
typealias SmsHelper = com.example.sanam.controller.SmsHelper
typealias AppLauncher = com.example.sanam.controller.AppLauncher
typealias AutonomousCommandResult = com.example.sanam.controller.AutonomousCommandResult
typealias SpeechManager = com.example.sanam.voice.SpeechManager
