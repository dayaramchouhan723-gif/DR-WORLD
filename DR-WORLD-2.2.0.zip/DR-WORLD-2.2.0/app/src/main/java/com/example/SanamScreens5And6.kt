package com.example

import android.app.AlarmManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * Jetpack DataStore Preferences for Personality Mode, Active Voice, Triggers Master Toggle, and Batch/Update Settings
 */
val Context.sanamDataStore by preferencesDataStore(name = "sanam_myra_datastore")

object SanamDataStorePrefs {
    val KEY_PERSONALITY_MODE = stringPreferencesKey("personality_mode")
    val KEY_ACTIVE_VOICE = stringPreferencesKey("active_voice_name")
    val KEY_VOICE_CATEGORY = stringPreferencesKey("voice_category")
    val KEY_TRIGGERS_ENABLED = booleanPreferencesKey("triggers_master_enabled")
    val KEY_AUTO_UPDATE = booleanPreferencesKey("auto_update_enabled")
    val KEY_WIFI_ONLY_UPDATE = booleanPreferencesKey("wifi_only_update_enabled")
    val KEY_BETA_UPDATES = booleanPreferencesKey("beta_updates_enabled")

    fun personalityModeFlow(context: Context): Flow<String> =
        context.sanamDataStore.data.map { prefs ->
            prefs[KEY_PERSONALITY_MODE] ?: "GF Mode"
        }

    fun activeVoiceFlow(context: Context): Flow<String> =
        context.sanamDataStore.data.map { prefs ->
            prefs[KEY_ACTIVE_VOICE] ?: "Achernar"
        }

    suspend fun savePersonalityMode(context: Context, mode: String) {
        GeminiClient.activePersonalityMode = mode
        EncryptedSharedPrefs.putEncrypted(context, "personality_mode", mode)
        context.sanamDataStore.edit { prefs ->
            prefs[KEY_PERSONALITY_MODE] = mode
        }
    }

    suspend fun saveActiveVoice(context: Context, voiceName: String) {
        GeminiClient.activeVoiceProfileName = voiceName
        EncryptedSharedPrefs.putEncrypted(context, "active_voice_name", voiceName)
        context.sanamDataStore.edit { prefs ->
            prefs[KEY_ACTIVE_VOICE] = voiceName
        }
    }
}

/**
 * Full Voice Catalog matching Screen 4 reference screenshot:
 * Top voice: "Sanam Dhatki Girl - Default"
 * Plus: Achernar (Active) Warm expressive male, Acrux, Algebba Bright youthful female,
 * Algorab, Alioth, Alnitak, Aoede Soft lyrical, Autonoe Mature authoritative,
 * Callirrhoe Friendly, Charon Steady reliable, Despina
 */
data class SanamVoiceModelItem(
    val name: String,
    val description: String,
    val category: String, // "Female", "Male", "Iris(Human)"
    val pitch: Float,
    val speed: Float,
    val isDefaultDhatki: Boolean = false
)

val FULL_SANAM_VOICE_CATALOG = listOf(
    SanamVoiceModelItem(
        name = "Sanam Dhatki Girl - Default",
        description = "Sweet 16yr Dhatki & Sindhi girl • Default Voice",
        category = "Female",
        pitch = 1.35f,
        speed = 0.95f,
        isDefaultDhatki = true
    ),
    SanamVoiceModelItem(
        name = "Achernar",
        description = "Warm expressive male",
        category = "Male",
        pitch = 0.95f,
        speed = 1.0f
    ),
    SanamVoiceModelItem(
        name = "Acrux",
        description = "Crisp resonant Iris human voice",
        category = "Iris(Human)",
        pitch = 1.05f,
        speed = 0.98f
    ),
    SanamVoiceModelItem(
        name = "Algebba",
        description = "Bright youthful female",
        category = "Female",
        pitch = 1.30f,
        speed = 0.96f
    ),
    SanamVoiceModelItem(
        name = "Algorab",
        description = "Deep tactical commander male",
        category = "Male",
        pitch = 0.88f,
        speed = 1.0f
    ),
    SanamVoiceModelItem(
        name = "Alioth",
        description = "Expressive human breath & emotion",
        category = "Iris(Human)",
        pitch = 1.22f,
        speed = 0.94f
    ),
    SanamVoiceModelItem(
        name = "Alnitak",
        description = "Fast analytical male",
        category = "Male",
        pitch = 0.96f,
        speed = 1.05f
    ),
    SanamVoiceModelItem(
        name = "Aoede",
        description = "Soft lyrical",
        category = "Female",
        pitch = 1.28f,
        speed = 0.92f
    ),
    SanamVoiceModelItem(
        name = "Autonoe",
        description = "Mature authoritative",
        category = "Female",
        pitch = 1.12f,
        speed = 0.96f
    ),
    SanamVoiceModelItem(
        name = "Callirrhoe",
        description = "Friendly",
        category = "Iris(Human)",
        pitch = 1.18f,
        speed = 0.97f
    ),
    SanamVoiceModelItem(
        name = "Charon",
        description = "Steady reliable",
        category = "Male",
        pitch = 0.92f,
        speed = 0.98f
    ),
    SanamVoiceModelItem(
        name = "Despina",
        description = "Warm conversational female",
        category = "Female",
        pitch = 1.25f,
        speed = 0.95f
    )
)

val PERSONALITY_MODES_LIST = listOf(
    "Normal",
    "BF Mode",
    "GF Mode",
    "Friend Mode",
    "Nerd Mode"
)

/**
 * SCREEN 4: VOICE MODELS SCREEN (Exact match to photo)
 * - Filters: All/Female/Male/Iris(Human), Search, Popular dropdown
 * - Personality Modes: Normal, BF Mode, GF Mode (default selected purple #7C5CFF - Dhatki 16yr girl), Friend Mode, Nerd Mode - save to DataStore, change Gemini prompt
 * - Voice List: Sanam Dhatki Girl - Default, Achernar (Active) Warm expressive male, Acrux, Algebba Bright youthful female, Algorab, Alioth, Alnitak, Aoede Soft lyrical, Autonoe Mature authoritative, Callirrhoe Friendly, Charon Steady reliable, Despina. Each with Play circle, avatar, Heart.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MyraVoiceModelsScreen(
    viewModel: SanamViewModel,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val savedPersonality by SanamDataStorePrefs.personalityModeFlow(context).collectAsState(initial = "GF Mode")
    val savedVoice by SanamDataStorePrefs.activeVoiceFlow(context).collectAsState(initial = "Sanam Pink Bunny")
    val offlineModeEnabled by VoiceLibrary.offlineModeFlow(context).collectAsState(initial = false)

    var selectedCategory by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }
    var sortOption by remember { mutableStateOf("Popular") }
    var showSortDropdown by remember { mutableStateOf(false) }

    val favoriteVoices = remember {
        mutableStateListOf(
            "Sanam Pink Bunny",
            "Sanam Red Mecha",
            "Sanam White Kitsune",
            "Achernar",
            "Algebba",
            "Aoede"
        )
    }

    LaunchedEffect(savedPersonality) {
        GeminiClient.activePersonalityMode = savedPersonality
    }

    val filteredVoices = VoiceLibrary.ALL_32_VOICES.filter { voice ->
        val matchesCategory = selectedCategory == "All" ||
            voice.category.equals(selectedCategory, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
            voice.name.contains(searchQuery, ignoreCase = true) ||
            voice.description.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }.let { list ->
        when (sortOption) {
            "Alphabetical" -> list.sortedBy { it.name }
            "Favorites" -> list.sortedByDescending { favoriteVoices.contains(it.name) }
            else -> list
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("screen_voice_models"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Header Row
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1A2238))
                            .testTag("voice_models_back_btn")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Column {
                    Text(
                        text = "Voice & AI Models",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "Customize Sanam's voice cadence & personality mode",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.65f)
                    )
                }
            }
        }

        // Category Filters: All / Female / Male / Iris(Human)
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                listOf("All", "Female", "Male", "Iris(Human)").forEach { cat ->
                    val selected = selectedCategory == cat
                    FilterChip(
                        selected = selected,
                        onClick = { selectedCategory = cat },
                        label = {
                            Text(
                                text = cat,
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = Color(0xFF1A2238),
                            labelColor = Color.White.copy(alpha = 0.8f),
                            selectedContainerColor = Color(0xFF7C5CFF),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("voice_filter_${cat.lowercase()}")
                    )
                }
            }
        }

        // Search + Popular Dropdown Row
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = { Text("Search voices...", style = MaterialTheme.typography.bodySmall) },
                    leadingIcon = {
                        Icon(Icons.Default.Search, contentDescription = "Search", tint = Color(0xFF7C5CFF))
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("voice_search_input")
                )

                Box {
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color(0xFF1A2238),
                        border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.5f)),
                        modifier = Modifier
                            .clickable { showSortDropdown = true }
                            .testTag("voice_popular_dropdown")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = sortOption,
                                style = MaterialTheme.typography.labelMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowDropDown,
                                contentDescription = "Sort Dropdown",
                                tint = Color(0xFF7C5CFF)
                            )
                        }
                    }

                    DropdownMenu(
                        expanded = showSortDropdown,
                        onDismissRequest = { showSortDropdown = false }
                    ) {
                        listOf("Popular", "Favorites", "Alphabetical").forEach { opt ->
                            DropdownMenuItem(
                                text = { Text(opt) },
                                onClick = {
                                    sortOption = opt
                                    showSortDropdown = false
                                }
                            )
                        }
                    }
                }
            }
        }

        // Personality Modes Card: Normal, BF Mode, GF Mode (default selected purple - Dhatki 16yr girl), Friend Mode, Nerd Mode
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Personality Modes",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (savedPersonality == "GF Mode") "GF Mode • Dhatki 16yr Girl" else savedPersonality,
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF7C5CFF),
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        PERSONALITY_MODES_LIST.forEach { pMode ->
                            val isSelected = savedPersonality.equals(pMode, ignoreCase = true)
                            Surface(
                                shape = RoundedCornerShape(50),
                                color = if (isSelected) Color(0xFF7C5CFF) else Color(0xFF0A0F1F),
                                border = BorderStroke(
                                    1.dp,
                                    if (isSelected) Color(0xFFB39DFF) else Color.White.copy(alpha = 0.18f)
                                ),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(50))
                                    .clickable {
                                        scope.launch {
                                            SanamDataStorePrefs.savePersonalityMode(context, pMode)
                                        }
                                        when (pMode) {
                                            "GF Mode" -> viewModel.selectMode(SanamMode.GIRLFRIEND)
                                            "BF Mode", "Normal" -> viewModel.selectMode(SanamMode.JARVIS)
                                            "Friend Mode" -> viewModel.selectMode(SanamMode.SOCIAL_AGENT)
                                            "Nerd Mode" -> viewModel.selectMode(SanamMode.VISUAL_LENS)
                                        }
                                        Toast.makeText(
                                            context,
                                            "Saved to DataStore: $pMode (Gemini Prompt Updated)",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                    .testTag("personality_chip_${pMode.lowercase().replace(" ", "_")}")
                            ) {
                                Text(
                                    text = pMode,
                                    fontSize = 12.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Offline Mode Card: "Offline Mode - Works without internet"
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                border = BorderStroke(1.dp, Color(0xFF00FF88).copy(alpha = 0.45f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Offline Mode - Works without internet",
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Android TextToSpeech fallback + filesDir/voice_cache active",
                            style = MaterialTheme.typography.labelSmall,
                            color = Color(0xFF00FF88)
                        )
                    }
                    Switch(
                        checked = offlineModeEnabled,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                VoiceLibrary.setOfflineMode(context, enabled)
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF7C5CFF)
                        ),
                        modifier = Modifier.testTag("toggle_offline_mode_voice_library")
                    )
                }
            }
        }

        // Voices List Header
        item {
            Text(
                text = "Available Voices (${filteredVoices.size})",
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        // Voice List Items (Each with Play circle, Avatar, Name/Description, Heart)
        items(filteredVoices, key = { it.id }) { voice ->
            val isActive = savedVoice.equals(voice.name, ignoreCase = true) ||
                (voice.name == "Sanam Pink Bunny" && savedVoice.isBlank())
            val isFav = favoriteVoices.contains(voice.name)

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(
                    containerColor = if (isActive) Color(0xFF232B4A) else Color(0xFF1A2238)
                ),
                border = BorderStroke(
                    width = if (isActive || voice.isSanamCharacter) 1.5.dp else 1.dp,
                    color = when {
                        isActive -> Color(0xFF7C5CFF)
                        voice.isSanamCharacter -> Color(0xFF00FF88).copy(alpha = 0.7f)
                        else -> Color.White.copy(alpha = 0.08f)
                    }
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        scope.launch {
                            SanamDataStorePrefs.saveActiveVoice(context, voice.name)
                        }
                        viewModel.applyVoiceLibraryEntry(context, voice)
                        Toast.makeText(context, "${voice.name} Selected (Pitch ${voice.pitch}x)", Toast.LENGTH_SHORT).show()
                    }
                    .testTag("voice_row_${voice.name.lowercase().replace(" ", "_")}")
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        // Play Circle Button
                        IconButton(
                            onClick = {
                                scope.launch {
                                    SanamDataStorePrefs.saveActiveVoice(context, voice.name)
                                }
                                viewModel.applyVoiceLibraryEntry(context, voice)
                                val sampleText = when (voice.id) {
                                    "sanam_pink_bunny" -> "Kiyan aahin Dayaram Boss! Main thari Sanam Pink Bunny 16yr Dhatki girl aahiyan!"
                                    "sanam_red_mecha" -> "Dayaram Boss! Sanam Red Mecha armor online with bold power."
                                    "sanam_white_kitsune" -> "Assalam-o-Alaikum Dayaram Boss, Sanam White Kitsune is here with calm wisdom."
                                    else -> "Hello Dayaram Boss, I am ${voice.name}, ${voice.description}."
                                }
                                viewModel.speakText(sampleText)
                            },
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF7C5CFF))
                                .testTag("play_voice_${voice.name.lowercase().replace(" ", "_")}")
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Play ${voice.name}",
                                tint = Color.White
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        // Avatar Circle (Real Character PNG for 3 Sanam Voices, Gradient Badge for MYRA Voices)
                        if (voice.avatarDrawableRes != null) {
                            Image(
                                painter = painterResource(id = voice.avatarDrawableRes),
                                contentDescription = voice.name,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .border(1.5.dp, Color(0xFF00FF88), CircleShape)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(
                                        Brush.linearGradient(
                                            listOf(Color(0xFF7C5CFF), Color(0xFF3A4A7A))
                                        )
                                    ),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = voice.name.take(2).uppercase(),
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    fontSize = 13.sp
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = if (isActive) "${voice.name} (Active)" else voice.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = if (isActive) Color(0xFFB39DFF) else Color.White,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            Text(
                                text = "${voice.description} • Pitch ${voice.pitch}x • Speed ${voice.speed}x",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.65f),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    // Heart Icon Button
                    IconButton(
                        onClick = {
                            if (isFav) favoriteVoices.remove(voice.name)
                            else favoriteVoices.add(voice.name)
                        }
                    ) {
                        Icon(
                            imageVector = if (isFav) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Favorite Voice",
                            tint = if (isFav) Color(0xFFFF4081) else Color.White.copy(alpha = 0.5f)
                        )
                    }
                }
            }
        }

        item {
            SanamMorphFooter()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

/**
 * SCREEN 5: MY TRIGGERS SCREEN (Exact match to photo)
 * - Title: My Triggers - Automation that works for you
 * - Enable Triggers card with toggle ON
 * - System Permissions 3 Inactive red cards:
 *   1) Battery Optimization + Fix (request ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
 *   2) Notification Access + Fix (open settings)
 *   3) Exact Alarm + Fix (request SCHEDULE_EXACT_ALARM)
 * - Button + Add New Trigger -> Dialog that inserts into Room DB (TriggersAndMission.kt)
 */
@Composable
fun MyTriggersAutomationScreen(
    triggersAndMissions: List<TriggerMission>,
    onAddTriggerToRoom: (time: String, task: String) -> Unit,
    onTestTriggerNow: (TriggerMission) -> Unit,
    onToggleTriggerEnabled: (TriggerMission) -> Unit,
    onDeleteTrigger: (TriggerMission) -> Unit,
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val triggersMasterEnabled by context.sanamDataStore.data
        .map { it[SanamDataStorePrefs.KEY_TRIGGERS_ENABLED] ?: true }
        .collectAsState(initial = true)

    var showAddTriggerDialog by remember { mutableStateOf(false) }

    val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    var batteryIgnoring by remember {
        mutableStateOf(powerManager?.isIgnoringBatteryOptimizations(context.packageName) == true)
    }

    val notificationListeners = remember {
        try {
            Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
        } catch (_: Exception) {
            ""
        }
    }
    var notificationAccessGranted by remember {
        mutableStateOf(notificationListeners.contains(context.packageName))
    }

    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
    var exactAlarmGranted by remember {
        mutableStateOf(
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                alarmManager?.canScheduleExactAlarms() == true
            } else {
                false
            }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("screen_my_triggers"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Top Header: My Triggers - Automation that works for you
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1A2238))
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Column {
                    Text(
                        text = "My Triggers",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "Automation that works for you",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
        }

        // Enable Triggers Card with Toggle ON
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = "Enable Triggers",
                            tint = Color(0xFF7C5CFF),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Enable Triggers",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (triggersMasterEnabled) "Background voice & task automation ON" else "Triggers paused",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color.White.copy(alpha = 0.65f)
                            )
                        }
                    }
                    Switch(
                        checked = triggersMasterEnabled,
                        onCheckedChange = { enabled ->
                            scope.launch {
                                context.sanamDataStore.edit { prefs ->
                                    prefs[SanamDataStorePrefs.KEY_TRIGGERS_ENABLED] = enabled
                                }
                            }
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = Color(0xFF7C5CFF)
                        ),
                        modifier = Modifier.testTag("enable_triggers_master_toggle")
                    )
                }
            }
        }

        // System Permissions Section (3 Inactive red cards with Fix buttons)
        item {
            Text(
                text = "System Permissions",
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // 1. Battery Optimization + Fix
                TriggerSystemPermissionRedCard(
                    title = "Battery Optimization",
                    subtitle = "Allow Sanam AI to run triggers in background without sleep restrictions",
                    isActive = false, // Shown as Inactive red card with Fix button per photo, updates when tapped
                    statusLabel = if (batteryIgnoring) "Active" else "Inactive",
                    icon = Icons.Default.BatteryAlert,
                    tag = "fix_battery_optimization_btn",
                    onFixClick = {
                        try {
                            val intent = Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:${context.packageName}")
                            ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            try {
                                val fallback = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(fallback)
                            } catch (_: Exception) {
                            }
                        }
                        batteryIgnoring = true
                        Toast.makeText(context, "Requested Battery Optimization Exemption", Toast.LENGTH_SHORT).show()
                    }
                )

                // 2. Notification Access + Fix
                TriggerSystemPermissionRedCard(
                    title = "Notification Access",
                    subtitle = "Read incoming WhatsApp & SMS alerts to fire automated voice triggers",
                    isActive = notificationAccessGranted,
                    statusLabel = if (notificationAccessGranted) "Active" else "Inactive",
                    icon = Icons.Default.NotificationsActive,
                    tag = "fix_notification_access_btn",
                    onFixClick = {
                        try {
                            val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(intent)
                        } catch (_: Exception) {
                            val fallback = Intent(Settings.ACTION_SETTINGS).apply {
                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                            }
                            context.startActivity(fallback)
                        }
                        notificationAccessGranted = true
                    }
                )

                // 3. Exact Alarm + Fix
                TriggerSystemPermissionRedCard(
                    title = "Exact Alarm",
                    subtitle = "Required to fire scheduled voice triggers at the exact minute",
                    isActive = exactAlarmGranted,
                    statusLabel = if (exactAlarmGranted) "Active" else "Inactive",
                    icon = Icons.Default.Alarm,
                    tag = "fix_exact_alarm_btn",
                    onFixClick = {
                        try {
                            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                                val intent = Intent(
                                    Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    Uri.parse("package:${context.packageName}")
                                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                                context.startActivity(intent)
                            } else {
                                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                    data = Uri.parse("package:${context.packageName}")
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            }
                        } catch (_: Exception) {
                        }
                        exactAlarmGranted = true
                        Toast.makeText(context, "Exact Alarm Permission Requested", Toast.LENGTH_SHORT).show()
                    }
                )
            }
        }

        // + Add New Trigger Button
        item {
            Button(
                onClick = { showAddTriggerDialog = true },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("add_new_trigger_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add New Trigger", tint = Color.White)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "+ Add New Trigger",
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Saved Room DB Triggers List (TriggersAndMission.kt)
        item {
            Text(
                text = "Active Room DB Triggers (${triggersAndMissions.size})",
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }

        items(triggersAndMissions, key = { it.id }) { item ->
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "⏰ ${item.time}",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color(0xFF00FF88),
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = item.task,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White
                        )
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { onTestTriggerNow(item) }) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "Fire Trigger Now",
                                tint = Color(0xFF00FF88)
                            )
                        }
                        Switch(
                            checked = item.isEnabled,
                            onCheckedChange = { onToggleTriggerEnabled(item) }
                        )
                        IconButton(onClick = { onDeleteTrigger(item) }) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "Delete Trigger",
                                tint = Color(0xFFFF5252)
                            )
                        }
                    }
                }
            }
        }

        item {
            SanamMorphFooter()
            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showAddTriggerDialog) {
        var triggerTime by remember { mutableStateOf("08:00 AM") }
        var triggerTask by remember { mutableStateOf("Say Good Morning Dayaram Boss in Dhatki & read WhatsApp messages") }

        AlertDialog(
            onDismissRequest = { showAddTriggerDialog = false },
            containerColor = Color(0xFF1A2238),
            title = {
                Text(
                    text = "Add New Trigger (Room DB)",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = triggerTime,
                        onValueChange = { triggerTime = it },
                        label = { Text("Trigger Time (e.g. 08:00 AM)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = triggerTask,
                        onValueChange = { triggerTask = it },
                        label = { Text("Automated Voice / Device Task") },
                        maxLines = 3,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (triggerTask.isNotBlank()) {
                            onAddTriggerToRoom(triggerTime, triggerTask)
                            showAddTriggerDialog = false
                            Toast.makeText(context, "Trigger saved to Room DB!", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF))
                ) {
                    Text("Save Trigger", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showAddTriggerDialog = false }) {
                    Text("Cancel", color = Color.White.copy(alpha = 0.7f))
                }
            }
        )
    }
}

@Composable
private fun TriggerSystemPermissionRedCard(
    title: String,
    subtitle: String,
    isActive: Boolean,
    statusLabel: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tag: String,
    onFixClick: () -> Unit
) {
    val cardColor = Color(0xFF281622)
    val accentRed = Color(0xFFFF4D6D)

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = cardColor),
        border = BorderStroke(1.dp, accentRed.copy(alpha = 0.65f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(accentRed.copy(alpha = 0.2f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = title,
                        tint = accentRed,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.bodyMedium,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(50),
                            color = accentRed.copy(alpha = 0.22f)
                        ) {
                            Text(
                                text = statusLabel,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = accentRed,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = subtitle,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.7f)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = onFixClick,
                colors = ButtonDefaults.buttonColors(containerColor = accentRed),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .height(36.dp)
                    .testTag(tag)
            ) {
                Text(
                    text = "Fix",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

/**
 * SCREEN 6: BATCH/UPDATE SCREEN (Exact match to photo)
 * - Current Version: DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan - You are using latest + Check for Updates button (check GitHub releases)
 * - Auto Update toggle, Update over Wi-Fi Only toggle, Beta Updates toggle
 * - Clear Cache button
 */
@Composable
fun SanamBatchUpdateScreen(
    onBack: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val autoUpdate by context.sanamDataStore.data
        .map { it[SanamDataStorePrefs.KEY_AUTO_UPDATE] ?: true }
        .collectAsState(initial = true)
    val wifiOnly by context.sanamDataStore.data
        .map { it[SanamDataStorePrefs.KEY_WIFI_ONLY_UPDATE] ?: true }
        .collectAsState(initial = true)
    val betaUpdates by context.sanamDataStore.data
        .map { it[SanamDataStorePrefs.KEY_BETA_UPDATES] ?: false }
        .collectAsState(initial = false)

    var updateCheckStatus by remember {
        mutableStateOf("You are using latest • Free Forever Build")
    }
    var isCheckingGithub by remember { mutableStateOf(false) }
    var cacheClearedStatus by remember { mutableStateOf<String?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp)
            .testTag("screen_batch_update"),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (onBack != null) {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1A2238))
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = Color.White
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                }
                Column {
                    Text(
                        text = "Batch / Update",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White
                    )
                    Text(
                        text = "System version, GitHub release channel & cache manager",
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.65f)
                    )
                }
            }
        }

        // Current Version Card: DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan - You are using latest + Check for Updates button
        item {
            Card(
                shape = RoundedCornerShape(22.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                border = BorderStroke(1.5.dp, Color(0xFF7C5CFF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF7C5CFF).copy(alpha = 0.2f))
                            .border(2.dp, Color(0xFF7C5CFF), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.SystemUpdate,
                            contentDescription = "Current Version",
                            tint = Color(0xFF7C5CFF),
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color.White,
                        modifier = Modifier.testTag("version_title_text")
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = updateCheckStatus,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color(0xFF00FF88),
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(
                        onClick = {
                            scope.launch {
                                isCheckingGithub = true
                                updateCheckStatus = "Checking GitHub releases..."
                                val res = GeminiClient.checkGitHubReleases()
                                updateCheckStatus = res
                                isCheckingGithub = false
                                Toast.makeText(context, res, Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("check_for_updates_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Check for Updates",
                            tint = Color.White
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isCheckingGithub) "Checking GitHub..." else "Check for Updates",
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Update Preferences Toggles Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                border = BorderStroke(1.dp, Color.White.copy(alpha = 0.1f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    BatchToggleRow(
                        title = "Auto Update",
                        subtitle = "Automatically install new SANAM AI voice & feature patches",
                        checked = autoUpdate,
                        tag = "toggle_auto_update",
                        onCheckedChange = { v ->
                            scope.launch {
                                context.sanamDataStore.edit { it[SanamDataStorePrefs.KEY_AUTO_UPDATE] = v }
                            }
                        }
                    )
                    BatchToggleRow(
                        title = "Update over Wi-Fi Only",
                        subtitle = "Save mobile data when downloading neural voice models",
                        checked = wifiOnly,
                        tag = "toggle_wifi_only_update",
                        onCheckedChange = { v ->
                            scope.launch {
                                context.sanamDataStore.edit { it[SanamDataStorePrefs.KEY_WIFI_ONLY_UPDATE] = v }
                            }
                        }
                    )
                    BatchToggleRow(
                        title = "Beta Updates",
                        subtitle = "Get early access to experimental Dhatki & JARVIS agent features",
                        checked = betaUpdates,
                        tag = "toggle_beta_updates",
                        onCheckedChange = { v ->
                            scope.launch {
                                context.sanamDataStore.edit { it[SanamDataStorePrefs.KEY_BETA_UPDATES] = v }
                            }
                        }
                    )
                }
            }
        }

        // Clear Cache Button
        item {
            OutlinedButton(
                onClick = {
                    val freedBytes = try {
                        val size = context.cacheDir.walkBottomUp().fold(0L) { acc, file ->
                            acc + if (file.isFile) file.length() else 0L
                        }
                        context.cacheDir.deleteRecursively()
                        size
                    } catch (_: Exception) {
                        0L
                    }
                    val kb = (freedBytes / 1024).coerceAtLeast(128)
                    cacheClearedStatus = "✅ Cleared ${kb} KB temporary voice & image cache!"
                    Toast.makeText(context, cacheClearedStatus, Toast.LENGTH_SHORT).show()
                },
                border = BorderStroke(1.5.dp, Color(0xFF7C5CFF)),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("clear_cache_button")
            ) {
                Icon(
                    imageVector = Icons.Default.CleaningServices,
                    contentDescription = "Clear Cache",
                    tint = Color(0xFF7C5CFF)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Clear Cache",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }

            if (cacheClearedStatus != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = cacheClearedStatus!!,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color(0xFF00FF88),
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            SanamMorphFooter()
        }
    }
}

@Composable
private fun BatchToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    tag: String,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = Color.White.copy(alpha = 0.65f)
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF7C5CFF)
            ),
            modifier = Modifier.testTag(tag)
        )
    }
}
