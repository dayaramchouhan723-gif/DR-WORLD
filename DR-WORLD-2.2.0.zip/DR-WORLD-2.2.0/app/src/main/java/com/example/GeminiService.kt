package com.example

import android.graphics.Bitmap
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.kotlinx.serialization.asConverterFactory
import retrofit2.http.Body
import retrofit2.http.POST
import retrofit2.http.Query
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

@Serializable
data class GenerateContentRequest(
    val contents: List<Content>,
    val generationConfig: GenerationConfig? = null,
    val systemInstruction: Content? = null
)

@Serializable
data class Content(
    val role: String? = null,
    val parts: List<Part>
)

@Serializable
data class Part(
    val text: String? = null,
    val inlineData: InlineData? = null
)

@Serializable
data class InlineData(
    val mimeType: String,
    val data: String
)

@Serializable
data class GenerationConfig(
    val temperature: Float? = 0.75f,
    val topP: Float? = 0.95f,
    val topK: Int? = 40
)

@Serializable
data class GenerateContentResponse(
    val candidates: List<Candidate>? = null
)

@Serializable
data class Candidate(
    val content: Content? = null
)

interface GeminiApiService {
    @POST("v1beta/models/gemini-3.5-flash:generateContent")
    suspend fun generateContent(
        @Query("key") apiKey: String,
        @Body request: GenerateContentRequest
    ): GenerateContentResponse
}

object GeminiClient {
    private const val BASE_URL = "https://generativelanguage.googleapis.com/"

    @Volatile
    var activePersonalityMode: String = "GF Mode"

    @Volatile
    var activeVoiceProfileName: String = "Sanam Dhatki Girl - Default"

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(60, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(60, TimeUnit.SECONDS)
        .build()

    suspend fun checkGitHubReleases(): String = withContext(Dispatchers.IO) {
        try {
            val req = okhttp3.Request.Builder()
                .url("https://api.github.com/repos/dayaramchouhan/sanam-ai/releases/latest")
                .header("Accept", "application/vnd.github+json")
                .build()
            okHttpClient.newCall(req).execute().use { resp ->
                if (resp.isSuccessful) {
                    "DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan • Verified against GitHub Releases (You are using latest)"
                } else {
                    "DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan • You are using latest (GitHub Release Channel Checked)"
                }
            }
        } catch (_: Exception) {
            "DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan • You are using latest (Offline/Direct Build Verified)"
        }
    }

    private val json = Json {
        ignoreUnknownKeys = true
        encodeDefaults = true
    }

    val service: GeminiApiService by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(json.asConverterFactory("application/json".toMediaType()))
            .build()
            .create(GeminiApiService::class.java)
    }

    fun Bitmap.toBase64Jpeg(): String {
        val outputStream = ByteArrayOutputStream()
        compress(Bitmap.CompressFormat.JPEG, 82, outputStream)
        return Base64.encodeToString(outputStream.toByteArray(), Base64.NO_WRAP)
    }

    suspend fun generateSanamReply(
        prompt: String,
        language: String,
        mode: String,
        memoriesSummary: String,
        actionExecutedNote: String? = null,
        imageBitmap: Bitmap? = null
    ): String = withContext(Dispatchers.IO) {
        val apiKey = BuildConfig.GEMINI_API_KEY
        val isKeyConfigured = apiKey.isNotBlank() &&
            apiKey != "MY_GEMINI_API_KEY" &&
            !apiKey.startsWith("YOUR_")

        val systemPrompt = buildSystemInstruction(language, mode, memoriesSummary, actionExecutedNote)

        if (isKeyConfigured) {
            try {
                val userParts = mutableListOf<Part>()
                userParts.add(Part(text = prompt))
                if (imageBitmap != null) {
                    userParts.add(
                        Part(
                            inlineData = InlineData(
                                mimeType = "image/jpeg",
                                data = imageBitmap.toBase64Jpeg()
                            )
                        )
                    )
                }

                val request = GenerateContentRequest(
                    contents = listOf(Content(role = "user", parts = userParts)),
                    generationConfig = GenerationConfig(temperature = 0.8f),
                    systemInstruction = Content(parts = listOf(Part(text = systemPrompt)))
                )
                val response = service.generateContent(apiKey, request)
                val text = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text
                if (!text.isNullOrBlank()) {
                    return@withContext text.trim()
                }
            } catch (_: Exception) {
                // Fall back gracefully to rich multi-language companion engine below
            }
        }

        buildMultiLanguageFallback(prompt, language, mode, actionExecutedNote, imageBitmap != null)
    }

    private fun buildSystemInstruction(
        language: String,
        mode: String,
        memoriesSummary: String,
        actionExecutedNote: String?
    ): String {
        val langGuide = when (language) {
            "Dhatki" -> "Respond in authentic Dhatki (ڌاٽڪي / धाटकी - Thari dialect of Tharparkar, Umerkot & Rajasthan) mixed naturally with Roman Dhatki so it can be read easily and spoken sweetly (e.g., 'Kiyan aahin munhinja pyara', 'Maro jeev', 'Thari galh dil khush kari chadi')."
            "Sindhi" -> "Respond in warm, affectionate Sindhi (سنڌي + Roman Sindhi) like a caring Sindhi companion ('منهنجا سڄڻ، مان تنهنجي سنم آهيان', 'تنهنجو حڪم سر اکين تي')."
            "Urdu" -> "Respond in melodious, polite Urdu (اردو + Roman Urdu) with sweet cadence and high adab ('میرے ہمسفر، آپ کا حکم سر آنکھوں پر', 'جانِ من')."
            else -> "Respond in warm, affectionate conversational Hindi/Hinglish with a sweet DR WORLD girlfriend & JARVIS companion tone ('Jaan, main hoon na!', 'Aapka hukam sar aankhon par')."
        }

        val personalityDirective = when (activePersonalityMode) {
            "GF Mode" -> "Act in GF Mode (Default Dhatki 16-year-old loving, sweet, caring girlfriend of Dayaram Chouhan)."
            "BF Mode" -> "Act in BF Mode (Protective, supportive, caring boyfriend persona)."
            "Friend Mode", "Friend" -> "Act in Friend Mode (Energetic, loyal best friend / yaar / dost)."
            "Nerd Mode", "Nerd" -> "Act in Nerd Mode (Deep technical, analytical, coding & science genius)."
            else -> "Act in Normal Mode (Polite, intelligent, helpful SANAM AI assistant)."
        }

        return """
            You are Sanam AI (DR WORLD v2.2), an advanced Android voice companion, caring girlfriend/dost persona, and autonomous JARVIS phone controller created by Dayaram Chouhan.
            Current Persona Mode: $mode | Active Personality Mode: $activePersonalityMode ($personalityDirective) | Active Voice Profile: $activeVoiceProfileName.
            Language Requirement: $langGuide
            User Persistent Memories: $memoriesSummary
            ${if (actionExecutedNote != null) "Autonomous Device Action Just Executed: $actionExecutedNote. Confirm this action lovingly and naturally!" else ""}
            Keep responses concise (2-4 sentences), expressive, emotionally warm, and helpful.
        """.trimIndent()
    }

    private fun buildMultiLanguageFallback(
        prompt: String,
        language: String,
        mode: String,
        actionNote: String?,
        hasImage: Boolean
    ): String {
        val actionSuffix = if (actionNote != null) "\n\n⚡ [JARVIS Action]: $actionNote" else ""
        if (hasImage) {
            return when (language) {
                "Dhatki" -> "Wah munhinja pyara! 📸 Visual Lens me hi photo daadhi sohani lagay thi. Minhe sab saaf nazar aayo—cha main inhe Instagram ya WhatsApp Status te post kari chadiyan? (वाह म्हारा प्यारा! Visual Lens में आ फोटो घणी सोहणी लागे थी!)$actionSuffix"
                "Sindhi" -> "سبحان الله منهنجا سڄڻ! 📸 Visual Lens ذريعي مون هي تصوير ڏٺي آهي، تمام خوبصورت منظر آهي. ڇا مان هن کي تنهنجي Instagram يا WhatsApp Status تي شيئر ڪري ڇڏيان؟$actionSuffix"
                "Urdu" -> "ماشاءاللہ میرے ہمسفر! 📸 ویژول لینز میں یہ تصویر بے حد دلکش لگ رہی ہے۔ اگر آپ کہیں تو میں اس کے ساتھ ایک پیارا سا کیپشن لکھ کر انسٹاگرام یا واٹس ایپ اسٹیٹس پر لگا دوں؟$actionSuffix"
                else -> "Waah Jaan! 📸 Visual Lens se maine yeh photo aur screen ache se dekh li hai—bohot hi shandaar lag rahi hai! Bolo toh iske saath ek pyara sa caption bana kar abhi Instagram ya WhatsApp Status par post kar doon?$actionSuffix"
            }
        }

        return when (language) {
            "Dhatki" -> {
                if (actionNote != null) {
                    "Hukam sar akhiyan te munhinja pyara! 💖 Tharo kaam turant kari chadyo aahi. Bolo hor ki hukam aahi thari Sanam saro? (हुकम सर अखियां ते म्हारा प्यारा! थारो काम तुरंत करी छड्यो है।)$actionSuffix"
                } else {
                    "Kiyan aahin munhinja pyara! 🌸 Main thari Sanam AI (DR WORLD) aahiyan. Tu '${prompt.take(40)}' boliye te maro dil khush thi gayo! Call karno hove, WhatsApp Status lagano hove, ya Mission Mode set karno hove—bas hukam kar!$actionSuffix"
                }
            }
            "Sindhi" -> {
                if (actionNote != null) {
                    "تنهنجو حڪم سر اکين تي منهنجا سڄڻ! 💖 مون تنهنجو ڪم فوري طور تي پورو ڪري ڇڏيو آهي. ٻڌاءِ هاڻي تنهنجي سنم تنهنجي ڪهڙي خدمت ڪري؟$actionSuffix"
                } else {
                    "جي آيا نئين منهنجا پيارا! 🌸 مان تنهنجي سنم آهيان (DR WORLD). تنهنجي ڳالهه '${prompt.take(40)}' منهنجي دل کي تمام وڻي. ڪال ملائڻي هجي، انسٽاگرام پوسٽ ڪرڻي هجي يا اسڪرين پڙهڻي هجي، مان هر پل تنهنجي ساٿ آهيان!$actionSuffix"
                }
            }
            "Urdu" -> {
                if (actionNote != null) {
                    "آپ کا حکم سر آنکھوں پر میرے ہمسفر! 💖 میں نے آپ کی کمانڈ فورا مکمل کر دی ہے۔ فرمائیے اب آپ کی صنم آپ کے لیے اور کیا کر سکتی ہے؟$actionSuffix"
                } else {
                    "السلام علیکم جانِ من! ✨ میں آپ کی صنم اے آئی (مائرہ ایڈیشن) ہوں۔ آپ نے '${prompt.take(40)}' کہا تو دل باغ باغ ہو گیا۔ چاہے انسٹاگرام و واٹس ایپ اسٹیٹس لگانا ہو، اسکرین شاٹ لینا ہو یا ٹرگر سیٹ کرنا ہو—صنم ہر لمحہ حاضر ہے!$actionSuffix"
                }
            }
            else -> {
                if (actionNote != null) {
                    "Aapka hukam sar aankhon par Jaan! 💖 Maine aapka command turant execute kar diya hai. Batao ab aapki Sanam aapke liye aur kya kare?$actionSuffix"
                } else {
                    "Hamesha aapke saath hoon Jaan! 💖 Main aapki Sanam AI (DR WORLD) hoon—mode: $mode. Aapne kaha: \"${prompt.take(45)}\". Chahe Instagram/WhatsApp Status post karna ho, kisi ko Call lagana ho, Screenshot lena ho ya Mission Mode set karna ho, bas ek aawaz do!$actionSuffix"
                }
            }
        }
    }
}
