package com.example

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material.icons.filled.SwipeVertical
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.theme.AuraTheme
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * SanamAccessibilityService - Full MYRA Beater Accessibility Engine
 * Capabilities:
 * 1. READ SCREEN: Reads active window hierarchy & on-screen text in real time into Room DB (Memory).
 * 2. PERFORM ACTIONS:
 *    - Tap at (x, y) coordinates via GestureDescription
 *    - Swipe (Up, Down, Left, Right) via GestureDescription
 *    - Global Back (GLOBAL_ACTION_BACK)
 *    - Global Home (GLOBAL_ACTION_HOME)
 *    - System Take Screenshot (GLOBAL_ACTION_TAKE_SCREENSHOT)
 *    - Auto-Click UI buttons by label (e.g., "Post", "Share", "Next", "Send", "My status")
 *      so Post to Insta/FB, WhatsApp Status, and Take Screenshot work seamlessly.
 */
class SanamAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Memory.init(applicationContext)
        _isConnected.value = true
        ScreenReaderService.isServiceConnectedFlow.value = true
        _lastActionStatus.value = "SanamAccessibilityService Active • Read Screen + Gestures Ready"
        Memory.saveScreenText(
            "SanamAccessibilityService connected: Read Screen + Tap/Swipe/Back/Home/Screenshot enabled.",
            "com.sanam.accessibility"
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: "android.screen"
        val directText = event.text?.joinToString(" ") { it.toString() }?.trim().orEmpty()
        if (directText.length > 2) {
            _lastReadScreenText.value = directText
            Memory.saveScreenText(directText, pkg)
        } else {
            val root = rootInActiveWindow
            if (root != null) {
                val sb = StringBuilder()
                collectNodeText(root, sb, 0)
                val collected = sb.toString().trim()
                if (collected.isNotEmpty()) {
                    _lastReadScreenText.value = collected.take(300)
                    Memory.saveScreenText(collected.take(260), pkg)
                }
            }
        }

        // If a pending social auto-post target is queued (e.g. WhatsApp Status / Instagram / Facebook),
        // automatically look for matching action buttons ("Send", "Share", "Post", "My status", "Done")
        val pendingTarget = pendingAutoClickLabel
        if (!pendingTarget.isNullOrBlank()) {
            val clicked = clickNodeByTextInternal(pendingTarget)
            if (clicked) {
                _lastActionStatus.value = "✅ Auto-clicked '$pendingTarget' in $pkg"
                pendingAutoClickLabel = null
            }
        }
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 5 || out.length > 300) return
        val nodeText = node.text?.toString()?.trim()
            ?: node.contentDescription?.toString()?.trim()
        if (!nodeText.isNullOrEmpty() && nodeText.length > 1) {
            if (out.isNotEmpty()) out.append(" • ")
            out.append(nodeText)
        }
        val count = node.childCount.coerceAtMost(10)
        for (i in 0 until count) {
            collectNodeText(node.getChild(i), out, depth + 1)
        }
    }

    private fun clickNodeByTextInternal(targetText: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val matchedNodes = root.findAccessibilityNodeInfosByText(targetText)
        if (!matchedNodes.isNullOrEmpty()) {
            for (node in matchedNodes) {
                if (node.isClickable) {
                    return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                var parent = node.parent
                var hops = 0
                while (parent != null && hops < 4) {
                    if (parent.isClickable) {
                        return parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                    }
                    parent = parent.parent
                    hops++
                }
            }
        }
        return false
    }

    override fun onInterrupt() {
        _isConnected.value = false
        ScreenReaderService.isServiceConnectedFlow.value = false
    }

    override fun onDestroy() {
        if (instance === this) {
            instance = null
        }
        _isConnected.value = false
        ScreenReaderService.isServiceConnectedFlow.value = false
        super.onDestroy()
    }

    companion object {
        @Volatile
        private var instance: SanamAccessibilityService? = null

        @Volatile
        private var pendingAutoClickLabel: String? = null

        private val _isConnected = MutableStateFlow(false)
        val isConnected: StateFlow<Boolean> = _isConnected.asStateFlow()

        private val _lastReadScreenText = MutableStateFlow(
            "Sanam AI Screen Reader Ready • Tap 'Read Screen' or enable Accessibility Service."
        )
        val lastReadScreenText: StateFlow<String> = _lastReadScreenText.asStateFlow()

        private val _lastActionStatus = MutableStateFlow(
            "Accessibility Actions Ready (Tap • Swipe • Back • Home • Screenshot)"
        )
        val lastActionStatus: StateFlow<String> = _lastActionStatus.asStateFlow()

        fun isAccessibilityPermissionGranted(context: Context): Boolean {
            if (_isConnected.value) return true
            return try {
                val enabledServices = Settings.Secure.getString(
                    context.contentResolver,
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                ).orEmpty()
                enabledServices.contains(context.packageName, ignoreCase = true)
            } catch (_: Exception) {
                false
            }
        }

        fun openAccessibilitySettings(context: Context) {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                _lastActionStatus.value = "Opened Android Accessibility Settings for Sanam AI"
            } catch (_: Exception) {
                _lastActionStatus.value = "Unable to open Accessibility Settings on this device"
            }
        }

        /**
         * Queues an automatic button click (e.g., "Share", "Post", "Send") when Instagram/FB/WhatsApp opens.
         */
        fun queueSocialAutoClick(buttonLabel: String) {
            pendingAutoClickLabel = buttonLabel
            _lastActionStatus.value = "Queued Accessibility Auto-Tap for '$buttonLabel'"
        }

        /**
         * READ SCREEN: Reads all visible text from the active screen window immediately.
         */
        fun readScreenNow(context: Context? = null): String {
            val svc = instance
            if (svc != null) {
                val root = svc.rootInActiveWindow
                if (root != null) {
                    val sb = StringBuilder()
                    svc.collectNodeText(root, sb, 0)
                    val result = sb.toString().trim()
                    if (result.isNotEmpty()) {
                        _lastReadScreenText.value = result
                        val pkg = root.packageName?.toString() ?: "android.screen"
                        Memory.saveScreenText(result, pkg)
                        _lastActionStatus.value = "📖 Read Screen ($pkg): ${result.take(80)}"
                        return result
                    }
                }
            }
            val fallback = Memory.liveScreenStream.value.firstOrNull()
                ?: "DR WORLD Screen Reader active • Hello, Dayaram Chouhan (Online Ready)"
            _lastReadScreenText.value = fallback
            if (context != null) {
                Memory.saveScreenText(fallback, context.packageName)
            }
            _lastActionStatus.value = "📖 Screen Read Snapshot: ${fallback.take(70)}"
            return fallback
        }

        /**
         * PERFORM ACTION - TAP at (x, y)
         */
        fun performTap(x: Float = 540f, y: Float = 1100f): Boolean {
            val svc = instance
            if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val tapPath = Path().apply { moveTo(x, y) }
                val stroke = GestureDescription.StrokeDescription(tapPath, 0L, 90L)
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                val dispatched = svc.dispatchGesture(gesture, null, null)
                _lastActionStatus.value = if (dispatched) {
                    "👆 Performed Tap Gesture at (${x.toInt()}, ${y.toInt()})"
                } else {
                    "Tap Gesture queued at (${x.toInt()}, ${y.toInt()})"
                }
                return dispatched
            }
            _lastActionStatus.value = "👆 Tap simulated at (${x.toInt()}, ${y.toInt()}) — Enable Accessibility for system-wide tap"
            return false
        }

        /**
         * PERFORM ACTION - SWIPE (Up / Down / Left / Right)
         */
        fun performSwipe(
            startX: Float = 540f,
            startY: Float = 1500f,
            endX: Float = 540f,
            endY: Float = 500f,
            durationMs: Long = 300L
        ): Boolean {
            val svc = instance
            if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
                val swipePath = Path().apply {
                    moveTo(startX, startY)
                    lineTo(endX, endY)
                }
                val stroke = GestureDescription.StrokeDescription(swipePath, 0L, durationMs)
                val gesture = GestureDescription.Builder().addStroke(stroke).build()
                val dispatched = svc.dispatchGesture(gesture, null, null)
                _lastActionStatus.value = if (dispatched) {
                    "🖐️ Performed Swipe Gesture (${startY.toInt()} -> ${endY.toInt()})"
                } else {
                    "Swipe Gesture queued"
                }
                return dispatched
            }
            val scrollTried = instance?.rootInActiveWindow?.performAction(
                AccessibilityNodeInfo.ACTION_SCROLL_FORWARD
            ) ?: false
            _lastActionStatus.value = "🖐️ Swipe Gesture executed (Scroll=${scrollTried})"
            return scrollTried
        }

        /**
         * PERFORM ACTION - GLOBAL BACK
         */
        fun performBack(): Boolean {
            val svc = instance
            val ok = svc?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
            _lastActionStatus.value = if (ok) {
                "⬅️ Executed System BACK Action"
            } else {
                "⬅️ Back Action ready (Enable Sanam Accessibility Service for global Back)"
            }
            return ok
        }

        /**
         * PERFORM ACTION - GLOBAL HOME
         */
        fun performHome(context: Context? = null): Boolean {
            val svc = instance
            if (svc != null) {
                val ok = svc.performGlobalAction(GLOBAL_ACTION_HOME)
                if (ok) {
                    _lastActionStatus.value = "🏠 Executed System HOME Action"
                    return true
                }
            }
            if (context != null) {
                return try {
                    val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                        addCategory(Intent.CATEGORY_HOME)
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(homeIntent)
                    _lastActionStatus.value = "🏠 Navigated to Home Screen"
                    true
                } catch (_: Exception) {
                    false
                }
            }
            return false
        }

        /**
         * PERFORM ACTION - SYSTEM SCREENSHOT (API 28+)
         */
        fun performAccessibilityScreenshot(): Boolean {
            val svc = instance
            if (svc != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val ok = svc.performGlobalAction(GLOBAL_ACTION_TAKE_SCREENSHOT)
                _lastActionStatus.value = if (ok) {
                    "📸 Taken System Screenshot via SanamAccessibilityService"
                } else {
                    "📸 Using In-App ScreenshotHelper fallback"
                }
                return ok
            }
            return false
        }

        /**
         * Clicks a node matching text or sets text into an editable field.
         */
        fun clickByText(label: String): Boolean {
            val svc = instance ?: return false
            val ok = svc.clickNodeByTextInternal(label)
            _lastActionStatus.value = if (ok) {
                "✅ Clicked UI element '$label'"
            } else {
                "🔍 Searched screen for '$label'"
            }
            return ok
        }

        fun fillTextInFocusedNode(text: String): Boolean {
            val root = instance?.rootInActiveWindow ?: return false
            val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
            val args = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
        }
    }
}

/**
 * Permission & Action Control Card for SanamAccessibilityService
 * Displays permission status, 1-tap button to open Accessibility Settings,
 * and interactive buttons for READ SCREEN, TAP, SWIPE, BACK, HOME, and SCREENSHOT.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SanamAccessibilityPermissionCard(
    auraTheme: AuraTheme,
    onTakeAppScreenshot: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isConnected by SanamAccessibilityService.isConnected.collectAsStateWithLifecycle()
    val lastActionStatus by SanamAccessibilityService.lastActionStatus.collectAsStateWithLifecycle()
    val lastScreenText by SanamAccessibilityService.lastReadScreenText.collectAsStateWithLifecycle()
    val isEnabledInSettings = isConnected || SanamAccessibilityService.isAccessibilityPermissionGranted(context)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("sanam_accessibility_permission_card"),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.95f)
        ),
        border = BorderStroke(1.5.dp, if (isEnabledInSettings) Color(0xFF00FF88) else auraTheme.primary)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(
                                if (isEnabledInSettings) Color(0xFF00FF88).copy(alpha = 0.2f)
                                else auraTheme.primary.copy(alpha = 0.2f)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = if (isEnabledInSettings) Icons.Default.CheckCircle else Icons.Default.AccessibilityNew,
                            contentDescription = "Sanam Accessibility Service",
                            tint = if (isEnabledInSettings) Color(0xFF00FF88) else auraTheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "♿ SANAM ACCESSIBILITY SERVICE",
                            style = MaterialTheme.typography.titleMedium,
                            color = if (isEnabledInSettings) Color(0xFF00FF88) else auraTheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isEnabledInSettings) {
                                "ACTIVE • Read Screen + Tap/Swipe/Back/Home Enabled"
                            } else {
                                "Permission Required for Auto Insta/FB/WhatsApp & Screen Control"
                            },
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Button(
                    onClick = { SanamAccessibilityService.openAccessibilitySettings(context) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isEnabledInSettings) Color(0xFF00FF88) else auraTheme.primary
                    ),
                    modifier = Modifier.testTag("grant_accessibility_permission_btn")
                ) {
                    Text(
                        text = if (isEnabledInSettings) "Settings" else "Grant Permission",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Live Action & Screen Reader Telemetry Box
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f),
                border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.3f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text(
                        text = lastActionStatus,
                        style = MaterialTheme.typography.labelLarge,
                        color = auraTheme.primary,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Screen Text: $lastScreenText",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        maxLines = 2
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Perform Actions Row: Read Screen | Tap | Swipe | Back | Home | Screenshot
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedButton(
                    onClick = { SanamAccessibilityService.readScreenNow(context) },
                    modifier = Modifier.testTag("acc_action_read_screen")
                ) {
                    Icon(Icons.Default.Visibility, contentDescription = "Read Screen", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Read Screen")
                }

                OutlinedButton(
                    onClick = { SanamAccessibilityService.performTap(540f, 1100f) },
                    modifier = Modifier.testTag("acc_action_tap")
                ) {
                    Icon(Icons.Default.TouchApp, contentDescription = "Tap", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Tap")
                }

                OutlinedButton(
                    onClick = { SanamAccessibilityService.performSwipe() },
                    modifier = Modifier.testTag("acc_action_swipe")
                ) {
                    Icon(Icons.Default.SwipeVertical, contentDescription = "Swipe", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Swipe")
                }

                OutlinedButton(
                    onClick = { SanamAccessibilityService.performBack() },
                    modifier = Modifier.testTag("acc_action_back")
                ) {
                    Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Back")
                }

                OutlinedButton(
                    onClick = { SanamAccessibilityService.performHome(context) },
                    modifier = Modifier.testTag("acc_action_home")
                ) {
                    Icon(Icons.Default.Home, contentDescription = "Home", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Home")
                }

                OutlinedButton(
                    onClick = {
                        val systemCaptured = SanamAccessibilityService.performAccessibilityScreenshot()
                        if (!systemCaptured) {
                            onTakeAppScreenshot()
                        }
                    },
                    modifier = Modifier.testTag("acc_action_screenshot")
                ) {
                    Icon(Icons.Default.ScreenshotMonitor, contentDescription = "Screenshot", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Screenshot")
                }
            }
        }
    }
}
