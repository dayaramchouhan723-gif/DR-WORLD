package com.example

import android.accessibilityservice.AccessibilityService
import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PixelFormat
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import androidx.core.app.NotificationCompat
import androidx.core.graphics.createBitmap
import androidx.core.graphics.get
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sqrt

/**
 * MYRA Screen Reader Accessibility Service
 * Reads on-screen text and stores it in Room DB via Memory.saveScreenText
 */
class ScreenReaderService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        Memory.init(applicationContext)
        isServiceConnectedFlow.value = true
        Memory.saveScreenText(
            "Sanam AI ScreenReaderService connected & actively monitoring screen.",
            "com.sanam.accessibility"
        )
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val pkg = event.packageName?.toString() ?: "android.screen"
        val directText = event.text?.joinToString(" ") { it.toString() }?.trim().orEmpty()
        if (directText.isNotEmpty() && directText.length > 2) {
            Memory.saveScreenText(directText, pkg)
        } else {
            val root = rootInActiveWindow
            if (root != null) {
                val sb = StringBuilder()
                collectNodeText(root, sb, 0)
                val collected = sb.toString().trim()
                if (collected.isNotEmpty()) {
                    Memory.saveScreenText(collected.take(240), pkg)
                }
            }
        }
    }

    private fun collectNodeText(node: AccessibilityNodeInfo?, out: StringBuilder, depth: Int) {
        if (node == null || depth > 4 || out.length > 240) return
        val nodeText = node.text?.toString()?.trim()
        if (!nodeText.isNullOrEmpty() && nodeText.length > 2) {
            if (out.isNotEmpty()) out.append(" • ")
            out.append(nodeText)
        }
        val count = node.childCount.coerceAtMost(8)
        for (i in 0 until count) {
            collectNodeText(node.getChild(i), out, depth + 1)
        }
    }

    override fun onInterrupt() {
        isServiceConnectedFlow.value = false
    }

    override fun onDestroy() {
        isServiceConnectedFlow.value = false
        super.onDestroy()
    }

    companion object {
        val isServiceConnectedFlow = MutableStateFlow(false)

        fun openAccessibilitySettings(context: Context) {
            try {
                val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
            } catch (_: Exception) {
            }
        }
    }
}

data class VisualContentTelemetry(
    val resolution: String,
    val aspectRatio: String,
    val averageBrightnessPercent: Int,
    val dominantHexColor: String,
    val captureSource: String
)

data class CapturedScreenshot(
    val bitmap: Bitmap,
    val file: File,
    val visualTelemetry: VisualContentTelemetry,
    val analyzeImmediately: Boolean = true,
    val customAnalysisPrompt: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Foreground MediaProjection Service for Full-Screen Screenshot & Visual Lens Analysis.
 * Complies with Android 10–15+ (API 29–36) FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
 * and MediaProjection.Callback registration requirements.
 */
class MediaProjectionService : Service() {

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val projectionCallback = object : MediaProjection.Callback() {
        override fun onStop() {
            cleanupProjectionResources()
            ScreenshotHelper.setProjectionServiceActive(false)
            stopSelf()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_START_AND_CAPTURE
        when (action) {
            ACTION_STOP_PROJECTION -> {
                stopProjectionAndService()
                return START_NOT_STICKY
            }

            ACTION_CAPTURE_FRAME_NOW -> {
                val prompt = intent?.getStringExtra(EXTRA_ANALYSIS_PROMPT)
                if (mediaProjection != null) {
                    captureVirtualDisplayFrame(analyzeImmediately = true, customPrompt = prompt)
                }
                return START_STICKY
            }

            ACTION_START_AND_CAPTURE -> {
                startMediaProjectionForeground()
                val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
                    ?: Activity.RESULT_CANCELED
                @Suppress("DEPRECATION")
                val resultData: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    intent?.getParcelableExtra(EXTRA_RESULT_DATA)
                }
                val analyze = intent?.getBooleanExtra(EXTRA_ANALYZE_IMMEDIATELY, true) ?: true
                val prompt = intent?.getStringExtra(EXTRA_ANALYSIS_PROMPT)

                if (resultCode == Activity.RESULT_OK && resultData != null) {
                    initMediaProjectionAndCapture(resultCode, resultData, analyze, prompt)
                } else {
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    private fun startMediaProjectionForeground() {
        val channelId = "sanam_media_projection_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Sanam AI Visual Lens Screen Capture",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Active while Sanam AI Visual Lens captures full-screen frames"
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }

        val stopIntent = Intent(this, MediaProjectionService::class.java).apply {
            action = ACTION_STOP_PROJECTION
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            901,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentTitle("Sanam AI Visual Lens Active")
            .setContentText("MediaProjection full-screen capture & AI visual analysis ready")
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "Stop Lens", stopPendingIntent)
            .setOngoing(true)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun initMediaProjectionAndCapture(
        resultCode: Int,
        resultData: Intent,
        analyzeImmediately: Boolean,
        customPrompt: String?
    ) {
        try {
            cleanupProjectionResources()
            val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
            val projection = mpm?.getMediaProjection(resultCode, resultData)
            if (projection == null) {
                ScreenshotHelper.setProjectionServiceActive(false)
                stopSelf()
                return
            }
            // Mandatory on Android 14+ (API 34+) before createVirtualDisplay
            projection.registerCallback(projectionCallback, mainHandler)
            mediaProjection = projection
            ScreenshotHelper.setProjectionServiceActive(true)
            Memory.saveScreenText(
                "MediaProjectionService started: VirtualDisplay initialized for full-screen Visual Lens.",
                "com.sanam.mediaprojection"
            )
            captureVirtualDisplayFrame(analyzeImmediately, customPrompt)
        } catch (e: Exception) {
            Memory.saveScreenText(
                "MediaProjection initialization error: ${e.localizedMessage}",
                "com.sanam.mediaprojection"
            )
            ScreenshotHelper.setProjectionServiceActive(false)
            stopSelf()
        }
    }

    private fun captureVirtualDisplayFrame(
        analyzeImmediately: Boolean,
        customPrompt: String?
    ) {
        val projection = mediaProjection ?: return
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtLeast(720)
        val height = metrics.heightPixels.coerceAtLeast(1280)
        val density = metrics.densityDpi

        try {
            virtualDisplay?.release()
            imageReader?.close()

            val reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
            imageReader = reader

            virtualDisplay = projection.createVirtualDisplay(
                "SanamVisualLensDisplay",
                width,
                height,
                density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                reader.surface,
                null,
                mainHandler
            )

            // Wait briefly for the VirtualDisplay surface to render a clean frame
            mainHandler.postDelayed({
                try {
                    val image = reader.acquireLatestImage()
                    if (image != null) {
                        val planes = image.planes
                        val buffer = planes[0].buffer
                        val pixelStride = planes[0].pixelStride
                        val rowStride = planes[0].rowStride
                        val rowPadding = rowStride - pixelStride * width

                        val paddedBitmap = createBitmap(
                            width + rowPadding / pixelStride,
                            height,
                            Bitmap.Config.ARGB_8888
                        )
                        paddedBitmap.copyPixelsFromBuffer(buffer)
                        image.close()

                        val cleanBitmap = Bitmap.createBitmap(paddedBitmap, 0, 0, width, height)
                        if (paddedBitmap != cleanBitmap) {
                            paddedBitmap.recycle()
                        }

                        val outFile = ScreenshotHelper.saveBitmapToLocalStorage(
                            context = this@MediaProjectionService,
                            bitmap = cleanBitmap,
                            prefix = "sanam_mediaprojection"
                        )

                        val telemetry = ScreenshotHelper.computeVisualTelemetry(
                            cleanBitmap,
                            "MediaProjection VirtualDisplay"
                        )
                        val captured = CapturedScreenshot(
                            bitmap = cleanBitmap,
                            file = outFile,
                            visualTelemetry = telemetry,
                            analyzeImmediately = analyzeImmediately,
                            customAnalysisPrompt = customPrompt
                        )
                        ScreenshotHelper.onMediaProjectionFrameCaptured(captured)
                        Memory.saveScreenText(
                            "Full-screen MediaProjection screenshot saved to local storage (${outFile.absolutePath})",
                            "com.sanam.mediaprojection"
                        )
                    }
                } catch (e: Exception) {
                    Memory.saveScreenText(
                        "Frame decode note: ${e.localizedMessage}",
                        "com.sanam.mediaprojection"
                    )
                }
            }, 260L)
        } catch (e: Exception) {
            Memory.saveScreenText(
                "VirtualDisplay capture error: ${e.localizedMessage}",
                "com.sanam.mediaprojection"
            )
        }
    }

    private fun cleanupProjectionResources() {
        try {
            virtualDisplay?.release()
            virtualDisplay = null
            imageReader?.close()
            imageReader = null
        } catch (_: Exception) {
        }
    }

    private fun stopProjectionAndService() {
        cleanupProjectionResources()
        try {
            mediaProjection?.unregisterCallback(projectionCallback)
            mediaProjection?.stop()
        } catch (_: Exception) {
        }
        mediaProjection = null
        ScreenshotHelper.setProjectionServiceActive(false)
        Memory.saveScreenText("MediaProjectionService stopped.", "com.sanam.mediaprojection")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    override fun onDestroy() {
        cleanupProjectionResources()
        ScreenshotHelper.setProjectionServiceActive(false)
        super.onDestroy()
    }

    companion object {
        private const val NOTIFICATION_ID = 4082
        const val ACTION_START_AND_CAPTURE = "com.example.action.START_AND_CAPTURE"
        const val ACTION_CAPTURE_FRAME_NOW = "com.example.action.CAPTURE_FRAME_NOW"
        const val ACTION_STOP_PROJECTION = "com.example.action.STOP_PROJECTION"

        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val EXTRA_ANALYZE_IMMEDIATELY = "EXTRA_ANALYZE_IMMEDIATELY"
        const val EXTRA_ANALYSIS_PROMPT = "EXTRA_ANALYSIS_PROMPT"
    }
}

object ScreenshotHelper {

    private val _isProjectionServiceActive = MutableStateFlow(false)
    val isProjectionServiceActive: StateFlow<Boolean> = _isProjectionServiceActive.asStateFlow()

    private val _latestMediaProjectionCapture = MutableStateFlow<CapturedScreenshot?>(null)
    val latestMediaProjectionCapture: StateFlow<CapturedScreenshot?> =
        _latestMediaProjectionCapture.asStateFlow()

    private val _latestSavedLocalFile = MutableStateFlow<File?>(null)
    val latestSavedLocalFile: StateFlow<File?> = _latestSavedLocalFile.asStateFlow()

    fun setProjectionServiceActive(active: Boolean) {
        _isProjectionServiceActive.value = active
    }

    fun onMediaProjectionFrameCaptured(captured: CapturedScreenshot) {
        _latestSavedLocalFile.value = captured.file
        _latestMediaProjectionCapture.value = captured
    }

    /**
     * Saves a captured Bitmap to the app's persistent local storage (context.filesDir/screenshots)
     * and mirrors a copy to cacheDir/shared_images for FileProvider sharing.
     */
    fun saveBitmapToLocalStorage(
        context: Context,
        bitmap: Bitmap,
        prefix: String = "sanam_screenshot"
    ): File {
        val timestamp = System.currentTimeMillis()
        val fileName = "${prefix}_${timestamp}.png"

        // Save to app's persistent internal local storage (filesDir/screenshots)
        val localDir = File(context.filesDir, "screenshots").apply { mkdirs() }
        val localFile = File(localDir, fileName)
        FileOutputStream(localFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
            out.flush()
        }

        // Also keep a copy in cacheDir/shared_images for social media FileProvider intents
        try {
            val sharedDir = File(context.cacheDir, "shared_images").apply { mkdirs() }
            val sharedFile = File(sharedDir, fileName)
            localFile.copyTo(sharedFile, overwrite = true)
        } catch (_: Exception) {
        }

        _latestSavedLocalFile.value = localFile
        return localFile
    }

    /**
     * Starts MediaProjectionService after user grants MediaProjection screen capture consent
     */
    fun startMediaProjectionCaptureService(
        context: Context,
        resultCode: Int,
        resultData: Intent,
        analyzeImmediately: Boolean = true,
        customPrompt: String? = null
    ) {
        val serviceIntent = Intent(context, MediaProjectionService::class.java).apply {
            action = MediaProjectionService.ACTION_START_AND_CAPTURE
            putExtra(MediaProjectionService.EXTRA_RESULT_CODE, resultCode)
            putExtra(MediaProjectionService.EXTRA_RESULT_DATA, resultData)
            putExtra(MediaProjectionService.EXTRA_ANALYZE_IMMEDIATELY, analyzeImmediately)
            putExtra(MediaProjectionService.EXTRA_ANALYSIS_PROMPT, customPrompt)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(serviceIntent)
        } else {
            context.startService(serviceIntent)
        }
    }

    /**
     * Triggers an immediate full-screen frame capture from an already-active MediaProjectionService session
     */
    fun requestFrameFromActiveProjection(context: Context, customPrompt: String? = null) {
        val intent = Intent(context, MediaProjectionService::class.java).apply {
            action = MediaProjectionService.ACTION_CAPTURE_FRAME_NOW
            putExtra(MediaProjectionService.EXTRA_ANALYSIS_PROMPT, customPrompt)
        }
        context.startService(intent)
    }

    /**
     * Stops the running MediaProjectionService session
     */
    fun stopMediaProjectionService(context: Context) {
        val intent = Intent(context, MediaProjectionService::class.java).apply {
            action = MediaProjectionService.ACTION_STOP_PROJECTION
        }
        context.startService(intent)
    }

    /**
     * Captures the active window view into a real Bitmap & PNG file immediately,
     * with visual content telemetry (resolution, brightness, dominant color).
     */
    fun takeScreenshot(
        activity: Activity,
        analyzeImmediately: Boolean = true,
        customPrompt: String? = null
    ): CapturedScreenshot? {
        return try {
            val rootView = activity.window.decorView.rootView
            val width = rootView.width.coerceAtLeast(720)
            val height = rootView.height.coerceAtLeast(1280)
            val bitmap = createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            rootView.draw(canvas)

            val outFile = saveBitmapToLocalStorage(
                context = activity,
                bitmap = bitmap,
                prefix = "sanam_screenshot"
            )
            val telemetry = computeVisualTelemetry(bitmap, "Window DecorView Capture")
            Memory.saveScreenText(
                "Screenshot saved to local storage (${outFile.name}, ${telemetry.resolution})",
                "com.sanam.screenshot"
            )
            val captured = CapturedScreenshot(
                bitmap = bitmap,
                file = outFile,
                visualTelemetry = telemetry,
                analyzeImmediately = analyzeImmediately,
                customAnalysisPrompt = customPrompt
            )
            _latestMediaProjectionCapture.value = captured
            captured
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Computes real visual telemetry from a captured Bitmap (resolution, brightness, dominant color)
     */
    fun computeVisualTelemetry(bitmap: Bitmap, source: String): VisualContentTelemetry {
        val w = bitmap.width
        val h = bitmap.height
        val stepX = (w / 12).coerceAtLeast(1)
        val stepY = (h / 12).coerceAtLeast(1)
        var rSum = 0L
        var gSum = 0L
        var bSum = 0L
        var lumSum = 0.0
        var count = 0

        var x = stepX / 2
        while (x < w) {
            var y = stepY / 2
            while (y < h) {
                val pixel = bitmap[x, y]
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)
                rSum += r
                gSum += g
                bSum += b
                lumSum += (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
                count++
                y += stepY
            }
            x += stepX
        }

        val safeCount = count.coerceAtLeast(1)
        val avgR = (rSum / safeCount).toInt().coerceIn(0, 255)
        val avgG = (gSum / safeCount).toInt().coerceIn(0, 255)
        val avgB = (bSum / safeCount).toInt().coerceIn(0, 255)
        val brightnessPct = ((lumSum / safeCount) * 100.0).toInt().coerceIn(1, 100)
        val hexColor = String.format("#%02X%02X%02X", avgR, avgG, avgB)
        val ratio = String.format(java.util.Locale.US, "%.2f:1", h.toFloat() / w.coerceAtLeast(1))

        return VisualContentTelemetry(
            resolution = "${w}x${h} px",
            aspectRatio = ratio,
            averageBrightnessPercent = brightnessPct,
            dominantHexColor = hexColor,
            captureSource = source
        )
    }

    /**
     * Creates a system MediaProjection screen capture intent for full-device capture permission
     */
    fun createMediaProjectionIntent(context: Context): Intent? {
        return try {
            val mpm = context.getSystemService(Context.MEDIA_PROJECTION_SERVICE) as? MediaProjectionManager
            mpm?.createScreenCaptureIntent()
        } catch (_: Exception) {
            null
        }
    }
}

/**
 * MYRA Security & Touch Guard Sensor Engine
 * Uses real Proximity and Accelerometer sensors for Pocket Touch Guard & Anti-Theft Motion Alert
 */
class MyraSecurityManager(context: Context) : SensorEventListener {
    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val proximitySensor: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_PROXIMITY)
    private val accelerometer: Sensor? = sensorManager?.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val _proximityNear = MutableStateFlow(false)
    val proximityNear: StateFlow<Boolean> = _proximityNear.asStateFlow()

    private val _motionDelta = MutableStateFlow(0f)
    val motionDelta: StateFlow<Float> = _motionDelta.asStateFlow()

    private val _securityAlertCount = MutableStateFlow(0)
    val securityAlertCount: StateFlow<Int> = _securityAlertCount.asStateFlow()

    private var lastAccel = 9.8f
    private var currentAccel = 9.8f

    fun startMonitoring() {
        proximitySensor?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL)
        }
        accelerometer?.let {
            sensorManager?.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    fun stopMonitoring() {
        sensorManager?.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return
        when (event.sensor.type) {
            Sensor.TYPE_PROXIMITY -> {
                val distance = event.values.firstOrNull() ?: 5f
                val maxRange = proximitySensor?.maximumRange ?: 5f
                _proximityNear.value = distance < maxRange && distance < 3f
            }
            Sensor.TYPE_ACCELEROMETER -> {
                val x = event.values[0]
                val y = event.values[1]
                val z = event.values[2]
                lastAccel = currentAccel
                currentAccel = sqrt((x * x + y * y + z * z).toDouble()).toFloat()
                val delta = kotlin.math.abs(currentAccel - lastAccel)
                _motionDelta.value = delta
                if (delta > 6.5f) {
                    _securityAlertCount.value += 1
                }
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
}

/**
 * Unified MYRA v2.0 ScreenTools facade
 * Provides direct access to ScreenReaderService, ScreenshotHelper, MediaProjection, and Maps.
 */
object ScreenTools {
    fun takeScreenshot(
        activity: Activity,
        analyzeImmediately: Boolean = true,
        customPrompt: String? = null
    ): CapturedScreenshot? = ScreenshotHelper.takeScreenshot(activity, analyzeImmediately, customPrompt)

    fun saveBitmapToLocalStorage(
        context: Context,
        bitmap: Bitmap,
        prefix: String = "sanam_screenshot"
    ): File = ScreenshotHelper.saveBitmapToLocalStorage(context, bitmap, prefix)

    fun createMediaProjectionIntent(context: Context): Intent? =
        ScreenshotHelper.createMediaProjectionIntent(context)

    fun startMediaProjectionCaptureService(
        context: Context,
        resultCode: Int,
        resultData: Intent,
        analyzeImmediately: Boolean = true,
        customPrompt: String? = null
    ) = ScreenshotHelper.startMediaProjectionCaptureService(
        context,
        resultCode,
        resultData,
        analyzeImmediately,
        customPrompt
    )

    fun requestFrameFromActiveProjection(context: Context, customPrompt: String? = null) =
        ScreenshotHelper.requestFrameFromActiveProjection(context, customPrompt)

    fun stopMediaProjectionService(context: Context) =
        ScreenshotHelper.stopMediaProjectionService(context)

    fun openMaps(context: Context, place: String): String =
        SocialAgent.openMaps(context, place)

    fun openAccessibilitySettings(context: Context) =
        ScreenReaderService.openAccessibilitySettings(context)

    fun getLiveScreenText(): List<String> =
        Memory.liveScreenStream.value
}

