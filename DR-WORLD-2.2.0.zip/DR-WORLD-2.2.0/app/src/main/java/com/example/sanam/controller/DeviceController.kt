package com.example.sanam.controller

import android.content.Context
import com.example.SocialAgent
import com.example.SystemTelemetry

/**
 * DeviceController (Sanam-ai JARVIS v1.0)
 * Central hardware & device action controller for calls, WhatsApp messages, SMS,
 * app launching, flashlight torch, volume adjustment, and battery/system telemetry.
 */
object DeviceController {

    fun callContact(context: Context, contact: String, hasCallPermission: Boolean): String =
        CallHelper.placeCall(context, contact, hasCallPermission)

    fun sendWhatsAppMessage(context: Context, contact: String, message: String): String =
        SocialAgent.sendWhatsAppText(context, CallHelper.resolvePhone(contact), message)

    fun sendTextSms(
        context: Context,
        contact: String,
        message: String,
        hasSmsPermission: Boolean
    ): String = SmsHelper.sendSms(context, contact, message, hasSmsPermission)

    fun launchApplication(context: Context, appName: String): String =
        AppLauncher.launch(context, appName)

    fun toggleFlashlight(context: Context, enable: Boolean): Boolean =
        SocialAgent.toggleFlashlight(context, enable)

    fun adjustVolume(context: Context, increase: Boolean): Int =
        SocialAgent.adjustVolume(context, increase)

    fun getDeviceTelemetry(context: Context, isFlashlightOn: Boolean): SystemTelemetry =
        SocialAgent.getSystemTelemetry(context, isFlashlightOn)
}
