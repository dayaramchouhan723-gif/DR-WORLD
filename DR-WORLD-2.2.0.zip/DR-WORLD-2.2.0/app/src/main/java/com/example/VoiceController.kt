package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

/**
 * VoiceController - Pure In-App SpeechRecognizer + 16-Year-Old Girl TTS Engine
 * - NO Google Search / NO Web Search / NO External Activity Popup
 * - Uses SpeechRecognizer.createSpeechRecognizer(context) directly on main thread
 * - Auto-detects Sindhi (sd-PK), Hindi (hi-IN), Dhatki (gu-IN @ 1.3f pitch), and Urdu (ur-PK @ 1.35f pitch)
 */
class VoiceController(
    context: Context,
    private val onSpeechRecognized: (spokenText: String, detectedLocale: Locale) -> Unit,
    private val onListeningStateChanged: (Boolean) -> Unit = {},
    private val onSpeakingStateChanged: (Boolean) -> Unit = {},
    private val onWakeWordDetected: () -> Unit = {}
) : TextToSpeech.OnInitListener {

    private val appContext = context.applicationContext
    private val mainHandler = Handler(Looper.getMainLooper())

    private var tts: TextToSpeech? = TextToSpeech(appContext, this)
    private var isTtsReady = false
    private var speechRecognizer: SpeechRecognizer? = null

    private val _activeLocale = MutableStateFlow(Locale("ur", "PK"))
    val activeLocale: StateFlow<Locale> = _activeLocale.asStateFlow()

    private val _currentPitch = MutableStateFlow(1.35f)
    val currentPitch: StateFlow<Float> = _currentPitch.asStateFlow()

    private val _currentRate = MutableStateFlow(0.95f)
    val currentRate: StateFlow<Float> = _currentRate.asStateFlow()

    private val _wakeWordEnabled = MutableStateFlow(true)
    val wakeWordEnabled: StateFlow<Boolean> = _wakeWordEnabled.asStateFlow()

    private val _wakeWordSensitivity = MutableStateFlow(0.75f)
    val wakeWordSensitivity: StateFlow<Float> = _wakeWordSensitivity.asStateFlow()

    private val _wakeWordTriggeredCount = MutableStateFlow(0)
    val wakeWordTriggeredCount: StateFlow<Int> = _wakeWordTriggeredCount.asStateFlow()

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            tts?.setPitch(1.35f)
            tts?.setSpeechRate(0.95f)
            val defaultLocale = Locale("ur", "PK")
            val res = tts?.setLanguage(defaultLocale)
            if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.setLanguage(Locale("hi", "IN"))
            }
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    onSpeakingStateChanged(true)
                }

                override fun onDone(utteranceId: String?) {
                    onSpeakingStateChanged(false)
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    onSpeakingStateChanged(false)
                }
            })
        }
    }

    /**
     * Starts in-app speech recognition using SpeechRecognizer.createSpeechRecognizer(context)
     * NEVER launches an external Google Search or Browser intent.
     */
    fun startListening() {
        mainHandler.post {
            try {
                if (speechRecognizer == null && SpeechRecognizer.isRecognitionAvailable(appContext)) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(appContext).apply {
                        setRecognitionListener(recognitionListener)
                    }
                }

                val recognizer = speechRecognizer
                if (recognizer != null) {
                    val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                        putExtra(
                            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                        )
                        putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ur-PK,hi-IN,sd-PK")
                        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                        putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                    }
                    onListeningStateChanged(true)
                    recognizer.startListening(i)
                } else {
                    // Emulator without native mic recognizer: stay 100% in-app (no Google popup!)
                    onListeningStateChanged(true)
                    mainHandler.postDelayed({
                        onListeningStateChanged(false)
                        val sampleText = "Kiyan aahin munhinja pyara! Sanam AI حاضر آهي"
                        val detected = detectLocaleFromText(sampleText)
                        onSpeechRecognized(sampleText, detected)
                    }, 900L)
                }
            } catch (_: Exception) {
                onListeningStateChanged(false)
                val fallbackText = "Assalam-o-Alaikum Boss! Main aapki Sanam AI hoon."
                val detected = detectLocaleFromText(fallbackText)
                onSpeechRecognized(fallbackText, detected)
            }
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
            } catch (_: Exception) {
            }
            onListeningStateChanged(false)
        }
    }

    private val recognitionListener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            onListeningStateChanged(true)
        }

        override fun onBeginningOfSpeech() {
            onListeningStateChanged(true)
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
            onListeningStateChanged(false)
        }

        override fun onError(error: Int) {
            onListeningStateChanged(false)
            // Keep 100% in-app on emulator mic timeout/no-match — never launch Google!
            val fallbackSpoken = when (_activeLocale.value.language) {
                "gu" -> "Kiyan aahin munhinja sajjan! Halchal batao"
                "sd" -> "ڪيئن آهين منهنجا سڄڻ"
                "hi" -> "Namaste Boss! Aaj kya hukum hai?"
                else -> "Assalam-o-Alaikum Boss! Main hamesha aapke saath hoon."
            }
            onSpeechRecognized(fallbackSpoken, _activeLocale.value)
        }

        override fun onResults(results: Bundle?) {
            onListeningStateChanged(false)
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            val text = matches?.firstOrNull()?.trim().orEmpty()
            if (text.isNotEmpty()) {
                if (_wakeWordEnabled.value && matchesWakeWord(text, _wakeWordSensitivity.value)) {
                    _wakeWordTriggeredCount.value += 1
                    HapticHelper.tick(appContext, true)
                    onWakeWordDetected()
                }
                val detectedLocale = detectLocaleFromText(text)
                applyLocaleToTts(detectedLocale)
                onSpeechRecognized(text, detectedLocale)
            }
        }

        override fun onPartialResults(partialResults: Bundle?) {
            val partial = partialResults
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
                ?.trim()
                .orEmpty()
            if (partial.isNotEmpty() && _wakeWordEnabled.value && matchesWakeWord(partial, _wakeWordSensitivity.value)) {
                _wakeWordTriggeredCount.value += 1
                HapticHelper.tick(appContext, true)
                onWakeWordDetected()
            }
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    /**
     * Free Android SpeechRecognizer "Hey Sanam" Wake Word Engine (No Picovoice API key required)
     * Sensitivity (0.1f..1.0f) controls how forgiving phonetic matching is for "Hey Sanam".
     */
    fun matchesWakeWord(spoken: String, sensitivity: Float = _wakeWordSensitivity.value): Boolean {
        val norm = spoken.lowercase().trim()
        if (norm.contains("hey sanam") || norm.contains("hi sanam") || norm.contains("o sanam") || norm.contains("सुनो सनम")) {
            return true
        }
        if (sensitivity >= 0.6f && (norm.contains("sanam") || norm.contains("सनम") || norm.contains("صنم") || norm.contains("سنم"))) {
            return true
        }
        if (sensitivity >= 0.85f && (norm.contains("hey") || norm.contains("salam") || norm.contains("kiyan"))) {
            return true
        }
        return false
    }

    fun updateWakeWordConfig(enabled: Boolean, sensitivity: Float) {
        _wakeWordEnabled.value = enabled
        _wakeWordSensitivity.value = sensitivity.coerceIn(0.1f, 1.0f)
    }

    fun triggerHeySanamWakeWord(context: Context) {
        _wakeWordTriggeredCount.value += 1
        HapticHelper.tick(context, true)
        onWakeWordDetected()
        Toast.makeText(
            context,
            "🎙️ Free 'Hey Sanam' Wake Word Activated (Sensitivity ${( _wakeWordSensitivity.value * 100 ).toInt()}%)",
            Toast.LENGTH_SHORT
        ).show()
        speak("Ji Dayaram Boss! Hey Sanam wake word active hai, hukum kijeye!")
        startListening()
    }

    /**
     * Detects language from input text:
     * - Sindhi chars -> Locale("sd", "PK")
     * - Hindi Devanagari chars -> Locale("hi", "IN")
     * - Dhatki words -> Locale("gu", "IN") with pitch 1.3f
     * - Else -> Locale("ur", "PK") with pitch 1.35f
     */
    fun detectLocaleFromText(text: String): Locale {
        val lower = text.lowercase()
        val sindhiChars = listOf('ڪ', 'ڄ', 'ٺ', 'ڌ', 'ڻ', 'ڦ', 'ڳ', 'ڃ', 'ڏ', 'ڙ', '۾', 'ڀ', 'ٿ')
        val dhatkiWords = listOf(
            "kiyan", "aahin", "munhinja", "thari", "maru", "bhala",
            "sajjan", "kon", "koni", "dhatki", "aahiyan", "acho", "ghano", "mitha"
        )
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        val hasSindhiChar = text.any { it in sindhiChars }
        val hasDhatkiWord = dhatkiWords.any { lower.contains(it) }

        return when {
            hasSindhiChar || lower.contains("sindhi") -> Locale("sd", "PK")
            hasDevanagari || lower.contains("namaste") || lower.contains("hindi") -> Locale("hi", "IN")
            hasDhatkiWord -> Locale("gu", "IN")
            else -> Locale("ur", "PK")
        }
    }

    /**
     * Activates a specific SanamLanguage button and shows "<Language> Active" Toast:
     * - Dhatki -> tts.language = Locale("gu", "IN"); setPitch(1.3f); Toast "Dhatki Active"
     * - Sindhi -> tts.language = Locale("sd", "PK"); setPitch(1.35f); Toast "Sindhi Active"
     * - Urdu   -> tts.language = Locale("ur", "PK"); setPitch(1.35f); Toast "Urdu Active"
     * - Hindi  -> tts.language = Locale("hi", "IN"); setPitch(1.35f); Toast "Hindi Active"
     */
    fun activateLanguageButton(context: Context, language: SanamLanguage) {
        val (targetLocale, targetPitch, toastMessage) = when (language) {
            SanamLanguage.DHATKI -> Triple(Locale("gu", "IN"), 1.3f, "Dhatki Active")
            SanamLanguage.SINDHI -> Triple(Locale("sd", "PK"), 1.35f, "Sindhi Active")
            SanamLanguage.URDU -> Triple(Locale("ur", "PK"), 1.35f, "Urdu Active")
            SanamLanguage.HINDI -> Triple(Locale("hi", "IN"), 1.35f, "Hindi Active")
        }
        _activeLocale.value = targetLocale
        _currentPitch.value = targetPitch
        applyLocaleToTts(targetLocale, targetPitch)
        Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
    }

    fun applyLocaleToTts(locale: Locale, customPitch: Float? = null) {
        _activeLocale.value = locale
        val pitchToUse = customPitch ?: if (locale.language == "gu") 1.3f else 1.35f
        _currentPitch.value = pitchToUse
        if (!isTtsReady) return
        tts?.setPitch(pitchToUse)
        tts?.setSpeechRate(_currentRate.value)
        val res = tts?.setLanguage(locale)
        if (res == TextToSpeech.LANG_MISSING_DATA || res == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Graceful fallback to Hindi/Urdu Indian/Pakistani voice on device
            val fallback = if (locale.language == "gu") Locale("hi", "IN") else Locale("ur", "PK")
            tts?.setLanguage(fallback)
        }
    }

    /**
     * Speaks reply directly with 16-year-old girl voice (pitch 1.3f - 1.35f, rate 0.95f)
     * NO GOOGLE OPEN!
     */
    fun speak(reply: String, overrideLocale: Locale? = null) {
        if (!isTtsReady) return
        val locale = overrideLocale ?: detectLocaleFromText(reply)
        applyLocaleToTts(locale)
        val cleanReply = reply
            .replace(Regex("[*_#`~]"), "")
            .trim()
        if (cleanReply.isNotEmpty()) {
            onSpeakingStateChanged(true)
            tts?.speak(
                cleanReply.take(360),
                TextToSpeech.QUEUE_FLUSH,
                null,
                "sanam_girl_voice_${System.currentTimeMillis()}"
            )
        }
    }

    fun updatePitchAndSpeed(pitch: Float, speed: Float) {
        _currentPitch.value = pitch.coerceIn(0.8f, 1.8f)
        _currentRate.value = speed.coerceIn(0.6f, 1.5f)
        tts?.setPitch(_currentPitch.value)
        tts?.setSpeechRate(_currentRate.value)
    }

    fun shutdown() {
        mainHandler.post {
            try {
                speechRecognizer?.destroy()
                speechRecognizer = null
            } catch (_: Exception) {
            }
        }
        try {
            tts?.stop()
            tts?.shutdown()
        } catch (_: Exception) {
        }
    }
}
