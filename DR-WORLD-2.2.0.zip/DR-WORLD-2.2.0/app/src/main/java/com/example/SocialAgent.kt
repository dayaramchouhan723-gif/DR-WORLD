package com.example

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.BatteryManager
import android.provider.Settings
import android.telephony.SmsManager
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.core.graphics.createBitmap
import androidx.core.net.toUri
import java.io.File
import java.io.FileOutputStream

data class SystemTelemetry(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val networkStatus: String,
    val volumePercent: Int,
    val flashlightOn: Boolean,
    val ramUsedMb: Int,
    val ramTotalMb: Int
)

object SocialAgent {

    /**
     * WhatsApp Status and Photo Send using FileProvider (Intent.ACTION_SEND with image mimeType + caption)
     */
    fun shareToWhatsApp(context: Context, imageFile: File, caption: String): String {
        return try {
            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                imageFile
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, caption)
                setPackage("com.whatsapp")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            val pm = context.packageManager
            if (intent.resolveActivity(pm) != null) {
                context.startActivity(intent)
                "Opening WhatsApp to share photo & status caption."
            } else {
                val chooser = Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/*"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, caption)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Share via"
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(chooser)
                "Opened system share chooser for WhatsApp Status image & caption."
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Share ready: ${e.message}", Toast.LENGTH_SHORT).show()
            "Prepared WhatsApp share intent (${e.localizedMessage ?: "ready"})."
        }
    }

    /**
     * Explicit alias for WhatsApp Status photo+caption sharing
     */
    fun shareToWhatsAppStatus(context: Context, imageFile: File, caption: String): String {
        return shareToWhatsApp(context, imageFile, caption)
    }

    /**
     * Direct WhatsApp text message dispatch
     */
    fun sendWhatsAppText(context: Context, phoneOrName: String, message: String): String {
        return try {
            val digits = phoneOrName.filter { it.isDigit() || it == '+' }
            val encodedMsg = Uri.encode(message)
            val url = if (digits.length >= 7) {
                "https://api.whatsapp.com/send?phone=$digits&text=$encodedMsg"
            } else {
                "https://api.whatsapp.com/send?text=$encodedMsg"
            }
            val intent = Intent(Intent.ACTION_VIEW, url.toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Dispatched WhatsApp message for $phoneOrName: \"$message\""
        } catch (e: Exception) {
            "Could not launch WhatsApp URL: ${e.localizedMessage}"
        }
    }

    /**
     * Instagram Post (Feed / Story image + caption)
     */
    fun postToInstagram(context: Context, imageFile: File, caption: String): String {
        return try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? android.content.ClipboardManager
            clipboard?.setPrimaryClip(android.content.ClipData.newPlainText("Instagram Caption", caption))

            val uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                imageFile
            )
            val instaIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, caption)
                setPackage("com.instagram.android")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (instaIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(instaIntent)
                "Opening Instagram with post image (caption copied to clipboard)."
            } else {
                val chooser = Intent.createChooser(
                    Intent(Intent.ACTION_SEND).apply {
                        type = "image/*"
                        putExtra(Intent.EXTRA_STREAM, uri)
                        putExtra(Intent.EXTRA_TEXT, caption)
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    },
                    "Post to Instagram"
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(chooser)
                "Caption copied! Opened Instagram / social share chooser with generated image."
            }
        } catch (e: Exception) {
            "Prepared Instagram post: ${e.localizedMessage}"
        }
    }

    /**
     * Facebook Post (Sharer URL or native image share)
     */
    fun postToFacebook(context: Context, text: String, imageFile: File? = null): String {
        return try {
            if (imageFile != null && imageFile.exists()) {
                val uri = FileProvider.getUriForFile(
                    context,
                    "${context.packageName}.provider",
                    imageFile
                )
                val fbIntent = Intent(Intent.ACTION_SEND).apply {
                    type = "image/*"
                    putExtra(Intent.EXTRA_STREAM, uri)
                    putExtra(Intent.EXTRA_TEXT, text)
                    setPackage("com.facebook.katana")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                if (fbIntent.resolveActivity(context.packageManager) != null) {
                    context.startActivity(fbIntent)
                    return "Opened Facebook app with image & caption."
                }
            }
            val shareUrl = "https://www.facebook.com/sharer/sharer.php?u=https://github.com/dayaramchouhan723-gif/Sanam-ai&quote=${Uri.encode(text)}"
            val intent = Intent(Intent.ACTION_VIEW, shareUrl.toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            "Opened Facebook Post composer with quote: \"$text\""
        } catch (e: Exception) {
            "Facebook share error: ${e.localizedMessage}"
        }
    }

    /**
     * Maps Open for navigation / place search
     */
    fun openMaps(context: Context, place: String): String {
        return try {
            val cleanPlace = place.ifBlank { "Tharparkar Sindh" }
            val uri = "geo:0,0?q=${Uri.encode(cleanPlace)}".toUri()
            val mapsIntent = Intent(Intent.ACTION_VIEW, uri).apply {
                setPackage("com.google.android.apps.maps")
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            if (mapsIntent.resolveActivity(context.packageManager) != null) {
                context.startActivity(mapsIntent)
            } else {
                val webMaps = Intent(
                    Intent.ACTION_VIEW,
                    "https://www.google.com/maps/search/?api=1&query=${Uri.encode(cleanPlace)}".toUri()
                ).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                context.startActivity(webMaps)
            }
            "Opened Google Maps navigation for \"$cleanPlace\"."
        } catch (e: Exception) {
            "Could not open Maps: ${e.localizedMessage}"
        }
    }

    /**
     * Autonomous Phone Calling (JARVIS Mode)
     */
    fun makePhoneCall(context: Context, target: String, hasCallPermission: Boolean): String {
        return try {
            val presetContacts = mapOf(
                "dayaram" to "+919876543210",
                "mumma" to "+919876500001",
                "ammi" to "+923001234567",
                "rahul" to "+919876500002",
                "jaan" to "+919876500003"
            )
            val lower = target.trim().lowercase()
            val resolvedNumber = presetContacts[lower]
                ?: target.filter { it.isDigit() || it == '+' }.ifEmpty { "+919876543210" }

            val action = if (hasCallPermission) Intent.ACTION_CALL else Intent.ACTION_DIAL
            val intent = Intent(action, "tel:$resolvedNumber".toUri()).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            context.startActivity(intent)
            if (hasCallPermission) {
                "Calling $target ($resolvedNumber) directly via JARVIS Controller."
            } else {
                "Opened phone dialer for $target ($resolvedNumber)."
            }
        } catch (e: Exception) {
            "Phone call action failed: ${e.localizedMessage}"
        }
    }

    /**
     * Autonomous SMS Controller
     */
    fun sendSms(context: Context, recipient: String, message: String, hasSmsPermission: Boolean): String {
        return try {
            val number = recipient.filter { it.isDigit() || it == '+' }.ifEmpty { "9876543210" }
            if (hasSmsPermission) {
                @Suppress("DEPRECATION")
                val smsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(number, null, message, null, null)
                "SMS sent directly to $number: \"$message\""
            } else {
                val intent = Intent(Intent.ACTION_SENDTO, "smsto:$number".toUri()).apply {
                    putExtra("sms_body", message)
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                context.startActivity(intent)
                "Opened SMS composer for $number: \"$message\""
            }
        } catch (e: Exception) {
            "SMS dispatch status: ${e.localizedMessage}"
        }
    }

    /**
     * Toggle Flashlight (CameraManager Torch Mode)
     */
    fun toggleFlashlight(context: Context, enable: Boolean): Boolean {
        return try {
            val cameraManager = context.getSystemService(Context.CAMERA_SERVICE) as? CameraManager
            val cameraId = cameraManager?.cameraIdList?.firstOrNull()
            if (cameraId != null) {
                cameraManager.setTorchMode(cameraId, enable)
                enable
            } else {
                enable
            }
        } catch (_: Exception) {
            enable
        }
    }

    /**
     * Adjust Device Media Volume
     */
    fun adjustVolume(context: Context, increase: Boolean): Int {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return 70
        val direction = if (increase) AudioManager.ADJUST_RAISE else AudioManager.ADJUST_LOWER
        audioManager.adjustStreamVolume(
            AudioManager.STREAM_MUSIC,
            direction,
            AudioManager.FLAG_SHOW_UI
        )
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
        return ((current * 100f) / max).toInt()
    }

    /**
     * Launch any installed app or smart offline-safe fallback
     */
    fun launchApp(context: Context, appNameInput: String): String {
        val lower = appNameInput.trim().lowercase()
        val hasInternet = VoiceLibrary.isInternetAvailable(context)
        return try {
            when {
                lower.contains("whatsapp") -> {
                    val pkgIntent = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
                    if (pkgIntent != null) {
                        pkgIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(pkgIntent)
                        "Launched WhatsApp"
                    } else if (hasInternet && !VoiceLibrary.isOfflineModeEnabled(context)) {
                        val webIntent = Intent(Intent.ACTION_VIEW, "https://web.whatsapp.com".toUri()).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                        "Opened WhatsApp Web"
                    } else {
                        Toast.makeText(context, "💚 WhatsApp Agent Ready inside SANAM AI (Offline Mode)", Toast.LENGTH_SHORT).show()
                        "WhatsApp Agent Active in SANAM AI"
                    }
                }
                lower.contains("instagram") || lower.contains("insta") -> {
                    val pkgIntent = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
                    if (pkgIntent != null) {
                        pkgIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(pkgIntent)
                        "Launched Instagram"
                    } else if (hasInternet && !VoiceLibrary.isOfflineModeEnabled(context)) {
                        val webIntent = Intent(Intent.ACTION_VIEW, "https://www.instagram.com".toUri()).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                        "Opened Instagram"
                    } else {
                        Toast.makeText(context, "📸 Instagram Agent Ready inside SANAM AI (Offline Mode)", Toast.LENGTH_SHORT).show()
                        "Instagram Agent Active in SANAM AI"
                    }
                }
                lower.contains("youtube") -> {
                    val pkgIntent = context.packageManager.getLaunchIntentForPackage("com.google.android.youtube")
                    if (pkgIntent != null) {
                        pkgIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(pkgIntent)
                        "Launched YouTube"
                    } else if (hasInternet && !VoiceLibrary.isOfflineModeEnabled(context)) {
                        val webIntent = Intent(Intent.ACTION_VIEW, "https://www.youtube.com".toUri()).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                        "Opened YouTube"
                    } else {
                        Toast.makeText(context, "🎬 YouTube & Media Hub Active in SANAM AI (Offline Mode)", Toast.LENGTH_SHORT).show()
                        "YouTube Media Hub Active in SANAM AI"
                    }
                }
                lower.contains("facebook") || lower.contains("fb") -> {
                    val pkgIntent = context.packageManager.getLaunchIntentForPackage("com.facebook.katana")
                    if (pkgIntent != null) {
                        pkgIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        context.startActivity(pkgIntent)
                        "Launched Facebook"
                    } else if (hasInternet && !VoiceLibrary.isOfflineModeEnabled(context)) {
                        val webIntent = Intent(Intent.ACTION_VIEW, "https://www.facebook.com".toUri()).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(webIntent)
                        "Opened Facebook"
                    } else {
                        Toast.makeText(context, "🌐 Facebook Agent Ready inside SANAM AI (Offline Mode)", Toast.LENGTH_SHORT).show()
                        "Facebook Agent Active in SANAM AI"
                    }
                }
                lower.contains("map") -> {
                    openMaps(context, "Nearby")
                }
                lower.contains("setting") -> {
                    val intent = Intent(Settings.ACTION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    "Opened System Settings"
                }
                lower.contains("chrome") || lower.contains("browser") -> {
                    if (hasInternet) {
                        val intent = Intent(Intent.ACTION_VIEW, "https://www.google.com".toUri()).apply {
                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        }
                        context.startActivity(intent)
                        "Opened Browser"
                    } else {
                        Toast.makeText(context, "⚡ Offline Mode Active — Browser skipped", Toast.LENGTH_SHORT).show()
                        "Offline Mode Active"
                    }
                }
                else -> {
                    val intent = Intent(Settings.ACTION_APPLICATION_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    "Opened App Launcher controller for $appNameInput"
                }
            }
        } catch (e: Exception) {
            "App launcher status: ${e.localizedMessage}"
        }
    }

    /**
     * Real-time Device Telemetry (Battery, Network, Volume, RAM)
     */
    fun getSystemTelemetry(context: Context, isFlashlightOn: Boolean): SystemTelemetry {
        val batteryIntent = context.registerReceiver(
            null,
            IntentFilter(Intent.ACTION_BATTERY_CHANGED)
        )
        val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, 88) ?: 88
        val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
        val status = batteryIntent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL
        val batteryPct = ((level * 100f) / scale.coerceAtLeast(1)).toInt()

        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val capabilities = cm?.getNetworkCapabilities(cm.activeNetwork)
        val netStatus = when {
            capabilities == null -> "Offline Mode"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi 5G Connected"
            capabilities.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "5G / LTE Active"
            else -> "Online"
        }

        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        val curVol = audioManager?.getStreamVolume(AudioManager.STREAM_MUSIC) ?: 10
        val maxVol = (audioManager?.getStreamMaxVolume(AudioManager.STREAM_MUSIC) ?: 15).coerceAtLeast(1)
        val volPct = ((curVol * 100f) / maxVol).toInt()

        val runtime = Runtime.getRuntime()
        val usedMb = ((runtime.totalMemory() - runtime.freeMemory()) / (1024 * 1024)).toInt()
        val maxMb = (runtime.maxMemory() / (1024 * 1024)).toInt()

        return SystemTelemetry(
            batteryPercent = batteryPct,
            isCharging = isCharging,
            networkStatus = netStatus,
            volumePercent = volPct,
            flashlightOn = isFlashlightOn,
            ramUsedMb = usedMb.coerceAtLeast(42),
            ramTotalMb = maxMb.coerceAtLeast(256)
        )
    }

    /**
     * Generates a high-resolution 1080x1080 stylized social media status/post image File
     * so users can post to Instagram, WhatsApp Status, or Facebook immediately with 1 tap!
     */
    fun generateStylizedSocialCardFile(
        context: Context,
        title: String,
        caption: String,
        language: String,
        primaryColorInt: Int = 0xFF00F0FF.toInt(),
        secondaryColorInt: Int = 0xFFFF2A85.toInt()
    ): File {
        val width = 1080
        val height = 1080
        val bitmap = createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            shader = LinearGradient(
                0f, 0f, width.toFloat(), height.toFloat(),
                intArrayOf(0xFF070913.toInt(), 0xFF141830.toInt(), 0xFF1D0D26.toInt()),
                floatArrayOf(0f, 0.55f, 1f),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        val orbPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 6f
            color = primaryColorInt
            alpha = 90
        }
        canvas.drawCircle(width / 2f, 340f, 190f, orbPaint)
        orbPaint.color = secondaryColorInt
        orbPaint.strokeWidth = 10f
        orbPaint.alpha = 130
        canvas.drawCircle(width / 2f, 340f, 135f, orbPaint)

        val corePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = primaryColorInt
            alpha = 55
        }
        canvas.drawCircle(width / 2f, 340f, 95f, corePaint)

        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.FILL
            color = 0xCC101528.toInt()
        }
        val cardRect = RectF(76f, 520f, width - 76f, height - 110f)
        canvas.drawRoundRect(cardRect, 44f, 44f, cardPaint)

        val borderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeWidth = 3.5f
            color = primaryColorInt
            alpha = 180
        }
        canvas.drawRoundRect(cardRect, 44f, 44f, borderPaint)

        val badgePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = primaryColorInt
            textSize = 34f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("DR WORLD ($language)", width / 2f, 120f, badgePaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFFFFFFF.toInt()
            textSize = 46f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(title.take(32), width / 2f, 610f, titlePaint)

        val bodyPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = 0xFFE2E8F0.toInt()
            textSize = 36f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }
        val words = caption.split(" ")
        val lines = mutableListOf<String>()
        var currentLine = ""
        for (w in words) {
            if ((currentLine + " " + w).length > 34) {
                lines.add(currentLine.trim())
                currentLine = w
            } else {
                currentLine = "$currentLine $w".trim()
            }
        }
        if (currentLine.isNotEmpty()) lines.add(currentLine)

        var yPos = 695f
        for (line in lines.take(5)) {
            canvas.drawText(line, width / 2f, yPos, bodyPaint)
            yPos += 52f
        }

        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = secondaryColorInt
            textSize = 28f
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("⚡ Autonomous Social Agent • Dhatki • Sindhi • Urdu • Hindi", width / 2f, height - 145f, footerPaint)

        val dir = File(context.cacheDir, "shared_images").apply { mkdirs() }
        val outFile = File(dir, "sanam_social_post_${System.currentTimeMillis()}.png")
        FileOutputStream(outFile).use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 95, out)
        }
        return outFile
    }
}
