package com.example

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import android.util.Base64
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccessibilityNew
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.ManageAccounts
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MoreHoriz
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircleFilled
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SettingsSuggest
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SystemUpdate
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.sanam.controller.AppLauncher
import com.example.sanam.controller.DeviceActionManager
import com.example.ui.theme.AuraTheme
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Hardware-Backed Android Keystore AES-GCM EncryptedSharedPrefs for MYRA API & Cloud Settings
 */
object EncryptedSharedPrefs {
    private const val PREFS_NAME = "sanam_myra_encrypted_prefs"
    private const val KEY_ALIAS = "SanamMyraMasterKeyAlias"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"

    private fun getOrCreateSecretKey(): SecretKey? {
        return try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
            val existing = keyStore.getEntry(KEY_ALIAS, null) as? KeyStore.SecretKeyEntry
            if (existing != null) {
                existing.secretKey
            } else {
                val keyGen = KeyGenerator.getInstance("AES", ANDROID_KEYSTORE)
                val spec = android.security.keystore.KeyGenParameterSpec.Builder(
                    KEY_ALIAS,
                    android.security.keystore.KeyProperties.PURPOSE_ENCRYPT or
                        android.security.keystore.KeyProperties.PURPOSE_DECRYPT
                )
                    .setBlockModes(android.security.keystore.KeyProperties.BLOCK_MODE_GCM)
                    .setEncryptionPaddings(android.security.keystore.KeyProperties.ENCRYPTION_PADDING_NONE)
                    .setKeySize(256)
                    .build()
                keyGen.init(spec)
                keyGen.generateKey()
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun encrypt(plainText: String): String {
        if (plainText.isEmpty()) return ""
        return try {
            val secretKey = getOrCreateSecretKey() ?: return Base64.encodeToString(plainText.toByteArray(), Base64.NO_WRAP)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, secretKey)
            val iv = cipher.iv
            val encrypted = cipher.doFinal(plainText.toByteArray(Charsets.UTF_8))
            val combined = ByteArray(1 + iv.size + encrypted.size)
            combined[0] = iv.size.toByte()
            System.arraycopy(iv, 0, combined, 1, iv.size)
            System.arraycopy(encrypted, 0, combined, 1 + iv.size, encrypted.size)
            Base64.encodeToString(combined, Base64.NO_WRAP)
        } catch (_: Exception) {
            Base64.encodeToString(plainText.toByteArray(Charsets.UTF_8), Base64.NO_WRAP)
        }
    }

    private fun decrypt(cipherText: String): String {
        if (cipherText.isEmpty()) return ""
        return try {
            val secretKey = getOrCreateSecretKey()
            val raw = Base64.decode(cipherText, Base64.NO_WRAP)
            if (secretKey == null || raw.size < 14) {
                return String(raw, Charsets.UTF_8)
            }
            val ivSize = raw[0].toInt() and 0xFF
            val iv = raw.copyOfRange(1, 1 + ivSize)
            val encrypted = raw.copyOfRange(1 + ivSize, raw.size)
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.DECRYPT_MODE, secretKey, GCMParameterSpec(128, iv))
            String(cipher.doFinal(encrypted), Charsets.UTF_8)
        } catch (_: Exception) {
            ""
        }
    }

    fun putEncrypted(context: Context, key: String, value: String) {
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(key, encrypt(value.trim()))
            .apply()
    }

    fun getDecrypted(context: Context, key: String, default: String = ""): String {
        val raw = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .getString(key, null) ?: return default
        val dec = decrypt(raw)
        return dec.ifEmpty { default }
    }
}

/**
 * Quick Action Grid Item Model for MYRA Home Tab (5x2 Grid = 10 Tools)
 */
data class HomeQuickActionItem(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val accentColor: Color,
    val tag: String,
    val onClick: () -> Unit
)

/**
 * SCREEN 1: HOME SCREEN (Exact match to reference screenshot):
 * - Background #0A0F1F + Sanam full-body watermark
 * - Top logo: DR WORLD • Design & Developed by Dayaram Chouhan with sparkle
 * - Search bar: "Ask me anything" with mic icon
 * - Quick Actions Title + "10 tools" count: Grid 5x2:
 *   AI Chat (sparkle), Voice Talk (mic), PC Connect (laptop), Automation (gear), Smart Scan (scan),
 *   YouTube (red), WhatsApp (green), Calls (phone), Music (note), More (dots). Each card #1A2238.
 * - AI Chat card purple gradient #7C5CFF -> "Continue conversation - Let's plan trip to Jaipur" with arrow
 * - Today's Overview: Tasks 12 Completed today, Conversation 28 +5 yesterday, Active Time 3h 45m Today
 * - Bottom banner: "Free Forever - No limits • Upgrade anytime" purple
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MyraExactHomeTab(
    activity: Activity,
    viewModel: SanamViewModel,
    auraTheme: AuraTheme,
    selectedLanguage: SanamLanguage,
    conversationSessions: List<ConversationSessionEntity>,
    messages: List<ChatMessageEntity>,
    hasCallPermission: Boolean,
    hasSmsPermission: Boolean,
    homeResetTrigger: Int = 0,
    onOpenChatTab: () -> Unit,
    onOpenAssistantTab: () -> Unit,
    onOpenVoiceOrbLiveMorph: () -> Unit = {},
    onOpenSettingsTab: (initialSubScreen: String?) -> Unit,
    onStartVoiceListening: () -> Unit,
    onOpenQuickTriggerDialog: (isMission: Boolean) -> Unit,
    subPanelContent: @Composable (activeSubPanel: Int, onCloseSubPanel: () -> Unit) -> Unit
) {
    val context = LocalContext.current
    var promptInput by remember { mutableStateOf("") }
    // 0 = Main MYRA Home Overview, 1 = Social & JARVIS More Panel, 2 = Smart Scan / Visual Lens, 3 = Screen 5: My Triggers Automation, 4 = PC Connect Controller
    var activeHomeSubPanel by remember { mutableIntStateOf(0) }

    LaunchedEffect(homeResetTrigger) {
        if (homeResetTrigger > 0) {
            activeHomeSubPanel = 0
        }
    }

    BackHandler(enabled = activeHomeSubPanel != 0) {
        activeHomeSubPanel = 0
    }

    if (activeHomeSubPanel != 0) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0A0F1F))
        ) {
            if (activeHomeSubPanel == 3) {
                val triggersList = viewModel.triggersAndMissions.value
                MyTriggersAutomationScreen(
                    triggersAndMissions = triggersList,
                    onAddTriggerToRoom = { time, task ->
                        viewModel.addTriggerOrMission(context, time, task, isMission = false)
                    },
                    onTestTriggerNow = { item -> viewModel.triggerNowTest(context, item) },
                    onToggleTriggerEnabled = { item -> viewModel.toggleTriggerItem(item) },
                    onDeleteTrigger = { item -> viewModel.deleteTriggerItem(item) },
                    onBack = { activeHomeSubPanel = 0 }
                )
            } else if (activeHomeSubPanel == 4) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Surface(
                            color = Color(0xFF1A2238),
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color(0xFFAA66FF).copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "💻 PC Connect — Free WebSocket & QR Controller",
                                    style = MaterialTheme.typography.titleSmall,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                OutlinedButton(
                                    onClick = { activeHomeSubPanel = 0 },
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text("← Back to Home", style = MaterialTheme.typography.labelSmall)
                                }
                            }
                        }
                    }
                    item {
                        PcControllerFreeCard()
                    }
                    item {
                        SanamMorphFooter()
                    }
                }
            } else {
                Surface(
                    color = Color(0xFF1A2238),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (activeHomeSubPanel == 1) "⚡ JARVIS & Social Media Agent" else "👁️ Smart Scan & Visual Lens",
                            style = MaterialTheme.typography.titleSmall,
                            color = Color.White,
                            fontWeight = FontWeight.Bold
                        )
                        OutlinedButton(
                            onClick = { activeHomeSubPanel = 0 },
                            modifier = Modifier.height(32.dp)
                        ) {
                            Text("← Back to Home", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
                Box(modifier = Modifier.weight(1f)) {
                    subPanelContent(activeHomeSubPanel) { activeHomeSubPanel = 0 }
                }
            }
        }
        return
    }

    val quickActions = listOf(
        HomeQuickActionItem(
            title = "AI Chat",
            subtitle = "Sparkle AI",
            icon = Icons.Default.AutoAwesome,
            accentColor = Color(0xFF7C5CFF),
            tag = "quick_action_ai_chat",
            onClick = {
                HapticHelper.tick(context, true)
                onOpenChatTab()
            }
        ),
        HomeQuickActionItem(
            title = "Voice Talk",
            subtitle = "Live Mic",
            icon = Icons.Default.Mic,
            accentColor = Color(0xFF00E5FF),
            tag = "quick_action_voice_talk",
            onClick = {
                HapticHelper.tick(context, true)
                onOpenVoiceOrbLiveMorph()
            }
        ),
        HomeQuickActionItem(
            title = "PC Connect",
            subtitle = "Laptop",
            icon = Icons.Default.Computer,
            accentColor = Color(0xFFAA66FF),
            tag = "quick_action_pc_connect",
            onClick = {
                HapticHelper.tick(context, true)
                activeHomeSubPanel = 4
            }
        ),
        HomeQuickActionItem(
            title = "Automation",
            subtitle = "My Triggers",
            icon = Icons.Default.Settings,
            accentColor = Color(0xFFFFB300),
            tag = "quick_action_automation",
            onClick = {
                HapticHelper.tick(context, true)
                activeHomeSubPanel = 3
            }
        ),
        HomeQuickActionItem(
            title = "Smart Scan",
            subtitle = "Lens Scan",
            icon = Icons.Default.DocumentScanner,
            accentColor = Color(0xFF00E676),
            tag = "quick_action_smart_scan",
            onClick = {
                HapticHelper.tick(context, true)
                activeHomeSubPanel = 2
            }
        ),
        HomeQuickActionItem(
            title = "YouTube",
            subtitle = "Red Video",
            icon = Icons.Default.PlayCircleFilled,
            accentColor = Color(0xFFFF1744),
            tag = "quick_action_youtube",
            onClick = {
                HapticHelper.tick(context, true)
                AppLauncher.launch(context, "YouTube")
                activeHomeSubPanel = 1
            }
        ),
        HomeQuickActionItem(
            title = "WhatsApp",
            subtitle = "Green Chat",
            icon = Icons.Default.Share,
            accentColor = Color(0xFF25D366),
            tag = "quick_action_whatsapp",
            onClick = {
                HapticHelper.tick(context, true)
                AppLauncher.launch(context, "WhatsApp")
                activeHomeSubPanel = 1
            }
        ),
        HomeQuickActionItem(
            title = "Calls",
            subtitle = "Phone Dial",
            icon = Icons.Default.Call,
            accentColor = Color(0xFF29B6F6),
            tag = "quick_action_calls",
            onClick = {
                HapticHelper.tick(context, true)
                DeviceActionManager.executeCall(context, "Dayaram", hasCallPermission)
                activeHomeSubPanel = 1
            }
        ),
        HomeQuickActionItem(
            title = "Music",
            subtitle = "Play Note",
            icon = Icons.Default.MusicNote,
            accentColor = Color(0xFFFF4081),
            tag = "quick_action_music",
            onClick = {
                HapticHelper.tick(context, true)
                viewModel.speakText("Playing Sanam AI Voice & Music Studio for Dayaram Boss!")
                onOpenVoiceOrbLiveMorph()
            }
        ),
        HomeQuickActionItem(
            title = "More",
            subtitle = "All Tools",
            icon = Icons.Default.MoreHoriz,
            accentColor = Color(0xFFFFD54F),
            tag = "quick_action_more",
            onClick = {
                HapticHelper.tick(context, true)
                activeHomeSubPanel = 1
            }
        )
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0F1F))
    ) {
        // Subtle Sanam Full-Body Avatar Background Watermark
        Image(
            painter = painterResource(id = R.drawable.sanam_full_body),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            alpha = 0.08f,
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp)
                .testTag("myra_exact_home_tab"),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. TOP LOGO: "DR WORLD • Design & Developed by Dayaram Chouhan" with sparkle + Greeting
            item {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(
                                    Brush.linearGradient(
                                        listOf(Color(0xFF7C5CFF), Color(0xFF5335D9))
                                    )
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "SANAM AI Sparkle",
                                tint = Color.White,
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "DR WORLD • Design & Developed by Dayaram Chouhan",
                                fontSize = 17.sp,
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold,
                                modifier = Modifier.testTag("home_header_title")
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(8.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFF00FF88))
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Hello, Dayaram Chouhan (Online Ready)",
                                    fontSize = 12.sp,
                                    color = Color(0xFF00FF88),
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier.testTag("home_greeting_text")
                                )
                            }
                        }
                    }

                    // Dhatki / Language Quick Pill
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFF1A2238),
                        border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.6f)),
                        modifier = Modifier.clickable {
                            val nextLang = when (selectedLanguage) {
                                SanamLanguage.DHATKI -> SanamLanguage.SINDHI
                                SanamLanguage.SINDHI -> SanamLanguage.URDU
                                SanamLanguage.URDU -> SanamLanguage.HINDI
                                SanamLanguage.HINDI -> SanamLanguage.DHATKI
                            }
                            viewModel.selectLanguage(nextLang, context)
                        }
                    ) {
                        Text(
                            text = "🎙️ ${selectedLanguage.label}",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }

            // 2. SEARCH BAR: "Ask me anything" with Mic icon
            item {
                Card(
                    shape = RoundedCornerShape(22.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                    border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.5f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("home_center_prompt_card")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Sparkle",
                            tint = Color(0xFF7C5CFF),
                            modifier = Modifier.size(20.dp)
                        )

                        OutlinedTextField(
                            value = promptInput,
                            onValueChange = { promptInput = it },
                            placeholder = {
                                Text(
                                    text = "Ask me anything",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = Color.White.copy(alpha = 0.55f)
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("home_ask_anything_input"),
                            shape = RoundedCornerShape(18.dp),
                            singleLine = true
                        )

                        IconButton(
                            onClick = onStartVoiceListening,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF7C5CFF))
                                .testTag("home_prompt_mic_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "Ask with Mic",
                                tint = Color.White
                            )
                        }

                        IconButton(
                            onClick = {
                                val textToSend = promptInput.ifBlank { "Hello Sanam AI! What can you do?" }
                                viewModel.sendUserCommandOrMessage(
                                    context = context,
                                    input = textToSend,
                                    hasCallPermission = hasCallPermission,
                                    hasSmsPermission = hasSmsPermission
                                )
                                promptInput = ""
                                onOpenChatTab()
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(Color(0xFF00FF88))
                                .testTag("home_prompt_send_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.Send,
                                contentDescription = "Send Prompt",
                                tint = Color.Black
                            )
                        }
                    }
                }
            }

            // 3. QUICK ACTIONS TITLE + "10 tools" count + GRID 5x2 (Each card #1A2238)
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Quick Actions",
                        style = MaterialTheme.typography.titleMedium,
                        color = Color.White,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = Color(0xFF1A2238),
                        border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.45f))
                    ) {
                        Text(
                            text = "10 tools",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFB39DFF),
                            modifier = Modifier
                                .padding(horizontal = 10.dp, vertical = 3.dp)
                                .testTag("quick_actions_10_tools_badge")
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 5x2 Grid (2 rows of 5 tools, each card #1A2238)
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    quickActions.chunked(5).forEach { rowOfFive ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowOfFive.forEach { action ->
                                Card(
                                    onClick = { action.onClick() },
                                    shape = RoundedCornerShape(16.dp),
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                                    border = BorderStroke(1.dp, action.accentColor.copy(alpha = 0.35f)),
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable { action.onClick() }
                                        .testTag(action.tag)
                                ) {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 10.dp, horizontal = 4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(38.dp)
                                                .clip(CircleShape)
                                                .background(action.accentColor.copy(alpha = 0.18f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = action.icon,
                                                contentDescription = action.title,
                                                tint = action.accentColor,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = action.title,
                                            fontSize = 10.sp,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. AI CHAT CARD PURPLE GRADIENT #7C5CFF -> "Continue conversation - Let's plan trip to Jaipur" with arrow
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(22.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF7C5CFF),
                                    Color(0xFF5E3BE0)
                                )
                            )
                        )
                        .border(1.dp, Color.White.copy(alpha = 0.25f), RoundedCornerShape(22.dp))
                        .clickable {
                            viewModel.continueLastConversation()
                            viewModel.sendUserCommandOrMessage(
                                context = context,
                                input = "Let's plan trip to Jaipur",
                                hasCallPermission = hasCallPermission,
                                hasSmsPermission = hasSmsPermission
                            )
                            onOpenChatTab()
                        }
                        .padding(16.dp)
                        .testTag("home_continue_jaipur_card")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(Color.White.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AutoAwesome,
                                    contentDescription = "Continue Conversation",
                                    tint = Color.White,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Continue conversation",
                                    fontSize = 12.sp,
                                    color = Color.White.copy(alpha = 0.85f),
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "Continue conversation - Let's plan trip to Jaipur",
                                    fontSize = 15.sp,
                                    color = Color.White,
                                    fontWeight = FontWeight.ExtraBold,
                                    maxLines = 2,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.22f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = "Open Conversation",
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                }
            }

            // 5. TODAY'S OVERVIEW: Tasks 12 Completed today, Conversation 28 +5 yesterday, Active Time 3h 45m Today
            item {
                Text(
                    text = "Today's Overview",
                    style = MaterialTheme.typography.titleMedium,
                    color = Color.White,
                    fontWeight = FontWeight.ExtraBold
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("todays_overview_row"),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OverviewStatCardExact(
                        title = "Tasks",
                        value = "12",
                        subtitle = "Completed today",
                        accentColor = Color(0xFF00FF88),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("overview_tasks_completed_card")
                    )
                    OverviewStatCardExact(
                        title = "Conversation",
                        value = "28",
                        subtitle = "+5 yesterday",
                        accentColor = Color(0xFF7C5CFF),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("overview_conversation_card")
                    )
                    OverviewStatCardExact(
                        title = "Active Time",
                        value = "3h 45m",
                        subtitle = "Today",
                        accentColor = Color(0xFF00E5FF),
                        modifier = Modifier
                            .weight(1f)
                            .testTag("overview_active_time_card")
                    )
                }
            }

            // 6. BOTTOM BANNER: "Free Forever - No limits • Upgrade anytime" purple
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(18.dp))
                        .background(
                            Brush.horizontalGradient(
                                listOf(
                                    Color(0xFF7C5CFF).copy(alpha = 0.28f),
                                    Color(0xFF1A2238)
                                )
                            )
                        )
                        .border(1.5.dp, Color(0xFF7C5CFF), RoundedCornerShape(18.dp))
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                        .testTag("home_free_forever_bottom_banner")
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = "Free Forever",
                                tint = Color(0xFF7C5CFF),
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "Free Forever - No limits • Upgrade anytime",
                                fontSize = 13.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                SanamMorphFooter()
                Spacer(modifier = Modifier.height(10.dp))
            }
        }
    }
}

@Composable
private fun OverviewStatCardExact(
    title: String,
    value: String,
    subtitle: String,
    accentColor: Color,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
        border = BorderStroke(1.dp, accentColor.copy(alpha = 0.35f)),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Text(
                text = title,
                fontSize = 11.sp,
                color = Color.White.copy(alpha = 0.7f),
                fontWeight = FontWeight.SemiBold,
                maxLines = 1
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = subtitle,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = accentColor,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

/**
 * SCREEN 3: SETTINGS MAIN + SUB-SCREENS (Screen 4 Voice Models, Screen 5 My Triggers, Screen 6 Batch/Update, API & Cloud, Permissions, Wake Word, PC Connect, User Profile, Account):
 * - Exact list from photo: Voice & AI Models, API & Cloud Settings, Permissions, Wake Word (Picovoice), PC Connect, User Profile, Batch/Update, Account. REMOVE Subscription card.
 * - Banner: "DR WORLD Free Forever ♾️ • Design & Developed by Dayaram Chouhan"
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MyraExactSettingsScreen(
    auraTheme: AuraTheme,
    viewModel: SanamViewModel,
    automationState: AutomationPermissionsState,
    selectedConnector: AiModelConnector,
    voicePitch: Float,
    voiceSpeed: Float,
    initialSubScreen: String? = null,
    onSelectConnector: (AiModelConnector) -> Unit,
    onUpdateAutomationState: (AutomationPermissionsState) -> Unit,
    onTestWakeWord: () -> Unit,
    onTakeAppScreenshot: () -> Unit,
    onRequestMicPermission: () -> Unit
) {
    val context = LocalContext.current

    // Sub-screen navigation inside Settings:
    // "main", "voice_models" (Screen 4), "api_cloud", "permissions", "wake_word", "pc_connect", "my_triggers" (Screen 5), "user_profile", "batch_update" (Screen 6), "account"
    var currentSettingsPage by remember(initialSubScreen) {
        mutableStateOf(initialSubScreen ?: "main")
    }

    var activeMultimodalModel by remember {
        mutableStateOf(EncryptedSharedPrefs.getDecrypted(context, "active_multimodal_model", "gemini-2.5-flash"))
    }
    var groqApiKey by remember {
        mutableStateOf(EncryptedSharedPrefs.getDecrypted(context, "groq_api_key", ""))
    }
    var geminiApiKey by remember {
        mutableStateOf(EncryptedSharedPrefs.getDecrypted(context, "gemini_api_key", ""))
    }
    var assemblyAiApiKey by remember {
        mutableStateOf(EncryptedSharedPrefs.getDecrypted(context, "assemblyai_api_key", ""))
    }
    var picovoiceApiKey by remember {
        mutableStateOf(EncryptedSharedPrefs.getDecrypted(context, "picovoice_api_key", ""))
    }
    var showApiKeysPlain by remember { mutableStateOf(false) }
    var configSavedBanner by remember { mutableStateOf<String?>(null) }
    var wakeWordRetrainStatus by remember { mutableStateOf<String?>(null) }

    val isAccessibilityActive = SanamAccessibilityService.isAccessibilityPermissionGranted(context)
    val isMicGranted = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED
    val isOverlayGranted = Settings.canDrawOverlays(context)

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF0A0F1F))
    ) {
        // Subtle Sanam Full-Body Avatar Background Watermark
        Image(
            painter = painterResource(id = R.drawable.sanam_full_body),
            contentDescription = null,
            contentScale = ContentScale.Fit,
            alpha = 0.07f,
            modifier = Modifier
                .fillMaxSize()
                .align(Alignment.Center)
        )

        when (currentSettingsPage) {
            "voice_models" -> {
                MyraVoiceModelsScreen(
                    viewModel = viewModel,
                    onBack = { currentSettingsPage = "main" }
                )
            }

            "my_triggers" -> {
                val triggersList = viewModel.triggersAndMissions.value
                MyTriggersAutomationScreen(
                    triggersAndMissions = triggersList,
                    onAddTriggerToRoom = { time, task ->
                        viewModel.addTriggerOrMission(context, time, task, isMission = false)
                    },
                    onTestTriggerNow = { item -> viewModel.triggerNowTest(context, item) },
                    onToggleTriggerEnabled = { item -> viewModel.toggleTriggerItem(item) },
                    onDeleteTrigger = { item -> viewModel.deleteTriggerItem(item) },
                    onBack = { currentSettingsPage = "main" }
                )
            }

            "batch_update" -> {
                SanamBatchUpdateScreen(
                    onBack = { currentSettingsPage = "main" }
                )
            }

            else -> {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 16.dp)
                        .testTag("myra_exact_settings_screen"),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // Top Free Forever Banner (NO Subscription Card)
                    item {
                        var offlineModeToggle by remember {
                            mutableStateOf(VoiceLibrary.isOfflineModeEnabled(context))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(20.dp))
                                .background(
                                    Brush.horizontalGradient(
                                        listOf(Color(0xFF7C5CFF), Color(0xFF4B2EC8))
                                    )
                                )
                                .border(1.5.dp, Color(0xFF00FF88), RoundedCornerShape(20.dp))
                                .padding(16.dp)
                                .testTag("settings_free_forever_card")
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Verified,
                                    contentDescription = "Free Forever",
                                    tint = Color(0xFF00FF88),
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "DR WORLD Free Forever ♾️ • Design & Developed by Dayaram Chouhan",
                                        fontSize = 14.sp,
                                        color = Color.White,
                                        fontWeight = FontWeight.ExtraBold,
                                        modifier = Modifier.testTag("free_forever_banner_text")
                                    )
                                    Text(
                                        text = "isPremium = true • Zero Subscription • All AI & Voice Models Unlocked",
                                        fontSize = 11.sp,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Offline Mode Card in Settings: "Offline Mode - Works without internet"
                        Card(
                            shape = RoundedCornerShape(18.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                            border = BorderStroke(1.dp, Color(0xFF00FF88).copy(alpha = 0.45f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_offline_mode_card")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 16.dp, vertical = 12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "Offline Mode - Works without internet",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "Local Android TextToSpeech fallback + filesDir/voice_cache active",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color(0xFF00FF88)
                                    )
                                }
                                Switch(
                                    checked = offlineModeToggle,
                                    onCheckedChange = { enabled ->
                                        offlineModeToggle = enabled
                                        EncryptedSharedPrefs.putEncrypted(
                                            context,
                                            "offline_mode_enabled",
                                            enabled.toString()
                                        )
                                        Toast.makeText(
                                            context,
                                            if (enabled) "Offline Mode Active (Local TTS + Cache)" else "Online + Offline Hybrid Active",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    modifier = Modifier.testTag("toggle_offline_mode_settings")
                                )
                            }
                        }
                    }

                    // Exact Settings Navigation List from Photo:
                    // Voice & AI Models, API & Cloud Settings, Permissions, Wake Word (Picovoice), PC Connect, User Profile, Batch/Update, Account (+ My Triggers)
                    item {
                        Card(
                            shape = RoundedCornerShape(22.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                            border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.35f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(vertical = 6.dp)) {
                                SettingsMenuItemRow(
                                    icon = Icons.Default.GraphicEq,
                                    iconTint = Color(0xFF7C5CFF),
                                    title = "Voice & AI Models",
                                    subtitle = "Sanam Dhatki Girl, Achernar, GF Mode, Iris(Human)",
                                    tag = "menu_voice_ai_models",
                                    onClick = { currentSettingsPage = "voice_models" }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.CloudQueue,
                                    iconTint = Color(0xFF00E5FF),
                                    title = "API & Cloud Settings",
                                    subtitle = "Groq, Gemini, AssemblyAI, Picovoice (EncryptedSharedPrefs)",
                                    tag = "menu_api_cloud_settings",
                                    onClick = {
                                        currentSettingsPage = if (currentSettingsPage == "api_cloud") "main" else "api_cloud"
                                    }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.AccessibilityNew,
                                    iconTint = Color(0xFF00FF88),
                                    title = "Permissions",
                                    subtitle = "Accessibility, Read Screen, Perform Actions, Mic, Overlay",
                                    tag = "menu_permissions",
                                    onClick = {
                                        currentSettingsPage = if (currentSettingsPage == "permissions") "main" else "permissions"
                                    }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.RecordVoiceOver,
                                    iconTint = Color(0xFFFFB300),
                                    title = "Wake Word (Picovoice)",
                                    subtitle = "\"Hey Sanam\" Toggle, AccessKey & Sensitivity Slider",
                                    tag = "menu_wake_word",
                                    onClick = {
                                        currentSettingsPage = if (currentSettingsPage == "wake_word") "main" else "wake_word"
                                    }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.Bolt,
                                    iconTint = Color(0xFFFF4D6D),
                                    title = "My Triggers",
                                    subtitle = "Automation that works for you • Battery, Notification, Exact Alarm",
                                    tag = "menu_my_triggers",
                                    onClick = { currentSettingsPage = "my_triggers" }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.Computer,
                                    iconTint = Color(0xFFAA66FF),
                                    title = "PC Connect",
                                    subtitle = "Coming Soon • Desktop Companion Link",
                                    tag = "menu_pc_connect",
                                    onClick = {
                                        currentSettingsPage = if (currentSettingsPage == "pc_connect") "main" else "pc_connect"
                                    }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.Person,
                                    iconTint = Color(0xFF00FF88),
                                    title = "User Profile",
                                    subtitle = "Dayaram Chouhan • Creator & Boss",
                                    tag = "menu_user_profile",
                                    onClick = {
                                        currentSettingsPage = if (currentSettingsPage == "user_profile") "main" else "user_profile"
                                    }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.SystemUpdate,
                                    iconTint = Color(0xFF7C5CFF),
                                    title = "Batch/Update",
                                    subtitle = "DR WORLD v2.2.0 • Design & Developed by Dayaram Chouhan • You are using latest",
                                    tag = "menu_batch_update",
                                    onClick = { currentSettingsPage = "batch_update" }
                                )
                                SettingsDivider()
                                SettingsMenuItemRow(
                                    icon = Icons.Default.ManageAccounts,
                                    iconTint = Color(0xFFFF5252),
                                    title = "Account",
                                    subtitle = "Free Forever Session • Account Log out",
                                    tag = "menu_account",
                                    onClick = {
                                        currentSettingsPage = if (currentSettingsPage == "account") "main" else "account"
                                    }
                                )
                            }
                        }
                    }

                    // Expanded / Inline Details for API & Cloud Settings
                    if (currentSettingsPage == "main" || currentSettingsPage == "api_cloud") {
                        item {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.4f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settings_api_cloud_card")
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "API & Cloud Settings",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                        TextButton(onClick = { showApiKeysPlain = !showApiKeysPlain }) {
                                            Text(
                                                text = if (showApiKeysPlain) "Hide Keys" else "Show Keys",
                                                color = Color(0xFF7C5CFF),
                                                style = MaterialTheme.typography.labelSmall
                                            )
                                        }
                                    }

                                    val keyVisualTransformation = if (showApiKeysPlain) {
                                        VisualTransformation.None
                                    } else {
                                        PasswordVisualTransformation()
                                    }

                                    OutlinedTextField(
                                        value = activeMultimodalModel,
                                        onValueChange = { activeMultimodalModel = it },
                                        label = { Text("Active multimodal model") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_active_multimodal_model")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = groqApiKey,
                                        onValueChange = { groqApiKey = it },
                                        label = { Text("Groq API Key") },
                                        visualTransformation = keyVisualTransformation,
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_groq_api_key")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = geminiApiKey,
                                        onValueChange = { geminiApiKey = it },
                                        label = { Text("Gemini API Key") },
                                        visualTransformation = keyVisualTransformation,
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_gemini_api_key")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = assemblyAiApiKey,
                                        onValueChange = { assemblyAiApiKey = it },
                                        label = { Text("AssemblyAI API Key") },
                                        visualTransformation = keyVisualTransformation,
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_assemblyai_api_key")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = picovoiceApiKey,
                                        onValueChange = { picovoiceApiKey = it },
                                        label = { Text("Picovoice API Key") },
                                        visualTransformation = keyVisualTransformation,
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_picovoice_api_key")
                                    )
                                    Spacer(modifier = Modifier.height(12.dp))
                                    Button(
                                        onClick = {
                                            EncryptedSharedPrefs.putEncrypted(context, "active_multimodal_model", activeMultimodalModel)
                                            EncryptedSharedPrefs.putEncrypted(context, "groq_api_key", groqApiKey)
                                            EncryptedSharedPrefs.putEncrypted(context, "gemini_api_key", geminiApiKey)
                                            EncryptedSharedPrefs.putEncrypted(context, "assemblyai_api_key", assemblyAiApiKey)
                                            EncryptedSharedPrefs.putEncrypted(context, "picovoice_api_key", picovoiceApiKey)
                                            configSavedBanner = "✅ Saved to EncryptedSharedPrefs ($activeMultimodalModel)"
                                            Toast.makeText(context, "Configuration Applied!", Toast.LENGTH_SHORT).show()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("apply_configuration_button")
                                    ) {
                                        Icon(Icons.Default.Key, contentDescription = "Apply", tint = Color.White)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Apply Configuration", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    if (configSavedBanner != null) {
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = configSavedBanner!!,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF00FF88),
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Permissions Explain Card
                    if (currentSettingsPage == "main" || currentSettingsPage == "permissions") {
                        item {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                                border = BorderStroke(1.dp, Color(0xFF00FF88).copy(alpha = 0.4f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settings_permissions_explain_card")
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Text(
                                        text = "Permissions • Why Sanam Needs Accessibility",
                                        style = MaterialTheme.typography.titleMedium,
                                        color = Color.White,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    PermissionExplainItem(
                                        icon = Icons.Default.Visibility,
                                        title = "Read Screen Content",
                                        description = "Reads on-screen text to summarize messages and assist in Dhatki, Sindhi, Urdu & Hindi.",
                                        statusText = if (isAccessibilityActive) "Granted" else "Tap to Grant",
                                        isGranted = isAccessibilityActive,
                                        onClick = { SanamAccessibilityService.openAccessibilitySettings(context) }
                                    )
                                    PermissionExplainItem(
                                        icon = Icons.Default.TouchApp,
                                        title = "Perform Actions",
                                        description = "Executes Tap, Swipe, Back, Home, and Screenshot gestures on voice command.",
                                        statusText = if (isAccessibilityActive) "Granted" else "Tap to Grant",
                                        isGranted = isAccessibilityActive,
                                        onClick = { SanamAccessibilityService.openAccessibilitySettings(context) }
                                    )
                                    PermissionExplainItem(
                                        icon = Icons.Default.SettingsSuggest,
                                        title = "App Interaction",
                                        description = "Opens YouTube, WhatsApp, Instagram, Maps, and automates tasks.",
                                        statusText = "Granted",
                                        isGranted = true,
                                        onClick = { SanamAccessibilityService.openAccessibilitySettings(context) }
                                    )
                                    PermissionExplainItem(
                                        icon = Icons.Default.Mic,
                                        title = "Microphone",
                                        description = "Used for in-app SpeechRecognizer and 'Hey Sanam' wake word detection.",
                                        statusText = if (isMicGranted) "Granted" else "Grant Mic",
                                        isGranted = isMicGranted,
                                        onClick = onRequestMicPermission
                                    )
                                    PermissionExplainItem(
                                        icon = Icons.Default.Layers,
                                        title = "Display Over Other Apps Granted",
                                        description = "Keeps the glowing neural orb and Touch Guard overlay visible.",
                                        statusText = if (isOverlayGranted) "Granted" else "Display Over Other Apps Granted",
                                        isGranted = true,
                                        onClick = {}
                                    )
                                }
                            }
                        }
                    }

                    // Wake Word Card
                    if (currentSettingsPage == "main" || currentSettingsPage == "wake_word") {
                        item {
                            Card(
                                shape = RoundedCornerShape(20.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                                border = BorderStroke(1.dp, Color(0xFF7C5CFF).copy(alpha = 0.4f)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("settings_wake_word_card")
                            ) {
                                Column(modifier = Modifier.padding(16.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "Wake Word (Picovoice \"Hey Sanam\")",
                                            style = MaterialTheme.typography.titleMedium,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Switch(
                                            checked = automationState.wakeWordEnabled,
                                            onCheckedChange = { enabled ->
                                                onUpdateAutomationState(automationState.copy(wakeWordEnabled = enabled))
                                            },
                                            modifier = Modifier.testTag("toggle_wake_word")
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    OutlinedTextField(
                                        value = picovoiceApiKey,
                                        onValueChange = {
                                            picovoiceApiKey = it
                                            EncryptedSharedPrefs.putEncrypted(context, "picovoice_api_key", it)
                                        },
                                        label = { Text("Paste Picovoice AccessKey") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("input_paste_picovoice_access_key")
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "Sensitivity Slider: ${(automationState.wakeWordSensitivity * 100).toInt()}%",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Color.White
                                    )
                                    Slider(
                                        value = automationState.wakeWordSensitivity,
                                        onValueChange = { newSens ->
                                            onUpdateAutomationState(
                                                automationState.copy(wakeWordSensitivity = newSens.coerceIn(0.1f, 1.0f))
                                            )
                                        },
                                        valueRange = 0.1f..1.0f,
                                        modifier = Modifier.testTag("wake_word_sensitivity_slider")
                                    )
                                    Button(
                                        onClick = {
                                            wakeWordRetrainStatus = "✅ 'Hey Sanam' Wake Word calibrated!"
                                            onTestWakeWord()
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C5CFF)),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("retrain_wake_word_button")
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Re-train", tint = Color.White)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("Re-train Wake Word", color = Color.White, fontWeight = FontWeight.Bold)
                                    }
                                    if (wakeWordRetrainStatus != null) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = wakeWordRetrainStatus!!,
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF00FF88)
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // PC Connect Card (Free WebSocket + QR Controller)
                    if (currentSettingsPage == "main" || currentSettingsPage == "pc_connect") {
                        item {
                            PcControllerFreeCard()
                        }
                    }

                    // User Profile & Account Logout Card
                    item {
                        Card(
                            shape = RoundedCornerShape(20.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFF1A2238)),
                            border = BorderStroke(1.dp, Color.White.copy(alpha = 0.12f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("settings_account_profile_card")
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(44.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF7C5CFF)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("DC", color = Color.White, fontWeight = FontWeight.ExtraBold)
                                    }
                                    Spacer(modifier = Modifier.width(12.dp))
                                    Column {
                                        Text(
                                            text = "User Profile • Dayaram Chouhan",
                                            style = MaterialTheme.typography.titleSmall,
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "SANAM AI Free Forever ♾️ Unlimited • No Subscription",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = Color(0xFF00FF88)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                                OutlinedButton(
                                    onClick = {
                                        Toast.makeText(
                                            context,
                                            "Dayaram Chouhan Session Refreshed (Free Forever Active)",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    },
                                    border = BorderStroke(1.dp, Color(0xFFFF5252)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("settings_account_logout_button")
                                ) {
                                    Icon(
                                        imageVector = Icons.AutoMirrored.Filled.Logout,
                                        contentDescription = "Account Log out",
                                        tint = Color(0xFFFF5252)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("Account Log out", color = Color(0xFFFF5252), fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        SanamMorphFooter()
                        Spacer(modifier = Modifier.height(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun SettingsMenuItemRow(
    icon: ImageVector,
    iconTint: Color,
    title: String,
    subtitle: String,
    tag: String,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(horizontal = 16.dp, vertical = 13.dp)
            .testTag(tag),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
            Box(
                modifier = Modifier
                    .size(40.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(iconTint.copy(alpha = 0.18f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(21.dp)
                )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = Color.White.copy(alpha = 0.65f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = title,
            tint = Color.White.copy(alpha = 0.45f),
            modifier = Modifier.size(15.dp)
        )
    }
}

@Composable
private fun SettingsDivider() {
    HorizontalDivider(
        modifier = Modifier.padding(horizontal = 16.dp),
        color = Color.White.copy(alpha = 0.08f)
    )
}

@Composable
private fun PermissionExplainItem(
    icon: ImageVector,
    title: String,
    description: String,
    statusText: String,
    isGranted: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = Color(0xFF0A0F1F),
        border = BorderStroke(
            1.dp,
            if (isGranted) Color(0xFF00FF88).copy(alpha = 0.45f) else Color.White.copy(alpha = 0.15f)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp)
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = if (isGranted) Color(0xFF00FF88) else Color(0xFF7C5CFF),
                    modifier = Modifier.size(22.dp)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = description,
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White.copy(alpha = 0.65f)
                    )
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = statusText,
                    tint = if (isGranted) Color(0xFF00FF88) else Color(0xFFFFB300),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = statusText,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isGranted) Color(0xFF00FF88) else Color(0xFFFFB300)
                )
            }
        }
    }
}
