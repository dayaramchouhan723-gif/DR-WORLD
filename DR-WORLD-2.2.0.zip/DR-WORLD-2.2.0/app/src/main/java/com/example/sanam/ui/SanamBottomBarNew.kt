package com.example.sanam.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.LiveMorphState
import com.example.R

/**
 * STEP 3 - SanamBottomBarNew.kt with 5 items:
 * 1) Home (house)
 * 2) Chat (bubble)
 * 3) CENTER ORB 72.dp purple gradient #7C3AED to #A855F7 showing small preview of current mode
 *    character inside (clip circle 40.dp), elevated -14.dp, shadow 20.dp purple,
 *    breathing scale 0.96-1.1 infinite, onClick -> VoiceOrbLiveMorph
 * 4) Assistant (stars)
 * 5) Settings (gear)
 * Selected #8B5CF6. Bg #0E1424 rounded top 24.dp 88.dp height.
 */
@Composable
fun SanamBottomBarNew(
    currentTab: Int,
    currentMorphModeIndex: Int = 0,
    onSelectTab: (Int) -> Unit,
    onOpenVoiceOrbLiveMorph: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "sanam_bottom_bar_new_orb")
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.96f,
        targetValue = 1.1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "center_orb_72_breathing"
    )

    val previewDrawable = LiveMorphState.modes
        .getOrElse(currentMorphModeIndex.coerceIn(0, LiveMorphState.modes.lastIndex)) {
            "GF Mode" to R.drawable.sanam_pink_bunny
        }.second

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .testTag("sanam_bottom_nav"),
        contentAlignment = Alignment.BottomCenter
    ) {
        Surface(
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = Color(0xFF0E1424),
            tonalElevation = 12.dp,
            shadowElevation = 16.dp,
            border = BorderStroke(
                1.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF7C3AED).copy(alpha = 0.55f),
                        Color(0xFFA855F7).copy(alpha = 0.75f),
                        Color(0xFF7C3AED).copy(alpha = 0.55f)
                    )
                )
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(88.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Home (house)
                SanamBottomBarItem(
                    label = "Home",
                    icon = Icons.Default.Home,
                    selected = currentTab == 1,
                    tag = "nav_tab_home",
                    onClick = { onSelectTab(1) }
                )

                // 2. Chat (bubble)
                SanamBottomBarItem(
                    label = "Chat",
                    icon = Icons.AutoMirrored.Filled.Chat,
                    selected = currentTab == 0,
                    tag = "nav_tab_chat",
                    onClick = { onSelectTab(0) }
                )

                // Space for 72.dp Center Orb
                Spacer(modifier = Modifier.width(80.dp))

                // 4. Assistant (stars)
                SanamBottomBarItem(
                    label = "Assistant",
                    icon = Icons.Default.AutoAwesome,
                    selected = currentTab == 2,
                    tag = "nav_tab_assistant",
                    onClick = { onSelectTab(2) }
                )

                // 5. Settings (gear)
                SanamBottomBarItem(
                    label = "Settings",
                    icon = Icons.Default.Settings,
                    selected = currentTab == 3,
                    tag = "nav_tab_settings",
                    onClick = { onSelectTab(3) }
                )
            }
        }

        // 3. CENTER ORB 72.dp purple gradient #7C3AED to #A855F7 with 40.dp character preview inside
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .offset(y = (-14).dp)
                .scale(breathingScale)
                .size(72.dp)
                .shadow(
                    elevation = 20.dp,
                    shape = CircleShape,
                    ambientColor = Color(0xFF8B5CF6),
                    spotColor = Color(0xFFA855F7)
                )
                .clip(CircleShape)
                .background(
                    Brush.linearGradient(
                        listOf(
                            Color(0xFF7C3AED),
                            Color(0xFFA855F7)
                        )
                    )
                )
                .border(
                    width = 2.5.dp,
                    color = if (currentTab == 4) Color(0xFF00FF88) else Color.White.copy(alpha = 0.9f),
                    shape = CircleShape
                )
                .clickable { onOpenVoiceOrbLiveMorph() }
                .testTag("center_notch_mic_button")
        ) {
            Image(
                painter = painterResource(id = previewDrawable),
                contentDescription = "Current Mode Character Preview",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .border(1.5.dp, Color.White.copy(alpha = 0.85f), CircleShape)
            )
        }
    }
}

@Composable
fun BottomBarNew(
    currentTab: Int,
    currentMorphModeIndex: Int = 0,
    onSelectTab: (Int) -> Unit,
    onOpenVoiceOrbLiveMorph: () -> Unit,
    modifier: Modifier = Modifier
) {
    SanamBottomBarNew(
        currentTab = currentTab,
        currentMorphModeIndex = currentMorphModeIndex,
        onSelectTab = onSelectTab,
        onOpenVoiceOrbLiveMorph = onOpenVoiceOrbLiveMorph,
        modifier = modifier
    )
}

@Composable
private fun SanamBottomBarItem(
    label: String,
    icon: ImageVector,
    selected: Boolean,
    tag: String,
    onClick: () -> Unit
) {
    val activeColor = Color(0xFF8B5CF6)
    val inactiveColor = Color.White.copy(alpha = 0.65f)

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag(tag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) activeColor else inactiveColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = label,
            fontSize = 11.sp,
            color = if (selected) activeColor else inactiveColor,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}
