package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

@Composable
fun SanamAiTheme(
    auraTheme: AuraTheme = AuraTheme.CYBER_ELECTRIC,
    content: @Composable () -> Unit
) {
    val colorScheme = darkColorScheme(
        primary = auraTheme.primary,
        onPrimary = Color(0xFF05070E),
        primaryContainer = auraTheme.surfaceVariant,
        onPrimaryContainer = Color(0xFFF3F6FF),
        secondary = auraTheme.secondary,
        onSecondary = Color(0xFF05070E),
        secondaryContainer = auraTheme.surfaceVariant,
        onSecondaryContainer = Color(0xFFFFEBF2),
        tertiary = auraTheme.tertiary,
        onTertiary = Color(0xFF05070E),
        background = auraTheme.background,
        onBackground = Color(0xFFF4F7FF),
        surface = auraTheme.surface,
        onSurface = Color(0xFFF4F7FF),
        surfaceVariant = auraTheme.surfaceVariant,
        onSurfaceVariant = Color(0xFFB8C4E0),
        outline = auraTheme.primary.copy(alpha = 0.35f)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    SanamAiTheme(auraTheme = AuraTheme.CYBER_ELECTRIC, content = content)
}
