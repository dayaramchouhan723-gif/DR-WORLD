package com.example.sanam.controller

import android.app.Activity
import android.content.Context
import com.example.MissionManager
import com.example.ScreenTools
import com.example.ScreenshotHelper
import com.example.SocialAgent
import com.example.SystemTelemetry
import com.example.TriggerMission
import java.io.File

data class AutonomousCommandResult(
    val executed: Boolean,
    val badge: String? = null,
    val summary: String? = null,
    val newFlashlightState: Boolean? = null,
    val scheduledTriggerMission: TriggerMission? = null
)

/**
 * Unified DeviceActionManager (Merges Sanam-ai JARVIS v1.0 + MYRA v2.0 SocialAgent, ScreenTools & MissionManager)
 * Parses and executes both device control commands (Calls, SMS, WhatsApp, Apps, Flashlight, Volume, Battery)
 * and MYRA Social Agent / Screen commands (Instagram Post, Facebook Post, WhatsApp Status, Screenshot, Maps, Triggers).
 */
object DeviceActionManager {

    fun executeCall(context: Context, contact: String, hasCallPermission: Boolean): String =
        DeviceController.callContact(context, contact, hasCallPermission)

    fun executeWhatsAppMessage(context: Context, contact: String, message: String): String =
        DeviceController.sendWhatsAppMessage(context, contact, message)

    fun executeWhatsAppStatusShare(context: Context, imageFile: File, caption: String): String =
        SocialAgent.shareToWhatsAppStatus(context, imageFile, caption)

    fun executeInstagramPost(context: Context, imageFile: File, caption: String): String =
        SocialAgent.postToInstagram(context, imageFile, caption)

    fun executeFacebookPost(context: Context, caption: String, imageFile: File? = null): String =
        SocialAgent.postToFacebook(context, caption, imageFile)

    fun executeSms(context: Context, contact: String, message: String, hasSmsPermission: Boolean): String =
        DeviceController.sendTextSms(context, contact, message, hasSmsPermission)

    fun executeOpenMaps(context: Context, locationQuery: String): String =
        ScreenTools.openMaps(context, locationQuery)

    fun executeLaunchApp(context: Context, appName: String): String =
        DeviceController.launchApplication(context, appName)

    fun executeFlashlight(context: Context, enable: Boolean): Boolean =
        DeviceController.toggleFlashlight(context, enable)

    fun executeVolumeChange(context: Context, increase: Boolean): Int =
        DeviceController.adjustVolume(context, increase)

    fun readTelemetry(context: Context, isFlashlightOn: Boolean): SystemTelemetry =
        DeviceController.getDeviceTelemetry(context, isFlashlightOn)

    fun scheduleVoiceTrigger(context: Context, time: String, task: String, isMission: Boolean) {
        MissionManager.addTrigger(context, time, task, isMission)
    }

    /**
     * Unified Intent & Command Router that handles JARVIS v1.0 Device Control + MYRA v2.0 Social Agent triggers.
     */
    fun parseAndExecuteUnifiedCommand(
        context: Context,
        rawInput: String,
        hasCallPermission: Boolean,
        hasSmsPermission: Boolean,
        currentFlashlightState: Boolean,
        imageFileProvider: (String) -> File
    ): AutonomousCommandResult {
        val trimmed = rawInput.trim()
        val lower = trimmed.lowercase()

        return when {
            // 1. MYRA Social Agent: WhatsApp Status / Photo Share
            lower.contains("whatsapp status") ||
                lower.contains("status lagao") ||
                lower.contains("status pe") ||
                lower.contains("share on whatsapp") ||
                lower.contains("whatsapp photo") -> {
                val caption = trimmed
                    .replace(Regex("(?i)(share on whatsapp status|whatsapp status|status lagao|share on whatsapp|whatsapp photo|:)"), "")
                    .trim()
                    .ifEmpty { "Sanam AI (Unified Edition) 💖 #SanamAI #DRWORLD #JARVIS" }
                val file = imageFileProvider(caption)
                val note = executeWhatsAppStatusShare(context, file, caption)
                AutonomousCommandResult(executed = true, badge = "💚 WhatsApp Status", summary = note)
            }

            // 2. MYRA Social Agent: Instagram Post
            lower.contains("instagram") ||
                lower.contains("insta post") ||
                lower.contains("post to insta") ||
                lower.contains("insta pe post") -> {
                val caption = trimmed
                    .replace(Regex("(?i)(post to instagram|post to insta|insta post|instagram|insta pe post|:)"), "")
                    .trim()
                    .ifEmpty { "Sanam AI • Unified JARVIS + DR WORLD Edition ✨ #SanamAI #Dhatki" }
                val file = imageFileProvider(caption)
                val note = executeInstagramPost(context, file, caption)
                AutonomousCommandResult(executed = true, badge = "📸 Instagram Post", summary = note)
            }

            // 3. MYRA Social Agent: Facebook Post
            lower.contains("facebook") ||
                lower.contains("post to fb") ||
                lower.contains("fb post") ||
                lower.contains("facebook pe post") -> {
                val caption = trimmed
                    .replace(Regex("(?i)(post to facebook|post to fb|fb post|facebook pe post|facebook|:)"), "")
                    .trim()
                    .ifEmpty { "Living the future with Sanam AI (JARVIS + DR WORLD Unified Edition)!" }
                val file = imageFileProvider(caption)
                val note = executeFacebookPost(context, caption, file)
                AutonomousCommandResult(executed = true, badge = "🌐 Facebook Post", summary = note)
            }

            // 4. MYRA ScreenTools: Screenshot Trigger
            lower.contains("screenshot") || lower.contains("screen capture") || lower.contains("screen padho") -> {
                val activity = context as? Activity
                val note = if (activity != null) {
                    val shot = ScreenshotHelper.takeScreenshot(activity, analyzeImmediately = true)
                    "Captured screenshot (${shot?.file?.name ?: "ready"}) & saved to local storage."
                } else {
                    "Screenshot capture triggered."
                }
                AutonomousCommandResult(executed = true, badge = "📸 Screenshot", summary = note)
            }

            // 5. JARVIS Direct Phone Call
            lower.startsWith("call ") ||
                lower.contains("ko call") ||
                lower.contains("phone laga") ||
                lower.startsWith("dial ") -> {
                val contact = trimmed
                    .replace(Regex("(?i)(call|dial|ko|phone|laga|lagao|karo)"), "")
                    .trim()
                    .ifEmpty { "Dayaram" }
                val note = executeCall(context, contact, hasCallPermission)
                AutonomousCommandResult(executed = true, badge = "📞 Direct Call", summary = note)
            }

            // 6. JARVIS WhatsApp Direct Chat Message
            lower.contains("whatsapp") -> {
                val msg = trimmed
                    .replace(Regex("(?i)(send|whatsapp|message|msg|to|bhejo|karo)"), "")
                    .trim()
                    .ifEmpty { "Salam from Sanam AI!" }
                val matchedContact = CallHelper.favoriteContacts.keys.firstOrNull { lower.contains(it) } ?: "Dayaram"
                val note = executeWhatsAppMessage(context, matchedContact, msg)
                AutonomousCommandResult(executed = true, badge = "💬 WhatsApp Msg", summary = note)
            }

            // 7. JARVIS Native SMS Controller
            lower.contains("sms") || lower.contains("text message") -> {
                val matchedContact = CallHelper.favoriteContacts.keys.firstOrNull { lower.contains(it) } ?: "Dayaram"
                val note = executeSms(context, matchedContact, trimmed, hasSmsPermission)
                AutonomousCommandResult(executed = true, badge = "✉️ SMS Controller", summary = note)
            }

            // 8. MYRA + JARVIS Google Maps Navigation
            lower.contains("map") || lower.contains("location") || lower.contains("navigate") -> {
                val place = trimmed
                    .replace(Regex("(?i)(open|maps|map|location|for|navigate|to|kholo)"), "")
                    .trim()
                    .ifEmpty { "Tharparkar Sindh" }
                val note = executeOpenMaps(context, place)
                AutonomousCommandResult(executed = true, badge = "🗺️ Google Maps", summary = note)
            }

            // 9. JARVIS Flashlight / Torch Hardware Control
            lower.contains("flashlight") || lower.contains("torch") -> {
                val turnOn = when {
                    lower.contains("off") || lower.contains("band") -> false
                    lower.contains("on") || lower.contains("chalu") || lower.contains("jala") -> true
                    else -> !currentFlashlightState
                }
                val res = executeFlashlight(context, turnOn)
                AutonomousCommandResult(
                    executed = true,
                    badge = "🔦 Flashlight",
                    summary = if (res) "Flashlight turned ON" else "Flashlight turned OFF",
                    newFlashlightState = res
                )
            }

            // 10. JARVIS Volume Control
            lower.contains("volume up") || lower.contains("aawaz badhao") || lower.contains("volume down") || lower.contains("aawaz kam") -> {
                val up = lower.contains("up") || lower.contains("badhao")
                val pct = executeVolumeChange(context, up)
                AutonomousCommandResult(
                    executed = true,
                    badge = "🔊 Volume Control",
                    summary = "Device media volume adjusted to $pct%"
                )
            }

            // 11. JARVIS App Launcher
            lower.startsWith("open ") || lower.contains("launch ") || lower.endsWith(" kholo") -> {
                val appName = trimmed
                    .replace(Regex("(?i)(open|launch|kholo|app)"), "")
                    .trim()
                val note = executeLaunchApp(context, appName)
                AutonomousCommandResult(executed = true, badge = "🚀 App Launcher", summary = note)
            }

            // 12. MYRA Triggers & Mission Mode
            lower.contains("trigger") || lower.contains("alarm") || lower.contains("mission") -> {
                val isMission = lower.contains("mission")
                val newItem = TriggerMission(
                    time = "08:00 AM",
                    task = trimmed,
                    isMission = isMission,
                    category = if (isMission) "Mission Mode" else "Daily Trigger"
                )
                scheduleVoiceTrigger(context, newItem.time, newItem.task, isMission)
                AutonomousCommandResult(
                    executed = true,
                    badge = if (isMission) "🎯 Mission Mode" else "⏰ Trigger Set",
                    summary = "Scheduled ${if (isMission) "Mission" else "Trigger"} (${newItem.time}): $trimmed",
                    scheduledTriggerMission = newItem
                )
            }

            else -> AutonomousCommandResult(executed = false)
        }
    }
}
