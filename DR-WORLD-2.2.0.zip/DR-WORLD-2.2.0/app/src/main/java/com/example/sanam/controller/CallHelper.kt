package com.example.sanam.controller

import android.content.Context
import com.example.SocialAgent

/**
 * CallHelper (Sanam-ai JARVIS v1.0)
 * Handles direct phone calls & dialer intents with smart contact book resolution.
 */
object CallHelper {
    val favoriteContacts = mapOf(
        "dayaram" to "+919876543210",
        "mumma" to "+919876500001",
        "ammi" to "+923001234567",
        "rahul" to "+919876500002",
        "jaan" to "+919876500003",
        "baba" to "+919876500004",
        "dost" to "+919876500005"
    )

    fun placeCall(context: Context, nameOrNumber: String, hasCallPermission: Boolean): String {
        return SocialAgent.makePhoneCall(context, nameOrNumber, hasCallPermission)
    }

    fun resolvePhone(nameOrNumber: String): String {
        val key = nameOrNumber.trim().lowercase()
        return favoriteContacts[key]
            ?: nameOrNumber.filter { it.isDigit() || it == '+' }.ifEmpty { "+919876543210" }
    }
}
