package com.example.sanam.controller

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.MediaStore
import android.provider.Settings
import androidx.core.net.toUri
import com.example.SocialAgent

/**
 * AppLauncher (Sanam-ai JARVIS v1.0)
 * Launches any installed Android application or system utility with web/intent fallback.
 */
object AppLauncher {
    val supportedApps = listOf(
        "WhatsApp",
        "Instagram",
        "YouTube",
        "Facebook",
        "Maps",
        "Chrome",
        "Camera",
        "Settings",
        "Alarm / Clock",
        "Contacts"
    )

    fun launch(context: Context, appName: String): String {
        val lower = appName.trim().lowercase()
        return try {
            when {
                lower.contains("camera") -> {
                    val intent = Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(intent)
                        "Launched System Camera"
                    } else {
                        SocialAgent.launchApp(context, appName)
                    }
                }
                lower.contains("alarm") || lower.contains("clock") -> {
                    val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(intent)
                        "Opened System Clock & Alarms"
                    } else {
                        SocialAgent.launchApp(context, "Settings")
                    }
                }
                lower.contains("contact") -> {
                    val intent = Intent(Intent.ACTION_VIEW, "content://contacts/people".toUri()).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    if (intent.resolveActivity(context.packageManager) != null) {
                        context.startActivity(intent)
                        "Opened Contacts Book"
                    } else {
                        SocialAgent.launchApp(context, "Settings")
                    }
                }
                lower.contains("wifi") -> {
                    val intent = Intent(Settings.ACTION_WIFI_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    "Opened Wi-Fi Settings"
                }
                lower.contains("bluetooth") -> {
                    val intent = Intent(Settings.ACTION_BLUETOOTH_SETTINGS).apply {
                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    }
                    context.startActivity(intent)
                    "Opened Bluetooth Settings"
                }
                else -> SocialAgent.launchApp(context, appName)
            }
        } catch (_: Exception) {
            SocialAgent.launchApp(context, appName)
        }
    }
}
