package com.example

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.windowInsetsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Computer
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AuraTheme
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * Global Free-Forever Configuration (No BillingClient, No Paywall, isPremium = true everywhere)
 */
object SanamFreeForeverConfig {
    const val IS_PREMIUM: Boolean = true
    const val FREE_FOREVER_BANNER: String = "DR WORLD • Design & Developed by Dayaram Chouhan - Free Forever ♾️ Unlimited"
    const val HEADER_ONLINE_READY: String = "Hello, Dayaram Chouhan (Online Ready)"
}

/**
 * AI Model Connectors (MYRA 2.2.10 Spec: Gemini, Claude, Groq, OpenAI, Perplexity - 100% Free Unlocked)
 */
enum class AiModelConnector(
    val displayName: String,
    val providerTag: String,
    val description: String
) {
    GEMINI_FLASH("Gemini 3.5 Flash", "Google AI", "Ultra-fast multimodal & native voice reasoning"),
    GEMINI_PRO("Gemini 3.1 Pro", "Google AI", "Deep STEM, coding & complex workflow automation"),
    CLAUDE_SONNET("Claude Sonnet", "Anthropic Agent", "Nuanced conversational empathy & coding agent"),
    GROQ_LLAMA("Groq Llama-3.3", "Groq LPU", "Instant low-latency voice & JSON tool execution"),
    OPENAI_GPT4O("GPT-4o Omni", "OpenAI", "Multimodal vision & creative writing assistant"),
    PERPLEXITY_SONAR("Perplexity Sonar", "Live Search", "Real-time web research & fact verification")
}

/**
 * Real working Automation Permission Toggles, Picovoice Free Wake Word ("Hey Sanam"),
 * Sensitivity Slider, and Free Forever Premium Flag (isPremium = true).
 */
data class AutomationPermissionsState(
    val isPremium: Boolean = true,
    val hapticFeedbackEnabled: Boolean = true,
    val gamingScreenCheckEnabled: Boolean = true,
    val imageGenerationEnabled: Boolean = true,
    val automatedPaymentsConfirmationEnabled: Boolean = false, // Safe OFF by default
    val wakeWordEnabled: Boolean = true,
    val wakeWordSensitivity: Float = 0.75f,
    val wakeWordPhrase: String = "Hey Sanam"
)

/**
 * Haptic Feedback Controller (MYRA 2.2.10 Vibration on buttons, toggles, tabs & options)
 */
object HapticHelper {
    fun tick(context: Context, enabled: Boolean = true) {
        if (!enabled) return
        try {
            val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(VibrationEffect.createOneShot(18L, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(18L)
            }
        } catch (_: Exception) {
        }
    }
}

/**
 * Phone Local Timezone Helper (Always uses user's phone timezone)
 */
object LocalTimezoneHelper {
    fun getFormattedLocalTimeAndZone(): String {
        val tz = TimeZone.getDefault()
        val sdf = SimpleDateFormat("hh:mm a • dd MMM yyyy", Locale.getDefault()).apply {
            timeZone = tz
        }
        return "${sdf.format(Date())} (${tz.id})"
    }
}

/**
 * Soft 3D Claymorphism + Neumorphism Card Wrapper
 */
@Composable
fun ClaymorphicCard(
    auraTheme: AuraTheme,
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = auraTheme.primary.copy(alpha = 0.28f),
                spotColor = auraTheme.secondary.copy(alpha = 0.32f)
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(
                Brush.linearGradient(
                    colors = listOf(
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.92f),
                        MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
                    )
                )
            )
            .border(
                BorderStroke(
                    width = 1.5.dp,
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color.White.copy(alpha = 0.22f),
                            auraTheme.primary.copy(alpha = 0.35f),
                            Color.Black.copy(alpha = 0.45f)
                        )
                    )
                ),
                shape = RoundedCornerShape(cornerRadius)
            )
    ) {
        content()
    }
}

/**
 * MYRA Style Bottom Nav Bar:
 * Chat | Home | Voice (center orb) | Settings
 * Translucent Claymorphic Pill with circular glowing Voice Orb in the center notch.
 */
@Composable
fun MyraNotchedBottomBar(
    currentTab: Int,
    auraTheme: AuraTheme,
    isListening: Boolean,
    isSpeaking: Boolean,
    onSelectTab: (Int) -> Unit,
    onCenterMicClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "notch_mic_pulse")
    val breathingScale by infiniteTransition.animateFloat(
        initialValue = 0.98f,
        targetValue = if (isListening || isSpeaking) 1.08f else 1.02f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isListening) 550 else 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "notch_breathing_scale"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .windowInsetsPadding(WindowInsets.navigationBars)
            .padding(horizontal = 10.dp, vertical = 8.dp)
            .testTag("sanam_bottom_nav"),
        contentAlignment = Alignment.BottomCenter
    ) {
        // Bottom Nav Bar (#1A2238 card surface with #7C5CFF purple & neon border):
        // Home | Chat | [70.dp Center Voice Orb] | Assistant | Settings
        Surface(
            shape = RoundedCornerShape(30.dp),
            color = Color(0xFF1A2238).copy(alpha = 0.96f),
            tonalElevation = 12.dp,
            shadowElevation = 16.dp,
            border = BorderStroke(
                1.5.dp,
                Brush.horizontalGradient(
                    listOf(
                        Color(0xFF7C5CFF).copy(alpha = 0.7f),
                        Color(0xFF00FF88).copy(alpha = 0.5f),
                        Color(0xFF7C5CFF).copy(alpha = 0.7f)
                    )
                )
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(68.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. HOME
                NotchNavItem(
                    label = "Home",
                    icon = Icons.Default.Home,
                    selected = currentTab == 1,
                    auraTheme = auraTheme,
                    tag = "nav_tab_home",
                    onClick = { onSelectTab(1) }
                )

                // 2. CHAT
                NotchNavItem(
                    label = "Chat",
                    icon = Icons.AutoMirrored.Filled.Chat,
                    selected = currentTab == 0,
                    auraTheme = auraTheme,
                    tag = "nav_tab_chat",
                    onClick = { onSelectTab(0) }
                )

                // Space reserved for 70.dp Center Voice Orb
                Spacer(modifier = Modifier.width(76.dp))

                // 3. ASSISTANT
                NotchNavItem(
                    label = "Assistant",
                    icon = Icons.Default.RecordVoiceOver,
                    selected = currentTab == 2,
                    auraTheme = auraTheme,
                    tag = "nav_tab_assistant",
                    onClick = { onSelectTab(2) }
                )

                // 4. SETTINGS
                NotchNavItem(
                    label = "Settings",
                    icon = Icons.Default.Settings,
                    selected = currentTab == 3,
                    auraTheme = auraTheme,
                    tag = "nav_tab_settings",
                    onClick = { onSelectTab(3) }
                )
            }
        }

        // CENTER VOICE ORB (70.dp glowing purple #7C5CFF breathing animation 0.98f-1.02f, on tap SpeechManager.startListening)
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.offset(y = (-16).dp)
        ) {
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .size((70 * breathingScale).dp)
                    .shadow(
                        elevation = 18.dp,
                        shape = CircleShape,
                        ambientColor = Color(0xFF7C5CFF),
                        spotColor = Color(0xFF7C5CFF)
                    )
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                Color(0xFFB39DFF),
                                Color(0xFF7C5CFF),
                                Color(0xFF4A25AA)
                            )
                        )
                    )
                    .border(
                        width = 2.5.dp,
                        color = if (isListening || isSpeaking) Color(0xFF00FF88) else Color.White.copy(alpha = 0.9f),
                        shape = CircleShape
                    )
                    .clickable {
                        onCenterMicClick()
                    }
                    .testTag("center_notch_mic_button")
            ) {
                Icon(
                    imageVector = if (isSpeaking || isListening) Icons.Default.GraphicEq else Icons.Default.Mic,
                    contentDescription = "Center Voice Orb",
                    tint = Color.White,
                    modifier = Modifier.size(30.dp)
                )
            }
        }
    }
}

@Composable
private fun NotchNavItem(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    auraTheme: AuraTheme,
    tag: String,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag(tag)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (selected) Color(0xFF7C5CFF) else Color.White.copy(alpha = 0.65f),
            modifier = Modifier.size(21.dp)
        )
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = if (selected) Color(0xFF7C5CFF) else Color.White.copy(alpha = 0.7f),
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
        )
    }
}

/**
 * Settings Card:
 * - "DR WORLD • Design & Developed by Dayaram Chouhan - Free Forever ♾️ Unlimited" (isPremium = true, zero paywall)
 * - Picovoice Free - "Hey Sanam" Wake Word Toggle + Sensitivity Slider (0.1f..1.0f)
 * - SanamAccessibilityService Permission & Action Control Card
 * - Multi-LLM Connectors, Haptics & PC Companion Bridge
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun Myra2210UpgradeCard(
    auraTheme: AuraTheme,
    selectedConnector: AiModelConnector,
    automationState: AutomationPermissionsState,
    onSelectConnector: (AiModelConnector) -> Unit,
    onUpdateAutomationState: (AutomationPermissionsState) -> Unit,
    onTestWakeWord: () -> Unit = {},
    onTakeAppScreenshot: () -> Unit = {},
    onGenerateWebsitePrompt: (String) -> Unit,
    onSendPcCommand: (String) -> Unit
) {
    val context = LocalContext.current
    var websiteIdea by remember { mutableStateOf("Modern portfolio & AI landing page with neon dark theme") }
    var pcCommand by remember { mutableStateOf("Open Chrome and play Sindhi/Dhatki Coke Studio on PC") }
    var pcBridgeStatus by remember { mutableStateOf("Ready • Free Companion Bridge (No Login Needed)") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // 1. FREE FOREVER UNLIMITED BANNER (100% Free - No Paywall, No BillingClient, isPremium = true)
        ClaymorphicCard(auraTheme = auraTheme, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Verified,
                            contentDescription = "Free Forever Unlimited",
                            tint = Color(0xFF00FF88),
                            modifier = Modifier.size(26.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = SanamFreeForeverConfig.FREE_FOREVER_BANNER,
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF00FF88),
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.testTag("free_forever_banner_text")
                            )
                            Text(
                                text = "isPremium = ${automationState.isPremium} • 100% Free Forever • Zero Paywall • All Features Unlocked",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Phone Local Timezone Display
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                    border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Schedule,
                            contentDescription = "Phone Timezone",
                            tint = auraTheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Phone Local Time: ${LocalTimezoneHelper.getFormattedLocalTimeAndZone()}",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "🤖 LIVE AI MODEL CONNECTORS (100% Free Unlimited):",
                    style = MaterialTheme.typography.labelSmall,
                    color = auraTheme.primary,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(6.dp))

                FlowRow(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    AiModelConnector.entries.forEach { connector ->
                        val selected = connector == selectedConnector
                        FilterChip(
                            selected = selected,
                            onClick = { onSelectConnector(connector) },
                            label = {
                                Text(
                                    text = "${connector.displayName} (${connector.providerTag})",
                                    style = MaterialTheme.typography.labelSmall
                                )
                            },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = auraTheme.primary.copy(alpha = 0.25f),
                                selectedLabelColor = auraTheme.primary
                            ),
                            modifier = Modifier.testTag("connector_chip_${connector.name.lowercase()}")
                        )
                    }
                }
            }
        }

        // 2. PICOVOICE FREE WAKE WORD ("Hey Sanam") + SENSITIVITY SLIDER CARD
        ClaymorphicCard(auraTheme = auraTheme, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(
                            imageVector = Icons.Default.RecordVoiceOver,
                            contentDescription = "Picovoice Free Wake Word",
                            tint = Color(0xFF00FF88)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "🎙️ PICOVOICE FREE WAKE WORD: \"Hey Sanam\"",
                                style = MaterialTheme.typography.titleMedium,
                                color = Color(0xFF00FF88),
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Hands-free \"Hey Sanam\" voice activation (No Google Popup)",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    Switch(
                        checked = automationState.wakeWordEnabled,
                        onCheckedChange = { enabled ->
                            onUpdateAutomationState(automationState.copy(wakeWordEnabled = enabled))
                        },
                        modifier = Modifier.testTag("toggle_wake_word")
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = "Wake Word Sensitivity: ${(automationState.wakeWordSensitivity * 100).toInt()}% (Picovoice Free Engine)",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onSurface,
                    fontWeight = FontWeight.SemiBold
                )
                Slider(
                    value = automationState.wakeWordSensitivity,
                    onValueChange = { newSens ->
                        onUpdateAutomationState(
                            automationState.copy(wakeWordSensitivity = newSens.coerceIn(0.1f, 1.0f))
                        )
                    },
                    valueRange = 0.1f..1.0f,
                    modifier = Modifier.testTag("wake_word_sensitivity_slider")
                )

                Button(
                    onClick = {
                        HapticHelper.tick(context, automationState.hapticFeedbackEnabled)
                        onTestWakeWord()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FF88)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("test_hey_sanam_wake_word_btn")
                ) {
                    Icon(Icons.Default.Mic, contentDescription = "Hey Sanam", tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Activate \"Hey Sanam\" Wake Word Now",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // 3. SANAM ACCESSIBILITY SERVICE PERMISSION & GESTURE ACTIONS CARD
        SanamAccessibilityPermissionCard(
            auraTheme = auraTheme,
            onTakeAppScreenshot = onTakeAppScreenshot
        )

        // 4. AUTOMATION PERMISSION TOGGLES & HAPTIC VIBRATION
        ClaymorphicCard(auraTheme = auraTheme, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Vibration,
                        contentDescription = "Automation & Haptics",
                        tint = auraTheme.secondary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "⚙️ AUTOMATION PERMISSIONS & HAPTICS",
                        style = MaterialTheme.typography.titleMedium,
                        color = auraTheme.secondary,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                AutomationToggleRow(
                    title = "Haptic Feedback Vibration",
                    subtitle = "Gentle vibration on buttons, toggles, tabs & orb taps",
                    checked = automationState.hapticFeedbackEnabled,
                    onCheckedChange = {
                        onUpdateAutomationState(automationState.copy(hapticFeedbackEnabled = it))
                    },
                    tag = "toggle_haptic_feedback"
                )

                AutomationToggleRow(
                    title = "Gaming Assistant Screen Check",
                    subtitle = "When OFF, Sanam stops reading the game screen & pauses gaming coach",
                    checked = automationState.gamingScreenCheckEnabled,
                    onCheckedChange = {
                        onUpdateAutomationState(automationState.copy(gamingScreenCheckEnabled = it))
                    },
                    tag = "toggle_gaming_screen_check"
                )

                AutomationToggleRow(
                    title = "AI Image & Status Card Generation",
                    subtitle = "When OFF, Sanam will not generate images or status cards automatically",
                    checked = automationState.imageGenerationEnabled,
                    onCheckedChange = {
                        onUpdateAutomationState(automationState.copy(imageGenerationEnabled = it))
                    },
                    tag = "toggle_image_generation"
                )

                AutomationToggleRow(
                    title = "Automated Payments Confirmation Guard",
                    subtitle = "Keep OFF so Sanam never clicks Pay / Place Order / Send Money automatically",
                    checked = automationState.automatedPaymentsConfirmationEnabled,
                    onCheckedChange = {
                        onUpdateAutomationState(automationState.copy(automatedPaymentsConfirmationEnabled = it))
                    },
                    tag = "toggle_automated_payments"
                )
            }
        }

        // 5. MYRA PC CONTROLLER BRIDGE & 1-PROMPT WEBSITE GENERATOR
        ClaymorphicCard(auraTheme = auraTheme, modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Computer,
                        contentDescription = "PC Controller & Website Builder",
                        tint = auraTheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = "💻 DR WORLD PC CONTROLLER & WEBSITE BUILDER",
                            style = MaterialTheme.typography.titleMedium,
                            color = auraTheme.primary,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = pcBridgeStatus,
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = pcCommand,
                    onValueChange = { pcCommand = it },
                    label = { Text("Remote Windows PC Command (WhatsApp / Files / Browser)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                OutlinedButton(
                    onClick = {
                        pcBridgeStatus = "✅ Dispatched to PC Companion: \"$pcCommand\""
                        onSendPcCommand(pcCommand)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("send_pc_command_btn")
                ) {
                    Icon(Icons.Default.Computer, contentDescription = "Send to PC", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Execute on Windows PC Companion")
                }

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = websiteIdea,
                    onValueChange = { websiteIdea = it },
                    label = { Text("1-Prompt AI Website Builder Idea") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = { onGenerateWebsitePrompt(websiteIdea) },
                    colors = ButtonDefaults.buttonColors(containerColor = auraTheme.secondary),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("generate_website_btn")
                ) {
                    Icon(Icons.Default.Code, contentDescription = "Generate Website", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Generate Complete Website Code with Sanam AI")
                }
            }
        }
    }
}

@Composable
private fun AutomationToggleRow(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f).padding(end = 8.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.testTag(tag)
        )
    }
}
