package com.example

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.widget.Toast
import androidx.core.app.NotificationCompat
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

@Entity(tableName = "TriggerMission")
data class TriggerMission(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val time: String, // e.g., "08:00 AM"
    val task: String, // e.g., "Good morning bolna", "Pani peene ki yaad dilana"
    val isMission: Boolean, // false = Trigger, true = Mission Mode
    val isEnabled: Boolean = true,
    val isCompleted: Boolean = false,
    val category: String = "Daily",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val sender: String, // "USER" or "SANAM"
    val text: String,
    val language: String, // "Dhatki", "Sindhi", "Urdu", "Hindi"
    val mode: String, // "Girlfriend", "JARVIS", "Voice", "Visual Lens", "Gaming", "Security"
    val actionBadge: String? = null,
    val sessionId: String = "default_session",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "conversation_sessions")
data class ConversationSessionEntity(
    @PrimaryKey val sessionId: String,
    val title: String,
    val lastMessagePreview: String,
    val language: String,
    val mode: String,
    val messageCount: Int = 1,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memory_facts")
data class MemoryFactEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val keyTitle: String,
    val factValue: String,
    val category: String = "Personal", // "Personal", "Preference", "Contact", "Bond"
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "screen_logs")
data class ScreenLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val packageName: String,
    val capturedText: String,
    val timestamp: Long = System.currentTimeMillis()
)

@Dao
interface MissionDao {
    @Query("SELECT * FROM TriggerMission ORDER BY isMission ASC, createdAt DESC")
    fun getAllFlow(): Flow<List<TriggerMission>>

    @Query("SELECT * FROM TriggerMission ORDER BY createdAt DESC")
    suspend fun getAll(): List<TriggerMission>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(m: TriggerMission): Long

    @Query("UPDATE TriggerMission SET isEnabled = :enabled WHERE id = :id")
    suspend fun setEnabled(id: Int, enabled: Boolean)

    @Query("UPDATE TriggerMission SET isCompleted = :completed WHERE id = :id")
    suspend fun setCompleted(id: Int, completed: Boolean)

    @Query("DELETE FROM TriggerMission WHERE id = :id")
    suspend fun deleteById(id: Int)
}

@Dao
interface SanamDao {
    @Query("SELECT * FROM chat_messages ORDER BY timestamp ASC")
    fun getAllMessages(): Flow<List<ChatMessageEntity>>

    @Query("SELECT * FROM chat_messages WHERE sessionId = :sessionId ORDER BY timestamp ASC")
    suspend fun getMessagesForSession(sessionId: String): List<ChatMessageEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(msg: ChatMessageEntity)

    @Query("DELETE FROM chat_messages")
    suspend fun clearMessages()

    @Query("SELECT * FROM conversation_sessions ORDER BY updatedAt DESC")
    fun getAllConversationSessions(): Flow<List<ConversationSessionEntity>>

    @Query("SELECT * FROM conversation_sessions ORDER BY updatedAt DESC LIMIT 1")
    suspend fun getLatestConversationSession(): ConversationSessionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertConversationSession(session: ConversationSessionEntity)

    @Query("DELETE FROM conversation_sessions WHERE sessionId = :sessionId")
    suspend fun deleteConversationSession(sessionId: String)

    @Query("SELECT * FROM memory_facts ORDER BY timestamp DESC")
    fun getAllMemories(): Flow<List<MemoryFactEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(fact: MemoryFactEntity)

    @Query("DELETE FROM memory_facts WHERE id = :id")
    suspend fun deleteMemoryById(id: Int)

    @Query("SELECT * FROM screen_logs ORDER BY timestamp DESC LIMIT 40")
    fun getRecentScreenLogs(): Flow<List<ScreenLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertScreenLog(log: ScreenLogEntity)

    @Query("DELETE FROM screen_logs")
    suspend fun clearScreenLogs()
}

@Database(
    entities = [
        TriggerMission::class,
        com.example.data.TriggersAndMission::class,
        ChatMessageEntity::class,
        ConversationSessionEntity::class,
        MemoryFactEntity::class,
        ScreenLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class SanamDatabase : RoomDatabase() {
    abstract fun missionDao(): MissionDao
    abstract fun sanamDao(): SanamDao

    companion object {
        @Volatile
        private var INSTANCE: SanamDatabase? = null

        fun getInstance(context: Context): SanamDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    SanamDatabase::class.java,
                    "sanam_ai_myra.db"
                ).fallbackToDestructiveMigration(true).build()
                INSTANCE = instance
                instance
            }
        }
    }
}

class SanamRepository(
    private val sanamDao: SanamDao,
    private val missionDao: MissionDao
) {
    val allMessages: Flow<List<ChatMessageEntity>> = sanamDao.getAllMessages()
    val allConversationSessions: Flow<List<ConversationSessionEntity>> = sanamDao.getAllConversationSessions()
    val allMemories: Flow<List<MemoryFactEntity>> = sanamDao.getAllMemories()
    val allMissionsAndTriggers: Flow<List<TriggerMission>> = missionDao.getAllFlow()
    val recentScreenLogs: Flow<List<ScreenLogEntity>> = sanamDao.getRecentScreenLogs()

    suspend fun addMessage(msg: ChatMessageEntity) = sanamDao.insertMessage(msg)
    suspend fun getMessagesForSession(sessionId: String): List<ChatMessageEntity> =
        sanamDao.getMessagesForSession(sessionId)
    suspend fun clearChat() = sanamDao.clearMessages()

    suspend fun upsertConversationSession(session: ConversationSessionEntity) =
        sanamDao.upsertConversationSession(session)
    suspend fun getLatestConversationSession(): ConversationSessionEntity? =
        sanamDao.getLatestConversationSession()
    suspend fun deleteConversationSession(sessionId: String) =
        sanamDao.deleteConversationSession(sessionId)

    suspend fun addMemory(fact: MemoryFactEntity) = sanamDao.insertMemory(fact)
    suspend fun deleteMemory(id: Int) = sanamDao.deleteMemoryById(id)

    suspend fun addTriggerMission(item: TriggerMission): Long = missionDao.insert(item)
    suspend fun toggleTriggerMission(id: Int, enabled: Boolean) = missionDao.setEnabled(id, enabled)
    suspend fun completeMission(id: Int, completed: Boolean) = missionDao.setCompleted(id, completed)
    suspend fun deleteTriggerMission(id: Int) = missionDao.deleteById(id)

    suspend fun addScreenLog(log: ScreenLogEntity) = sanamDao.insertScreenLog(log)
    suspend fun clearScreenLogs() = sanamDao.clearScreenLogs()
}

/**
 * Global Memory Bridge used by ScreenReaderService and Autonomous Agents
 */
object Memory {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _liveScreenStream = MutableStateFlow<List<String>>(
        listOf(
            "Sanam AI Screen Reader Ready • Waiting for accessibility or on-screen events",
            "WhatsApp Status & Instagram Post Agent initialized",
            "Multi-Language Neural Engine: Dhatki • Sindhi • Urdu • Hindi active"
        )
    )
    val liveScreenStream: StateFlow<List<String>> = _liveScreenStream.asStateFlow()

    private var appContext: Context? = null

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    fun saveScreenText(text: String, packageName: String = "com.system.screen") {
        val cleaned = text.trim().removeSurrounding("[", "]").trim()
        if (cleaned.length < 3) return
        val timestampStr = SimpleDateFormat("hh:mm:ss a", Locale.getDefault()).format(Date())
        val entry = "[$timestampStr] ($packageName): $cleaned"
        val current = _liveScreenStream.value.toMutableList()
        if (current.firstOrNull()?.endsWith(cleaned) == true) return
        current.add(0, entry)
        if (current.size > 30) {
            current.removeAt(current.lastIndex)
        }
        _liveScreenStream.value = current

        val ctx = appContext ?: return
        scope.launch {
            try {
                SanamDatabase.getInstance(ctx).sanamDao().insertScreenLog(
                    ScreenLogEntity(
                        packageName = packageName,
                        capturedText = cleaned
                    )
                )
            } catch (_: Exception) {
            }
        }
    }
}

object MissionManager {
    private const val CHANNEL_ID = "sanam_myra_triggers"

    fun addTrigger(
        context: Context,
        time: String,
        task: String,
        isMission: Boolean = false,
        category: String = if (isMission) "Mission Mode" else "Daily Trigger"
    ) {
        ensureNotificationChannel(context)
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val intent = Intent(context, TriggerAlarmReceiver::class.java).apply {
            putExtra("EXTRA_TIME", time)
            putExtra("EXTRA_TASK", task)
            putExtra("EXTRA_IS_MISSION", isMission)
        }
        val requestCode = (time + task).hashCode()
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerMillis = parseTimeToNextMillis(time)
        try {
            alarmManager?.setAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerMillis,
                pendingIntent
            )
        } catch (_: SecurityException) {
            alarmManager?.set(
                AlarmManager.RTC_WAKEUP,
                triggerMillis,
                pendingIntent
            )
        } catch (_: Exception) {
        }
    }

    fun fireTriggerNow(context: Context, time: String, task: String, isMission: Boolean) {
        ensureNotificationChannel(context)
        val title = if (isMission) "⚡ Sanam Mission Mode Active ($time)" else "💖 Sanam AI Trigger ($time)"
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle(title)
            .setContentText(task)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()
        try {
            notificationManager?.notify((time + task).hashCode(), notification)
        } catch (_: Exception) {
        }
        Toast.makeText(context, "$title: $task", Toast.LENGTH_SHORT).show()
    }

    private fun ensureNotificationChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Sanam AI Triggers & Missions",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Autonomous voice triggers and Mission Mode reminders from Sanam AI"
            }
            val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            nm?.createNotificationChannel(channel)
        }
    }

    private fun parseTimeToNextMillis(timeStr: String): Long {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance()
        return try {
            val sdf = SimpleDateFormat("hh:mm a", Locale.US)
            val parsed = sdf.parse(timeStr.trim().uppercase(Locale.US))
            if (parsed != null) {
                val parsedCal = Calendar.getInstance().apply { time = parsed }
                target.set(Calendar.HOUR_OF_DAY, parsedCal.get(Calendar.HOUR_OF_DAY))
                target.set(Calendar.MINUTE, parsedCal.get(Calendar.MINUTE))
                target.set(Calendar.SECOND, 0)
                if (target.before(now)) {
                    target.add(Calendar.DAY_OF_YEAR, 1)
                }
                target.timeInMillis
            } else {
                now.timeInMillis + 60_000L
            }
        } catch (_: Exception) {
            now.timeInMillis + 60_000L
        }
    }
}

class TriggerAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val time = intent?.getStringExtra("EXTRA_TIME") ?: "Now"
        val task = intent?.getStringExtra("EXTRA_TASK") ?: "Sanam AI Reminder"
        val isMission = intent?.getBooleanExtra("EXTRA_IS_MISSION", false) ?: false
        MissionManager.fireTriggerNow(context, time, task, isMission)
    }
}
