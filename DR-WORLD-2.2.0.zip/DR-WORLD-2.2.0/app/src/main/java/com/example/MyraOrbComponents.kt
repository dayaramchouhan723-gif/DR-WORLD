package com.example

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.ScreenshotMonitor
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.AssistChip
import androidx.compose.material3.AssistChipDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.sanam.ui.components.SecondaryWaveAnimationLayer
import com.example.ui.theme.AuraTheme
import com.example.ui.theme.OrbStyle
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun MyraNeuralOrbHeader(
    auraTheme: AuraTheme,
    orbStyle: OrbStyle,
    selectedLanguage: SanamLanguage,
    selectedMode: SanamMode,
    isListening: Boolean,
    isSpeaking: Boolean,
    isThinking: Boolean,
    telemetry: SystemTelemetry,
    statusBanner: String,
    onMicClick: () -> Unit,
    onOrbStyleChange: (OrbStyle) -> Unit,
    onLanguageChange: (SanamLanguage) -> Unit,
    onAuraChange: (AuraTheme) -> Unit
) {
    var currentMood by remember(statusBanner) {
        mutableStateOf(SanamMood.detectFromText(statusBanner))
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("myra_orb_header_card"),
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.96f)
        ),
        border = BorderStroke(2.dp, Color(0xFF00FF88))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Header Row: "Hello, Dayaram Chouhan (Online Ready)" + Free Forever Badge
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00FF88))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = SanamFreeForeverConfig.HEADER_ONLINE_READY,
                        style = MaterialTheme.typography.titleSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.testTag("header_online_ready_text")
                    )
                }
                Surface(
                    shape = RoundedCornerShape(50),
                    color = Color(0xFF00FF88).copy(alpha = 0.18f),
                    border = BorderStroke(1.dp, Color(0xFF00FF88))
                ) {
                    Text(
                        text = "FREE FOREVER ♾️",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF00FF88),
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // FULL BODY MYRA STYLE STAGE (Replaces small 120.dp CircleShape box)
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(320.dp)
                    .clip(RoundedCornerShape(28.dp))
                    .background(Color(0xFF070A14))
                    .border(2.dp, Color(0xFF00FF88), RoundedCornerShape(28.dp))
                    .testTag("full_body_myra_stage")
            ) {
                // Subtle holographic hero art backdrop
                Image(
                    painter = painterResource(id = R.drawable.img_sanam_hero_1791435022733),
                    contentDescription = "Sanam AI Neural Core Backdrop",
                    contentScale = ContentScale.Crop,
                    alpha = 0.16f,
                    modifier = Modifier.fillMaxSize()
                )

                // Top Greeting Header: GOOD EVENING DAYARAM BOSS / I'M ALWAYS WITH YOU
                Column(
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "GOOD EVENING DAYARAM BOSS",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.testTag("good_evening_dayaram_boss_text")
                    )
                    Text(
                        text = "I'M ALWAYS WITH YOU",
                        color = Color.Cyan,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center
                    )
                }

                // MAIN FULL BODY GIRL (R.drawable.sanam_full_body, ContentScale.Fit, Modifier.graphicsLayer for breathing 0.98f..1.02f + 4-Mood Halchal)
                SanamMoodSwitcher(
                    mood = currentMood,
                    onMoodChange = { currentMood = it },
                    isSpeaking = isSpeaking,
                    modifier = Modifier
                        .fillMaxHeight(0.78f)
                        .fillMaxWidth()
                        .align(Alignment.Center)
                        .offset(y = 30.dp)
                )

                // ORB ON WAIST like Myra video (65.dp)
                OrbView(
                    auraTheme = auraTheme,
                    orbStyle = orbStyle,
                    isActive = isListening || isSpeaking || isThinking,
                    onClick = onMicClick,
                    modifier = Modifier
                        .align(Alignment.Center)
                        .offset(y = 90.dp)
                        .size(65.dp)
                )

                // TAP TO SPEAK below waist orb (NO GOOGLE OPEN - uses VoiceController directly)
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomCenter)
                        .padding(bottom = 12.dp)
                ) {
                    TapToSpeakButton(
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        isThinking = isThinking,
                        onClick = onMicClick
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // 4 Mood Halchal Switcher Pills (Happy, Sad, Love, Chill)
            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.testTag("sanam_mood_pills_row")
            ) {
                SanamMood.entries.forEach { item ->
                    val selected = item == currentMood
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = if (selected) item.primaryColor.copy(alpha = 0.25f)
                        else Color(0xFF14182B).copy(alpha = 0.85f),
                        border = BorderStroke(
                            width = if (selected) 1.5.dp else 1.dp,
                            color = if (selected) item.primaryColor else Color.White.copy(alpha = 0.2f)
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(50))
                            .clickable { currentMood = item }
                            .testTag("sanam_mood_pill_${item.name.lowercase()}")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(item.primaryColor)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (selected) item.primaryColor else Color.White.copy(alpha = 0.85f),
                                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            SecondaryWaveAnimationLayer(
                auraTheme = auraTheme,
                isActive = isListening || isSpeaking || isThinking
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Status Banner
            Text(
                text = statusBanner,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface,
                textAlign = TextAlign.Center,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Multi-Language Intelligence Selector (Dhatki • Sindhi • Urdu • Hindi) - Active with Toast & Locale/Pitch
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SanamLanguage.entries.forEach { lang ->
                    val isSelected = lang == selectedLanguage
                    FilterChip(
                        selected = isSelected,
                        onClick = { onLanguageChange(lang) },
                        label = {
                            Text(
                                text = "${lang.label} (${lang.nativeScript})",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = Color(0xFF00FF88).copy(alpha = 0.24f),
                            selectedLabelColor = Color.White
                        ),
                        modifier = Modifier.testTag("lang_chip_${lang.code.lowercase()}")
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Orb Style Selector (Classic / Energy / Neon) + Aura Selector
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OrbStyle.entries.forEach { style ->
                    val selected = style == orbStyle
                    FilterChip(
                        selected = selected,
                        onClick = { onOrbStyleChange(style) },
                        label = {
                            Text(
                                text = "Orb: ${style.title}",
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        leadingIcon = {
                            Icon(
                                imageVector = Icons.Default.Bolt,
                                contentDescription = style.title,
                                modifier = Modifier.size(15.dp)
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = auraTheme.primary.copy(alpha = 0.24f),
                            selectedLabelColor = auraTheme.primary
                        ),
                        modifier = Modifier.testTag("orb_style_${style.name.lowercase()}")
                    )
                }

                AuraTheme.entries.forEach { aura ->
                    val isCurrent = aura == auraTheme
                    AssistChip(
                        onClick = { onAuraChange(aura) },
                        label = {
                            Text(
                                text = aura.title,
                                style = MaterialTheme.typography.labelSmall
                            )
                        },
                        leadingIcon = {
                            Box(
                                modifier = Modifier
                                    .size(12.dp)
                                    .clip(CircleShape)
                                    .background(aura.primary)
                                    .border(
                                        width = if (isCurrent) 2.dp else 0.dp,
                                        color = Color.White,
                                        shape = CircleShape
                                    )
                            )
                        },
                        colors = AssistChipDefaults.assistChipColors(
                            containerColor = if (isCurrent) {
                                aura.primary.copy(alpha = 0.2f)
                            } else {
                                MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                            }
                        )
                    )
                }
            }
        }
    }
}

@Composable
fun MyraAnimatedOrbCanvas(
    auraTheme: AuraTheme,
    orbStyle: OrbStyle,
    isActive: Boolean,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "myra_orb_transition")
    val rotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isActive) 3600 else 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "orb_rotation"
    )
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.86f,
        targetValue = if (isActive) 1.16f else 1.04f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isActive) 650 else 1600, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "orb_pulse"
    )

    Canvas(modifier = modifier) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val baseRadius = (size.minDimension / 2f) * 0.68f

        // Ambient radial glow
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    auraTheme.glowCore.copy(alpha = 0.55f),
                    auraTheme.glowOuter.copy(alpha = 0.25f),
                    Color.Transparent
                ),
                center = center,
                radius = baseRadius * 1.42f * pulse
            ),
            radius = baseRadius * 1.42f * pulse,
            center = center
        )

        when (orbStyle) {
            OrbStyle.CLASSIC -> {
                // MYRA Classic: Concentric smooth glowing rings
                drawCircle(
                    color = auraTheme.primary.copy(alpha = 0.35f),
                    radius = baseRadius * 1.15f * pulse,
                    center = center,
                    style = Stroke(width = 3.dp.toPx())
                )
                drawCircle(
                    color = auraTheme.secondary.copy(alpha = 0.65f),
                    radius = baseRadius * 0.94f / pulse,
                    center = center,
                    style = Stroke(width = 4.dp.toPx())
                )
                rotate(degrees = rotation, pivot = center) {
                    drawArc(
                        brush = Brush.sweepGradient(
                            listOf(auraTheme.primary, auraTheme.secondary, auraTheme.primary)
                        ),
                        startAngle = 0f,
                        sweepAngle = 270f,
                        useCenter = false,
                        topLeft = Offset(center.x - baseRadius, center.y - baseRadius),
                        size = Size(baseRadius * 2f, baseRadius * 2f),
                        style = Stroke(width = 6.dp.toPx(), cap = StrokeCap.Round)
                    )
                }
            }

            OrbStyle.ENERGY -> {
                // MYRA Energy: Sine-wave plasma harmonic rings & orbital flares
                val path = Path()
                val steps = 72
                val waveAmp = if (isActive) 12.dp.toPx() else 6.dp.toPx()
                for (i in 0..steps) {
                    val angleRad = (i.toFloat() / steps) * 2.0 * PI
                    val r = baseRadius * pulse + sin(angleRad * 6 + Math.toRadians(rotation.toDouble())).toFloat() * waveAmp
                    val x = center.x + (r * cos(angleRad)).toFloat()
                    val y = center.y + (r * sin(angleRad)).toFloat()
                    if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
                }
                path.close()
                drawPath(
                    path = path,
                    brush = Brush.linearGradient(listOf(auraTheme.primary, auraTheme.secondary)),
                    style = Stroke(width = 4.5.dp.toPx())
                )

                rotate(degrees = -rotation * 1.3f, pivot = center) {
                    for (idx in 0 until 8) {
                        val a = Math.toRadians((idx * 45).toDouble())
                        val orbPos = Offset(
                            center.x + (baseRadius * 1.18f * cos(a)).toFloat(),
                            center.y + (baseRadius * 1.18f * sin(a)).toFloat()
                        )
                        drawCircle(
                            color = if (idx % 2 == 0) auraTheme.primary else auraTheme.secondary,
                            radius = 4.dp.toPx() * pulse,
                            center = orbPos
                        )
                    }
                }
            }

            OrbStyle.NEON, OrbStyle.SANAM_AVATAR -> {
                // MYRA Neon: Cybernetic geometric hexagon + laser radar rings
                rotate(degrees = rotation, pivot = center) {
                    val hexPath = Path()
                    val hexRadius = baseRadius * 1.12f * pulse
                    for (i in 0..6) {
                        val a = Math.toRadians((i * 60).toDouble())
                        val x = center.x + (hexRadius * cos(a)).toFloat()
                        val y = center.y + (hexRadius * sin(a)).toFloat()
                        if (i == 0) hexPath.moveTo(x, y) else hexPath.lineTo(x, y)
                    }
                    hexPath.close()
                    drawPath(
                        path = hexPath,
                        color = auraTheme.primary,
                        style = Stroke(width = 3.5.dp.toPx())
                    )
                }
                rotate(degrees = -rotation, pivot = center) {
                    val innerHex = Path()
                    val r2 = baseRadius * 0.88f
                    for (i in 0..6) {
                        val a = Math.toRadians((i * 60 + 30).toDouble())
                        val x = center.x + (r2 * cos(a)).toFloat()
                        val y = center.y + (r2 * sin(a)).toFloat()
                        if (i == 0) innerHex.moveTo(x, y) else innerHex.lineTo(x, y)
                    }
                    innerHex.close()
                    drawPath(
                        path = innerHex,
                        color = auraTheme.secondary,
                        style = Stroke(width = 3.dp.toPx())
                    )
                }
            }
        }

        // Core luminous sphere
        drawCircle(
            brush = Brush.radialGradient(
                colors = listOf(
                    auraTheme.primary.copy(alpha = 0.85f),
                    auraTheme.secondary.copy(alpha = 0.65f),
                    auraTheme.background.copy(alpha = 0.9f)
                ),
                center = center,
                radius = baseRadius * 0.72f
            ),
            radius = baseRadius * 0.72f,
            center = center
        )
    }
}

/**
 * Quick MYRA Action Strip containing all requested direct buttons:
 * [Post to Insta] [Post to FB] [Share on WhatsApp Status] [Take Screenshot] [Set Trigger] [Mission Mode]
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun MyraQuickActionButtonsBar(
    auraTheme: AuraTheme,
    onPostToInsta: () -> Unit,
    onPostToFb: () -> Unit,
    onShareWhatsAppStatus: () -> Unit,
    onTakeScreenshot: () -> Unit,
    onSetTrigger: () -> Unit,
    onMissionMode: () -> Unit,
    onOpenMaps: () -> Unit,
    onToggleTouchGuard: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.65f)
        ),
        border = BorderStroke(1.dp, auraTheme.primary.copy(alpha = 0.25f))
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Text(
                text = "⚡ DR WORLD AUTONOMOUS QUICK ACTIONS",
                style = MaterialTheme.typography.labelSmall,
                color = auraTheme.primary,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickActionPill(
                    label = "Post to Insta",
                    icon = Icons.Default.PhotoCamera,
                    accent = auraTheme.secondary,
                    tag = "btn_post_to_insta",
                    onClick = onPostToInsta
                )
                QuickActionPill(
                    label = "Post to FB",
                    icon = Icons.Default.Public,
                    accent = auraTheme.primary,
                    tag = "btn_post_to_fb",
                    onClick = onPostToFb
                )
                QuickActionPill(
                    label = "Share on WhatsApp Status",
                    icon = Icons.Default.Share,
                    accent = Color(0xFF00E676),
                    tag = "btn_share_whatsapp_status",
                    onClick = onShareWhatsAppStatus
                )
                QuickActionPill(
                    label = "Take Screenshot",
                    icon = Icons.Default.ScreenshotMonitor,
                    accent = auraTheme.primary,
                    tag = "btn_take_screenshot",
                    onClick = onTakeScreenshot
                )
                QuickActionPill(
                    label = "Set Trigger",
                    icon = Icons.Default.NotificationsActive,
                    accent = Color(0xFFFFB300),
                    tag = "btn_set_trigger",
                    onClick = onSetTrigger
                )
                QuickActionPill(
                    label = "Mission Mode",
                    icon = Icons.Default.Flag,
                    accent = auraTheme.secondary,
                    tag = "btn_mission_mode",
                    onClick = onMissionMode
                )
                QuickActionPill(
                    label = "Open Maps",
                    icon = Icons.Default.Map,
                    accent = auraTheme.tertiary,
                    tag = "btn_open_maps",
                    onClick = onOpenMaps
                )
                QuickActionPill(
                    label = "Touch Guard",
                    icon = Icons.Default.Security,
                    accent = auraTheme.primary,
                    tag = "btn_touch_guard",
                    onClick = onToggleTouchGuard
                )
            }
        }
    }
}

@Composable
private fun QuickActionPill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accent: Color,
    tag: String,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, accent.copy(alpha = 0.55f)),
        modifier = Modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label,
                tint = accent,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.onSurface,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
