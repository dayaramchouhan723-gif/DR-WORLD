package com.example.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/**
 * Room Entity and Database for TriggersAndMission (version = 1)
 */
@Entity(tableName = "triggers_and_mission")
data class TriggersAndMission(
    @PrimaryKey val id: String,
    val time: String,
    val task: String,
    val isEnabled: Boolean = true,
    val type: String = "Trigger"
)

@Dao
interface TriggersAndMissionDao {
    @Query("SELECT * FROM triggers_and_mission")
    fun getAll(): Flow<List<TriggersAndMission>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: TriggersAndMission)
}

@Database(
    entities = [TriggersAndMission::class],
    version = 1,
    exportSchema = false
)
abstract class TriggersAndMissionDatabase : RoomDatabase() {
    abstract fun triggersAndMissionDao(): TriggersAndMissionDao
}
