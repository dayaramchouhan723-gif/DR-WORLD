package com.example.sanam.controller

import android.content.Context
import com.example.SocialAgent

/**
 * SmsHelper (Sanam-ai JARVIS v1.0)
 * Dispatches direct SMS via SmsManager or opens pre-filled SMS composer.
 */
object SmsHelper {
    fun sendSms(
        context: Context,
        recipientNameOrNumber: String,
        message: String,
        hasSmsPermission: Boolean
    ): String {
        val resolved = CallHelper.resolvePhone(recipientNameOrNumber)
        return SocialAgent.sendSms(context, resolved, message, hasSmsPermission)
    }
}
